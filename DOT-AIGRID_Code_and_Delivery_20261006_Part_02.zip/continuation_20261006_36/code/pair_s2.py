from pair_common import run
run('s2')
