from pathlib import Path
import json,hashlib,argparse
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);a=p.parse_args()
receipt=ROOT/'submissions/real_smoke/attempt_001';out=ROOT/'artifacts/real_smoke/attempt_001';errors=[]
detail=json.loads((receipt/f'detail_{a.snapshot}.json').read_text());status=detail.get('data',{}).get('status')
if status not in {'job_succeeded','job_failed','job_stopped'}:
 print(json.dumps({'status':'PENDING_OBSERVATION','platform_status':status,'do_not_resubmit':True}));raise SystemExit(2)
if status!='job_succeeded':errors.append('platform_not_success')
instances=json.loads((receipt/f'instances_{a.snapshot}.json').read_text()).get('data',[])
if not any(x.get('instance_status')=='instance_success' for x in instances):errors.append('instance_not_success')
logs=json.loads((receipt/f'logs_{a.snapshot}.json').read_text()).get('data',{}) or {}
if not any('exit code 0' in x.get('message','') for x in logs.get('logs',[])):errors.append('exit_zero_missing')
freeze=json.loads((receipt/'source_freeze.json').read_text())
for row in freeze['files']:
 if hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()!=row['sha256']:errors.append('source_changed:'+row['path'])
if (out/'result.json').is_file():
 result=json.loads((out/'result.json').read_text())
 if result['status']!='PASS_REAL_GPU_HOST_SMOKE' or result['GPU_requests']!=1 or result['cap_writes']!=0 or not 0<result['completed_tokens']<=32:errors.append('invalid_runtime_result')
 events=[json.loads(line) for line in (out/'host_events.jsonl').read_text().splitlines() if line]
 for kind in ['request_start','engine_terminal','host_drain_observed']:
  if sum(e.get('event')==kind for e in events)!=1:errors.append('event_count:'+kind)
 if any('text' in e or 'token_ids' in e or e.get('true_eos_ns') is not None or e.get('device_completion_ns') is not None for e in events):errors.append('event_privacy_or_device_claim')
 for timing in ['gpu_before.json','gpu_after.json']:
  if not (out/timing).is_file():errors.append('missing_'+timing)
 if not errors:
  before=json.loads((out/'gpu_before.json').read_text());after=json.loads((out/'gpu_after.json').read_text())
  if [(r['uuid_sha256'],r['power_limit_W']) for r in before]!=[(r['uuid_sha256'],r['power_limit_W']) for r in after]:errors.append('device_or_cap_change')
else:result={};errors.append('missing_result')
if (out/'nvml.jsonl').is_file():
 power=[json.loads(line) for line in (out/'nvml.jsonl').read_text().splitlines() if line]
 if len(power)<2 or any(r['arrival_ns']<r['query_begin_ns'] or r['power_W']!=r['raw_power_mW']/1000 for r in power):errors.append('NVML_units_or_time_invalid')
 if any(b['query_begin_ns']<=a['query_begin_ns'] for a,b in zip(power,power[1:])):errors.append('NVML_time_reset_or_reorder')
 if any(r['acquisition_id']!=result.get('same_acquisition_id') for r in power+events):errors.append('mixed_acquisition')
 starts=[e['host_visible_ns'] for e in events if e['event']=='request_start'];drains=[e['host_visible_ns'] for e in events if e['event']=='host_drain_observed']
 if not starts or not drains or not power[0]['query_begin_ns']<starts[0]<drains[0]<power[-1]['arrival_ns']:errors.append('idle_request_return_not_bracketed')
else:errors.append('missing_NVML_capture')
if result.get('terminal_stop_class')!='stop_rule' or result.get('terminal_censored') is not True:errors.append('stop_contract_not_observed')
if (out/'host_events.jsonl').is_file():
 terminal=[e for e in events if e['event']=='engine_terminal']
 if len(terminal)!=1 or terminal[0].get('actual_stop_reason')!='OK' or terminal[0].get('stop_reason_redacted') is not False:errors.append('actual_declared_stop_rule_not_verified')
report={'status':'PASS_VERIFIED_REAL_GPU_HOST_SMOKE' if not errors else 'FAIL','errors':errors,'job_id':json.loads((receipt/'submit.stdout.json').read_text())['data']['job_id'],'runtime':result,'model_input_sha256':hashlib.sha256((ROOT/'MODEL_INPUT.json').read_bytes()).hexdigest(),'previous_attempt_failure_preserved':True,'full_goal_complete':False,'remaining_gates':['multi_session_smoke','instrumentation_AB','device_timing_and_physical_drain','actuator_recovery','DC_PCC','confirmation_statistics']}
(ROOT/f'VERIFIED_REAL_SMOKE_{a.snapshot}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(bool(errors))
