import os,json,time,hashlib
from pathlib import Path
from vllm.v1.core.sched.async_scheduler import AsyncScheduler

def digest(ids):
 return hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()

class AuditedAsyncScheduler(AsyncScheduler):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  path=Path(os.environ['W6_SCHED_AUDIT_PATH'])
  if not path.resolve().is_relative_to(Path(__file__).resolve().parents[3]):
   raise RuntimeError('scheduler_log_outside_workspace')
  self._dot_log=path.open('x');self._dot_step=0
 def update_from_output(self,scheduler_output,model_runner_output):
  before=[]
  for req_id in scheduler_output.num_scheduled_tokens:
   req=self.requests.get(req_id)
   index=model_runner_output.req_id_to_index.get(req_id)
   ids=model_runner_output.sampled_token_ids
   tokens=ids[index] if ids and index is not None else []
   before.append({'request_id':req_id,'present':req is not None,
                  'finished':req.is_finished() if req else None,
                  'sample_count':len(tokens),'sample_token_sha256':digest(tokens)})
  begin=time.monotonic_ns()
  output=super().update_from_output(scheduler_output,model_runner_output)
  emitted=[]
  for batch in output.values():
   for item in batch.outputs:
    ids=item.new_token_ids
    emitted.append({'request_id':item.request_id,'emitted_count':len(ids),
                    'emitted_token_sha256':digest(ids),'finish_reason':str(item.finish_reason)})
  row={'step':self._dot_step,'before':before,'emitted':emitted,
       'host_update_begin_ns':begin,'host_update_return_ns':time.monotonic_ns(),
       'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
  self._dot_log.write(json.dumps(row)+'\n');self._dot_log.flush();self._dot_step+=1
  if self._dot_step>32:raise RuntimeError('scheduler_audit_budget_exceeded')
  return output
