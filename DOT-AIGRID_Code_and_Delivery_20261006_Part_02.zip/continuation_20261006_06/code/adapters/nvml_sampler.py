"""Read-only NVML query-domain sampler, not DC or native sensor timestamps."""
import threading,time,json,hashlib
class NVMLSampler:
 def __init__(self,api,device,path,identity,period_s=.05):
  self.api=api;self.device=device;self.path=path;self.identity=identity;self.period_s=period_s;self.stop_event=threading.Event();self.error=None;self.rows=0;self.thread=None
 def check(self):
  if self.error is not None:raise RuntimeError('NVML_sampling_or_log_failed') from self.error
 def start(self):
  self.stream=self.path.open('x');self.thread=threading.Thread(target=self._run,daemon=True);self.thread.start()
 def _run(self):
  try:
   while not self.stop_event.is_set():
    begin=time.monotonic_ns();raw=self.api.nvmlDeviceGetPowerUsage(self.device);temp=self.api.nvmlDeviceGetTemperature(self.device,0);cap=self.api.nvmlDeviceGetPowerManagementLimit(self.device);arrival=time.monotonic_ns()
    if not isinstance(raw,int) or raw<0:raise ValueError('invalid_NVML_power_mW')
    row={**self.identity,'source':'NVML_API_QUERY_DOMAIN','timestamp_source':'HOST_QUERY_BEGIN_ARRIVAL_NOT_NATIVE_SENSOR_TIME','query_begin_ns':begin,'arrival_ns':arrival,'raw_power_mW':raw,'power_W':raw/1000,'temperature_C':temp,'configured_cap_mW':cap,'requested_period_ns':int(self.period_s*1e9),'status':'ok','device_EOS_ns':None,'DC_boundary':False}
    self.stream.write(json.dumps(row,allow_nan=False)+'\n');self.stream.flush();self.rows+=1
    self.stop_event.wait(max(0,self.period_s-(time.monotonic_ns()-begin)/1e9))
  except BaseException as error:self.error=error;self.stop_event.set()
 def close(self):
  self.stop_event.set()
  if self.thread is not None:
   self.thread.join(timeout=2)
   if self.thread.is_alive():raise RuntimeError('sampler_thread_not_stopped')
  if hasattr(self,'stream'):self.stream.close()
  self.check()
