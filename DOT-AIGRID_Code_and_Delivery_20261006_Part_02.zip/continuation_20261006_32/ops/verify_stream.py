from pathlib import Path
import json,subprocess,sys,argparse
ROOT=Path(__file__).resolve().parents[1]

def validate(rows):
 if not rows:raise ValueError('no_samples')
 for row in rows:
  b=row['runtime_branch']
  if b['all_greedy'] is not True or b['all_random'] is not False:
   raise ValueError('unsupported_sampling_branch')
  if b['sampler_class']!='vllm.v1.sample.sampler.Sampler':raise ValueError('sampler_changed')
  if type(b['stream_before']) is not int or type(b['stream_after']) is not int:
   raise ValueError('invalid_stream_identity')
  if b['stream_before']!=b['stream_after']:raise ValueError('current_stream_changed')
  if b['logits_device']!='cuda:0' or b['sample_device']!=b['logits_device']:
   raise ValueError('device_changed')
 return {'status':'PASS_OBSERVED_GREEDY_BRANCH_CURRENT_STREAM_IDENTITY',
         'samples':len(rows),'source_supported_producer_path':'Pinned PyTorch argmax then dtype conversion',
         'internal_kernel_stream_dependencies':'NOT_INDEPENDENTLY_TRACED',
         'precise_device_EOS_qualified':False,'instrumentation_overhead_qualified':False,
         'full_goal_complete':False}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);args=p.parse_args()
 subprocess.run([sys.executable,str(ROOT/'ops/verify_observation.py'),'--snapshot',args.snapshot],check=True)
 a=ROOT/'artifacts/real_smoke/attempt_001'
 subprocess.run([sys.executable,str(ROOT/'ops/join_scheduler.py'),str(a)],check=True)
 data=json.loads((a/'sample_events.json').read_text())
 if len(data)!=1:raise ValueError('single_worker_required')
 report=validate(data[0]['rows']);out=ROOT/f'VERIFIED_STREAM_{args.snapshot}.json'
 if out.exists():raise FileExistsError(out)
 out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
