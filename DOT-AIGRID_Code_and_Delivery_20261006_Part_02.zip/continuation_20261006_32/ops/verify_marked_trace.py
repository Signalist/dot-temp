from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'artifacts/real_smoke/attempt_001'

def within(event,scope):
 return (event.get('pid')==scope.get('pid') and event.get('tid')==scope.get('tid')
         and scope['ts']<=event.get('ts',-1)
         and event.get('ts',-1)+event.get('dur',0)<=scope['ts']+scope['dur'])

if __name__=='__main__':
 p=A/'cuda_trace.json';events=json.loads(p.read_text())['traceEvents']
 samples=json.loads((A/'sample_events.json').read_text())
 if len(samples)!=1:raise ValueError('single_worker_required')
 rows=[]
 for sample in samples[0]['rows']:
  i=sample['sample_step']
  scopes=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='DOT_SAMPLE_STEP_'+str(i)]
  records=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='DOT_EVENT_RECORD_STEP_'+str(i)]
  if len(scopes)!=1 or len(records)!=1:raise ValueError('missing_or_duplicate_step_marker')
  scope,record=scopes[0],records[0]
  if scope['ts']+scope['dur']>record['ts']:raise ValueError('record_precedes_sample_return')
  ops=[e for e in events if e.get('cat')=='cpu_op' and within(e,scope)]
  arg=[e for e in ops if e['name']=='aten::argmax']
  if len(arg)!=1:raise ValueError('ambiguous_argmax')
  views=[e for e in ops if e['name']=='aten::unsqueeze' and e['ts']>=arg[0]['ts']+arg[0]['dur']]
  if not views:raise ValueError('missing_sample_output_view')
  first_view=min(views,key=lambda e:e['ts'])
  copies=[e for e in ops if e['name']=='aten::copy_' and arg[0]['ts']+arg[0]['dur']<=e['ts']<first_view['ts']]
  if len(copies)!=1:raise ValueError('ambiguous_conversion_copy')
  kernels=[]
  for op in [arg[0],copies[0]]:
   matches=[e for e in events if e.get('cat')=='kernel' and e.get('args',{}).get('External id')==op['args']['External id']]
   if len(matches)!=1:raise ValueError('ambiguous_op_kernel_correlation')
   kernels.append(matches[0])
  ka,kc=kernels
  if 'ArgMaxOps' not in ka['name'] or 'direct_copy_kernel_cuda' not in kc['name']:
   raise ValueError('unexpected_kernel_implementation')
  if ka['args']['stream']!=kc['args']['stream'] or ka['ts']+ka['dur']>kc['ts']:
   raise ValueError('producer_stream_or_order_mismatch')
  api=[e for e in events if 'EventRecord' in e.get('name','') and within(e,record)]
  if len(api)!=1:raise ValueError('event_record_API_not_uniquely_marked')
  if sample['identity_check']!='SAME_RETAINED_TENSOR_POINTER_ON_READ':raise ValueError('missing_tensor_identity_check')
  rows.append({'step':i,'EOS_predicate':sample['sample_is_declared_eos'],
               'CUPTI_stream':kc['args']['stream'],'argmax_correlation':ka['args']['correlation'],
               'conversion_correlation':kc['args']['correlation'],'record_correlation':api[0]['args']['correlation'],
               'tensor_identity_sha256':sample['sample_tensor_identity_sha256']})
 result={'status':'PASS_EXPLICIT_STEP_PRODUCER_AND_EVENT_API_JOIN','rows':rows,
         'trace_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
         'event_API_stream_argument':'NOT_CAPTURED','kernel_output_pointer':'NOT_CAPTURED',
         'clock_mapping':'NOT_QUALIFIED','profiler_overhead':'NOT_QUALIFIED',
         'precise_device_EOS_qualified':False,'full_goal_complete':False}
 out=ROOT/'MARKED_TRACE_AUDIT.json'
 if out.exists():raise FileExistsError(out)
 out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
