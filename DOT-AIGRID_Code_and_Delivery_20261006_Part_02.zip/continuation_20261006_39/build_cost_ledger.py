from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent;DATA=WS/'continuation_20261006_36'
rows=[];sources=[]
def read(p):
 sources.append({'path':str(p.relative_to(WS)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 return json.loads(p.read_text())
for session in ['s1','s2']:
 task='pair_'+session;receipt=DATA/'submissions'/task/'attempt_001';a=DATA/'artifacts'/task/'attempt_001'
 instances=read(receipt/'instances_005.json')
 if not instances['ok'] or len(instances['data'])!=1:raise ValueError('single_verified_instance_required')
 i=instances['data'][0]
 if i['instance_status']!='instance_success':raise ValueError('instance_not_successful')
 created,started,finished=[int(i[k]) for k in ['created_at','started_at','finished_at']]
 if not created<=started<=finished:raise ValueError('platform_timestamp_order')
 platform_ns=(finished-started)*1_000_000
 if int(i['running_time_ms'])*1_000_000!=platform_ns:raise ValueError('platform_duration_inconsistent')
 arms=[]
 for arm in ['A','B']:
  result=read(a/arm/'result.json');timing=read(a/arm/'instrumentation_timing.json')
  if not result['status'].startswith('PASS'):raise ValueError('arm_failure')
  if timing['elapsed_ns']!=timing['end_ns']-timing['begin_ns']:raise ValueError('timing_inconsistent')
  arms.append({'arm':arm,'instrumentation_request_closure_extraction_ns':timing['elapsed_ns'],
               'script_smoke_wall_ns':result['host_wall_duration_ns'],
               'script_wall_scope':'Starts after input/model hashes and GPU inventory; includes engine initialization, idle windows, request, closure, shutdown and final inventory',
               'excluded_before_timer':['Python/import/ABI/source/model integrity checks','Initial GPU/NVML identity setup'],
               'energy_J':None,'boundary':'GPU_ONLY_NVML_QUERY_DOMAIN_NOT_DC_OR_PCC'})
 total=sum(x['script_smoke_wall_ns'] for x in arms)
 if total>platform_ns:raise ValueError('script_intervals_exceed_platform_duration')
 rows.append({'session':session,'arms':arms,'instance_created_to_started_ns':(started-created)*1_000_000,
              'platform_instance_running_ns':platform_ns,'sum_script_smoke_wall_ns':total,
              'unpartitioned_platform_running_minus_script_ns':platform_ns-total,
              'residual_scope':'Unpartitioned startup, pre-timer integrity, parent orchestration and exit/platform reporting; not exclusively initialization or instrumentation overhead'})
report={'status':'PASS_RECONCILED_OBSERVED_COST_SCOPES','rows':rows,'source_bindings':sources,
        'units':'ns for duration; energy remains null without qualified integration/boundary',
        'clock_domains':'Platform epoch-ms durations and process monotonic-ns durations kept distinct',
        'complete_cost_claim':False,'missing':['Data/calibration and solver costs','Instrumented worker CPU costs','Qualified physical energy','Allocation or billing scope beyond reported instance running time'],
        'C04_complete':False,'full_goal_complete':False}
out=ROOT/'COST_SCOPE_LEDGER.json'
if out.exists():raise FileExistsError(out)
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sessions':[{'session':x['session'],'platform_run_s':x['platform_instance_running_ns']/1e9,'script_wall_s':x['sum_script_smoke_wall_ns']/1e9,'unpartitioned_s':x['unpartitioned_platform_running_minus_script_ns']/1e9} for x in rows],'C04_complete':False},indent=2))
