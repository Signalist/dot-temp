from pathlib import Path
from decimal import Decimal,ROUND_FLOOR,ROUND_CEILING
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'artifacts/real_smoke/attempt_001'

def bracket(marker,begin,end):
 lo=Decimal(begin)-Decimal(marker['ts'])*1000
 hi=Decimal(end)-(Decimal(marker['ts'])+Decimal(marker['dur']))*1000
 lo=int(lo.to_integral_value(rounding=ROUND_FLOOR));hi=int(hi.to_integral_value(rounding=ROUND_CEILING))
 if lo>hi:raise ValueError('invalid_marker_enclosure')
 return lo,hi

if __name__=='__main__':
 p=A/'cuda_trace.json';events=json.loads(p.read_text(),parse_float=Decimal)['traceEvents']
 def marker(name):
  x=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')==name]
  if len(x)!=1:raise ValueError('ambiguous_clock_marker')
  return x[0]
 anchors=[];boot=None
 for label in ['START','END']:
  data=json.loads((A/('clock_probe_'+label.lower()+'.json')).read_text())
  if len(data)!=1 or not data[0]['event_complete']:raise ValueError('clock_probe_incomplete')
  d=data[0]
  if boot is not None and boot!=d['boot_id']:raise ValueError('different_boot_clocks')
  boot=d['boot_id'];lo,hi=bracket(marker('DOT_CLOCK_PROBE_'+label),d['host_begin_ns'],d['host_end_ns'])
  anchors.append({'label':label,'lower_ns':lo,'upper_ns':hi})
 lower=max(x['lower_ns'] for x in anchors);upper=min(x['upper_ns'] for x in anchors)
 samples=json.loads((A/'sample_events.json').read_text())
 if len(samples)!=1 or samples[0]['boot_id']!=boot:raise ValueError('sample_clock_mismatch')
 validation=[]
 for d in samples[0]['rows']:
  lo,hi=bracket(marker('DOT_EVENT_RECORD_STEP_'+str(d['sample_step'])),d['host_record_begin_ns'],d['host_record_return_ns'])
  validation.append({'step':d['sample_step'],'lower_ns':lo,'upper_ns':hi,
    'overlaps_anchor_interval':lower<=upper and max(lo,lower)<=min(hi,upper),
    'contains_entire_anchor_interval':lo<=lower<=upper<=hi})
 result={'status':'OBSERVED_ANCHOR_VALIDATION_CONSISTENCY' if lower<=upper and all(x['overlaps_anchor_interval'] for x in validation) else 'CLOCK_CANDIDATE_INCONSISTENT',
         'anchors':anchors,'anchor_lower_ns':lower,'anchor_upper_ns':upper,'anchor_width_ns':upper-lower,
         'sample_markers_used_to_fit':False,'validation':validation,
         'assumption':'Unit-slope constant CPU trace to host offset for this acquisition',
         'independent_acquisition_validation':'NOT_RUN','CUPTI_GPU_CPU_accuracy':'NOT_QUALIFIED',
         'continuous_drift_bound':'NOT_QUALIFIED','profiler_overhead':'NOT_QUALIFIED',
         'precise_device_EOS_qualified':False,'full_goal_complete':False,
         'trace_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 out=ROOT/'CLOCK_PROBE_VALIDATION.json'
 if out.exists():raise FileExistsError(out)
 out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
