"""NVML-reported energy; sensor boundary/bandwidth remain unqualified."""
import json,time
from .nvml_sampler import NVMLSampler

class PilotMeter:
 def __init__(self,api,device,out,identity,periodic):
  self.api=api;self.device=device;self.out=out;self.identity=identity;self.periodic=periodic;self.marks=[]
  self.inner=NVMLSampler(api,device,out/'nvml.jsonl',identity) if periodic else None
 @property
 def rows(self):return self.inner.rows if self.inner else 0
 def start(self):
  if self.inner:self.inner.start()
 def check(self):
  if self.inner:self.inner.check()
 def mark(self,label):
  begin=time.monotonic_ns();value=None;error=None
  try:
   value=self.api.nvmlDeviceGetTotalEnergyConsumption(self.device)
   if type(value) is not int or value<0:raise ValueError('invalid_energy_counter')
  except self.api.NVMLError as e:error=type(e).__name__
  self.marks.append({**self.identity,'label':label,'query_begin_ns':begin,'arrival_ns':time.monotonic_ns(),'energy_mJ':value,'error_type':error,'unit':'mJ','boundary':'NVML_GPU_REPORTED_NOT_EXTERNAL_DC_OR_ALL_RAILS','native_sensor_timestamp':None,'counter_unit_quantum_mJ':1,'accuracy_and_update_bandwidth':'NOT_CALIBRATED'})
 def close(self):
  try:
   if self.inner:self.inner.close()
  finally:(self.out/'energy_counter.json').write_text(json.dumps(self.marks,indent=2)+'\n')
