"""Descriptive host timing; unknown token emission times remain unknown."""
def summarize(events,marks,begin,end):
 start=[x for x in events if x['event']=='request_start']
 terminal=[x for x in events if x['event']=='engine_terminal']
 progress=[x for x in events if x['event'] in ['host_progress','engine_terminal'] and x['new_tokens']>0]
 if len(start)!=1 or len(terminal)!=1 or not progress:raise ValueError('missing_or_ambiguous_request')
 t=terminal[0];n=t['completed_tokens'];times=[x['engine_visible_ns'] for x in progress]
 itl=[(b-a)/1e6 for a,b in zip(times,times[1:])] if all(x['new_tokens']==1 for x in progress) else None
 m={x['label']:x for x in marks}
 def energy(a,b):
  x,y=m[a],m[b]
  if x['energy_mJ'] is None or y['energy_mJ'] is None:return None
  if y['energy_mJ']<x['energy_mJ']:raise ValueError('counter_reset_or_rollover')
  return (y['energy_mJ']-x['energy_mJ'])/1000
 return {'cycle_energy_J':energy('cycle_start','cycle_end'),'request_recovery_energy_J':energy('request_recovery_start','request_recovery_end'),
  'cycle_latency_ms':(m['cycle_end']['arrival_ns']-m['cycle_start']['query_begin_ns'])/1e6,
  'script_observed_wall_ms':(end-begin)/1e6,'request_e2e_ms':(t['engine_visible_ns']-start[0]['host_visible_ns'])/1e6,
  'TTFT_ms':(times[0]-start[0]['host_visible_ns'])/1e6,'TPOT_ms':(times[-1]-times[0])/1e6/(n-1) if n>1 else None,
  'ITL_ms':itl,'token_batching_observed':any(x['new_tokens']!=1 for x in progress),'completed_tokens':n,
  'stop_class':t['stop_class'],'generated_token_sha256':t['generated_token_sha256'],'censored':t['censored'],
  'energy_boundary':'NVML_GPU_REPORTED_ONLY','recovery_scope':'POST_DRAIN_SYNC_SHUTDOWN_NOT_PHYSICAL_INITIAL_STATE_CERTIFICATE',
  'service_scope':'FIRST_REQUEST_IN_FRESH_ENGINE_INCLUDES_FIRST_REQUEST_COMPILATION','EOS_counted_in_tokens':True,
  'J_W6':None,'acceptability_decision':None,'device_EOS_time_qualified':False}
