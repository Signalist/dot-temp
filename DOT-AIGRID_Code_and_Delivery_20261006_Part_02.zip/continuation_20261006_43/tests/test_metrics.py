import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.pilot_metrics import summarize
class Metrics(unittest.TestCase):
 def data(self):
  events=[{'event':'request_start','host_visible_ns':0}, {'event':'host_progress','engine_visible_ns':1000000,'new_tokens':1}, {'event':'engine_terminal','engine_visible_ns':3000000,'new_tokens':1,'completed_tokens':2,'stop_class':'natural_eos_token_host_verified','generated_token_sha256':'a','censored':False}]
  marks=[{'label':k,'query_begin_ns':i*1000000,'arrival_ns':i*1000000+10,'energy_mJ':1000+i*100} for i,k in enumerate(['cycle_start','request_recovery_start','request_recovery_end','cycle_end'])]
  return events,marks
 def test_units_and_common_cost(self):
  e,m=self.data();r=summarize(e,m,0,4000000)
  self.assertEqual(r['cycle_energy_J'],.3);self.assertEqual(r['TTFT_ms'],1);self.assertEqual(r['TPOT_ms'],2);self.assertEqual(r['ITL_ms'],[2]);self.assertIsNone(r['J_W6'])
 def test_missing_energy_not_imputed(self):
  e,m=self.data();m[-1]['energy_mJ']=None;self.assertIsNone(summarize(e,m,0,4)['cycle_energy_J'])
 def test_counter_reset_rejected(self):
  e,m=self.data();m[-1]['energy_mJ']=0
  with self.assertRaises(ValueError):summarize(e,m,0,4)
 def test_batched_tokens_no_fake_itl(self):
  e,m=self.data();e[-1]['new_tokens']=2;self.assertIsNone(summarize(e,m,0,4)['ITL_ms'])
if __name__=='__main__':unittest.main()
