# DOT-AIGRID 工作区

用户授权的可写范围仅为本目录及其子目录（包括 tunnel 别名所指向的同一实际目录）。其他目录只读；不修改其他项目、全局配置或文件权限。平台 qzcli 必需的自身提交状态记录是已授权 GPU 调度的一部分；避免额外目录写入。

临时文件、缓存、测试输出与新证据必须置于本工作区。不 commit/push。原始 ZIP、source_package、source_plan 与已封存 raw 保持字节不变。旧 DOT-GFM 路径在历史回执中保留，通过 WORKSPACE_PATH_MIGRATION.json 解析；可执行入口和当前配置必须使用 DOT-AIGRID。

qzcli GPU 提交和独立任务并行已获授权；真实 cap/burn/DC/PCC 仍按 W6 具体设备/动作/安全准入合同取得批准。任务提交成功不等于实际执行成功，必须检查实例、日志和落盘。
