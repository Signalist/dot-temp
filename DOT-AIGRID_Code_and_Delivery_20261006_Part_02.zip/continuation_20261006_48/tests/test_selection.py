from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from resident import select,length_bin
class Selection(unittest.TestCase):
 def test_bins(self):
  self.assertEqual(length_bin(100),'short');self.assertEqual(length_bin(384),'medium');self.assertEqual(length_bin(1024),'long');self.assertEqual(length_bin(1536),'outside_reference_bins')
 def test_domain_length_not_gain(self):
  tasks={};screen=[]
  for domain in ['writing','code','reasoning']:
   for index,n in enumerate([100,380,1020]):
    key=domain+str(index);tasks[key]={'domain':domain};screen.append({'task_id':key,'useful_tokens':n,'actual_length_bin':length_bin(n),'censored':False,'cycle_energy_J':-999 if index==0 else 999})
  self.assertEqual(select(screen,tasks),['writing0','code1','reasoning2'])
 def test_natural_preferred_capped_not_eos(self):
  tasks={};screen=[]
  for domain in ['writing','code','reasoning']:
   for key,n,c in [('natural',100,False),('capped',1536,True)]:
    k=domain+key;tasks[k]={'domain':domain};screen.append({'task_id':k,'useful_tokens':n,'actual_length_bin':length_bin(n),'censored':c})
  self.assertEqual(select(screen,tasks),['writingnatural','codenatural','reasoningnatural'])
if __name__=='__main__':unittest.main()
