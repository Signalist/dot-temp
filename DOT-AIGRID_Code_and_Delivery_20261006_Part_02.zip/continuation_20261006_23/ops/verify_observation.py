"""Verify measured event occurrence bounds without upgrading EOS qualification."""
from pathlib import Path
import argparse,json,subprocess,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]

def validate(events,binding,closure,host):
    if len(events)!=1 or len(binding)!=1:raise ValueError('single_request_worker_required')
    s=events[0];b=binding[0];rows=s['rows']
    if not rows or len(rows)>32:raise ValueError('invalid_step_budget')
    if s['boot_id']!=closure['worker_ack']['boot_id']:raise ValueError('different_boot_clocks')
    terminal=[x for x in host if x['event']=='engine_terminal']
    if len(terminal)!=1 or terminal[0]['request_id']!=b['external_request_id']:
        raise ValueError('missing_exact_host_binding')
    if terminal[0]['stop_class']!='natural_eos_token_host_verified':raise ValueError('missing_host_EOS_evidence')
    eos=[]
    for i,r in enumerate(rows):
        if r['sample_step']!=i or r['request_id']!=b['internal_request_id']:
            raise ValueError('mixed_step_or_request')
        times=[r[k] for k in ('host_record_begin_ns','host_record_return_ns','host_sync_begin_ns','host_completion_observed_ns')]
        if any(type(t) is not int for t in times) or times!=sorted(times):
            raise ValueError('invalid_monotonic_interval')
        if r['event_observation_interval_ns']!=[times[0],times[-1]] or r['event_complete'] is not True:
            raise ValueError('missing_measured_completion')
        if r['sample_is_declared_eos'] is True:eos.append(i)
    if not eos:raise ValueError('missing_device_sample_EOS_predicate')
    if s['device_EOS_ns'] is not None:raise ValueError('unexpected_qualified_EOS_timestamp')
    return {'status':'PASS_MEASURED_CURRENT_STREAM_EVENT_OCCURRENCE_BOUNDS',
            'steps':len(rows),'EOS_predicate_steps':eos,
            'interval_widths_ns':[r['host_completion_observed_ns']-r['host_record_begin_ns'] for r in rows],
            'precise_device_EOS_qualified':False,'scheduler_acceptance_qualified':False,
            'cross_stream_dependencies_qualified':False,'instrumentation_overhead_qualified':False,
            'full_goal_complete':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);args=p.parse_args()
    subprocess.run([sys.executable,str(ROOT/'ops/verify_closure.py'),'--snapshot',args.snapshot],check=True)
    a=ROOT/'artifacts/real_smoke/attempt_001'
    load=lambda n:json.loads((a/n).read_text())
    report=validate(load('sample_events.json'),load('request_bindings.json'),load('closure_ack.json'),
                    [json.loads(x) for x in (a/'host_events.jsonl').read_text().splitlines()])
    target=ROOT/f'VERIFIED_OBSERVATION_{args.snapshot}.json'
    if target.exists():raise FileExistsError(target)
    report['files']=[{'path':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
                     for f in sorted(a.iterdir()) if f.is_file()]
    target.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
