from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent
payload={}
def add(p):
 payload[str(p.relative_to(WS))]=p.read_bytes()
excluded={'cache','hf','torch','triton','vllm','__pycache__'}
for n in range(11,33):
 r=WS/f'continuation_20261006_{n:02d}'
 for folder in ['code','tests','ops']:
  for p in (r/folder).rglob('*.py'):add(p)
 for p in r.iterdir():
  if p.is_file() and p.suffix in ['.json','.txt','.csv']:add(p)
 for p in (r/'03_calibration').rglob('*'):
  if p.is_file() and p.suffix in ['.json','.jsonl','.csv','.txt']:add(p)
 for p in (r/'artifacts').rglob('*'):
  rel=p.relative_to(r/'artifacts')
  if p.is_file() and (not excluded.intersection(rel.parts) or 'installed_source' in rel.parts) and p.suffix in ['.json','.jsonl','.txt','.py']:
   add(p)
 for attempt in (r/'submissions').glob('*/*'):
  if not attempt.is_dir():continue
  for name in ['source_freeze.json','launch.json','failure.json']:
   p=attempt/name
   if p.exists():add(p)
  snapshots={}
  for p in sorted(attempt.glob('detail_*.json')):
   d=json.loads(p.read_text());data=d.get('data') or {}
   snapshots[p.name]={'ok':d.get('ok'),'status':data.get('status'),'error':d.get('error') if not d.get('ok') else None}
  for p in sorted(attempt.glob('instances_*.json')):
   d=json.loads(p.read_text());data=d.get('data') or []
   snapshots[p.name]={'ok':d.get('ok'),'instances':[{'status':x.get('instance_status')} for x in data] if isinstance(data,list) else []}
  for p in sorted(attempt.glob('logs_*.json')):
   d=json.loads(p.read_text());messages=[x.get('message','') for x in (d.get('data') or {}).get('logs',[])]
   snapshots[p.name]={'ok':d.get('ok'),'exit_messages':[m for m in messages if 'exit code' in m.lower() or 'exitcode' in m.lower()]}
  p=attempt/'submit.stdout.json'
  if p.exists():
   d=json.loads(p.read_text());snapshots['submission']={'ok':d.get('ok'),'job_id':(d.get('data') or {}).get('job_id'),'error':d.get('error') if not d.get('ok') else None}
  payload[str((attempt/'SANITIZED_PLATFORM.json').relative_to(WS))]=(json.dumps(snapshots,indent=2)+'\n').encode()
note={'kind':'Supplement after v3, not full final W6 results','scope':'continuations 11 through 32; prior attempts remain in v3 and original archives',
      'prerequisites':['W6_GPU_Results_Audit_20261006_v3.zip','Original W6 source and plan packages'],
      'all_small_projects_complete':False,'physical_DC_PCC_qualified':False,'device_EOS_qualified':False,
      'security':'No model weights, caches or full platform detail profiles; sanitized status/exit receipts only',
      'instructions':'Unpack ordinary ZIP into an isolated directory. Offline validation never submits or starts acquisition.'}
payload['DELTA_README.json']=(json.dumps(note,indent=2)+'\n').encode()
manifest=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(payload.items())]
payload['DELTA_PAYLOAD_MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=ROOT/'W6_GPU_Audit_Supplement_11_32_v2.zip'
if target.exists():raise FileExistsError(target)
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(payload.items()):z.writestr(name,data)
assert target.stat().st_size<18_000_000
fresh=ROOT/'fresh_unpack_v2';fresh.mkdir()
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for name in z.namelist():
  if not (fresh/name).resolve().is_relative_to(fresh.resolve()):raise ValueError('unsafe_archive_path')
 z.extractall(fresh)
for row in manifest:
 p=fresh/row['path'];assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
receipt={'status':'PASS_ZIP_CRC_AND_FRESH_UNPACK_HASHES','files':len(manifest),'bytes':target.stat().st_size,
         'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'zip':target.name,'full_goal_complete':False}
(ROOT/'DELIVERY_RECEIPT_v2.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
