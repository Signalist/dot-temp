def join(worker,scheduler,binding,natural):
 req=binding['internal_request_id'];inputs=[]
 for row in scheduler:
  if row['boot_id']!=worker['boot_id']:raise ValueError('scheduler_worker_clock_mismatch')
  for item in row['before']:
   if item['request_id']!=req or item['sample_count']!=1:raise ValueError('unexpected_scheduler_sample')
   inputs.append((row,item))
 if len(inputs)!=len(worker['rows']):raise ValueError('missing_worker_scheduler_steps')
 rows=[]
 for sample,(row,item) in zip(worker['rows'],inputs):
  if sample['request_id']!=req or sample['sample_token_sha256']!=item['sample_token_sha256']:raise ValueError('tensor_hash_or_request_mismatch')
  emitted=[x for x in row['emitted'] if x['request_id']==req and x['emitted_count']]
  if len(emitted)>1 or emitted and (emitted[0]['emitted_count']!=1 or emitted[0]['emitted_token_sha256']!=item['sample_token_sha256']):raise ValueError('emitted_hash_mismatch')
  rows.append({'sample_step':sample['sample_step'],'EOS_predicate':sample['sample_is_declared_eos'],'emitted':bool(emitted),'present':item['present']})
 accepted=[x for x in rows if x['EOS_predicate'] and x['emitted']]
 if natural and len(accepted)!=1:raise ValueError('natural_EOS_attribution_missing_or_ambiguous')
 return {'status':'PASS_EXACT_ORDERED_RESIDENT_SAMPLE_JOIN','rows':rows,'accepted_EOS_step':accepted[0]['sample_step'] if len(accepted)==1 else None,'natural_completion':natural,'device_EOS_time_qualified':False,'physical_completion_certified':False}
