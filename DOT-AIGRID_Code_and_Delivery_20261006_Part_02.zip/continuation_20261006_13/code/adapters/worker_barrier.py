"""Candidate single-process GPU barrier; live qualification required before use.

No resume operation exists. Successful closure never certifies device EOS time,
DC/PCC or physical safety. Callables run only after explicit source qualification.
"""
import asyncio,time
from pathlib import Path
class BarrierError(RuntimeError):pass

def synchronize_worker(worker):
 # Executed by the model-owning worker through verified collective RPC only.
 import torch
 device=worker.device
 if device.type!='cuda' or torch.cuda.device_count()!=1:raise BarrierError('single_cuda_worker_required')
 begin=time.monotonic_ns();torch.cuda.synchronize(device);end=time.monotonic_ns()
 return {'cuda_all_stream_sync_ack':True,'worker_query_begin_ns':begin,'worker_return_ns':end,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'device':str(device),'semantics':'POST_DRAIN_SYNC_BOUND_NOT_DEVICE_EOS'}

class ClosureGate:
 def __init__(self,engine,sink,*,source_qualified=False,timeout_s=10,boot_id=None):
  if not 0<timeout_s<=30:raise BarrierError('invalid_timeout')
  self.engine=engine;self.sink=sink;self.source_qualified=source_qualified;self.timeout_s=timeout_s;self.boot_id=boot_id or Path('/proc/sys/kernel/random/boot_id').read_text().strip();self.state='ADMISSION_CLOSED';self.busy=False
 async def close(self):
  if self.state!='ADMISSION_CLOSED' or self.busy:raise BarrierError('closure_already_attempted_or_busy')
  self.busy=True;self.state='CLOSING'
  try:
   if not self.source_qualified:raise BarrierError('RPC_source_and_executor_not_qualified')
   async with asyncio.timeout(self.timeout_s):
    # abort clears all scheduler request states, including waiting requests;
    # wait/keep can hide waiting work and are deliberately not used here.
    await self.engine.pause_generation(mode='abort',clear_cache=False)
    if await self.engine.is_paused() is not True:raise BarrierError('scheduler_pause_not_acknowledged')
    states=getattr(getattr(self.engine,'output_processor',None),'request_states',None)
    if not isinstance(states,dict) or states:raise BarrierError('frontend_requests_not_empty')
    issue=time.monotonic_ns()
    rows=await self.engine.collective_rpc(synchronize_worker,timeout=self.timeout_s)
    returned=time.monotonic_ns()
    if not isinstance(rows,list) or len(rows)!=1:raise BarrierError('single_worker_ack_required')
    row=rows[0]
    if row.get('cuda_all_stream_sync_ack') is not True or row.get('boot_id')!=self.boot_id or row.get('semantics')!='POST_DRAIN_SYNC_BOUND_NOT_DEVICE_EOS':raise BarrierError('unqualified_worker_ack')
    a=row.get('worker_query_begin_ns');b=row.get('worker_return_ns')
    if type(a) is not int or type(b) is not int or not issue<=a<=b<=returned:raise BarrierError('worker_clock_domain_or_order_unknown')
    if await self.engine.is_paused() is not True or self.engine.output_processor.request_states:raise BarrierError('pause_or_frontend_changed_after_sync')
    result={'event':'closure_candidate_ack','scheduler_pause_mode':'abort','frontend_request_states':0,'worker_ack':row,'controller_issue_ns':issue,'controller_return_ns':returned,'device_EOS_ns':None,'next_request_admitted':False,'physical_safety_certified':False}
    self.sink(result);self.state='CLOSED_NO_RESUME';return result
  except BaseException:
   self.state='BLOCKED_NO_RESUME';raise
  finally:self.busy=False

class PrivateSessionAdmission:
 """Single-controller admission wrapper; external clients are unsupported.

All generation and closure operations must use this owner. It cannot certify
exclusive hardware access or constrain callers who bypass the owner.
 """
 def __init__(self,closure):self.closure=closure;self.state='OPEN';self.busy=False
 async def run(self,operation):
  if self.state!='OPEN' or self.busy:raise BarrierError('request_admission_denied')
  self.busy=True
  try:return await operation()
  except BaseException:self.state='BLOCKED';raise
  finally:self.busy=False
 async def close(self):
  if self.busy:raise BarrierError('inflight_request_must_terminate_before_closure')
  if self.state=='CLOSED':raise BarrierError('admission_already_closed')
  self.state='CLOSED'
  return await self.closure.close()
