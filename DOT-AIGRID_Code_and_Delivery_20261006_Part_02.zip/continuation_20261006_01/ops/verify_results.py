from pathlib import Path
import json,hashlib,datetime,re
ROOT=Path(__file__).resolve().parents[1];checks=[]
for task in ['engine_abi','integration']:
 receipt=ROOT/'submissions'/task/'attempt_002';output=ROOT/'artifacts'/task/'attempt_002';job=json.loads((receipt/'submit.stdout.json').read_text())['data']['job_id'];detail=json.loads((receipt/'detail_002.json').read_text());instances=json.loads((receipt/'instances_002.json').read_text());logs=json.loads((receipt/'logs_002.json').read_text());result=json.loads((output/'result.json').read_text())
 errs=[]
 if detail.get('data',{}).get('status')!='job_succeeded':errs.append('platform_not_success')
 if not any(x.get('instance_status')=='instance_success' for x in instances.get('data',[])):errs.append('instance_not_success')
 if not any('exit code 0' in x.get('message','') for x in logs.get('data',{}).get('logs',[])):errs.append('no_exit_zero_log')
 if not result['status'].startswith('PASS'):errs.append('artifact_not_pass')
 manifest=json.loads((receipt/'source_freeze.json').read_text())
 for row in manifest['files']:
  if hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()!=row['sha256']:errs.append('source_changed:'+row['path'])
 for c in ['GPU_requests','cap_writes']:
  if result[c]!=0:errs.append('unapproved_hardware_activity')
 if task=='integration':
  text=(output/'host_bridge_tests.stderr.txt').read_text()
  if not re.search(r'Ran 16 tests',text) or not text.strip().endswith('OK'):errs.append('test_scope_not_16_passing')
 checks.append({'task':task,'job_id':job,'status':'PASS' if not errs else 'FAIL','verified_sources':len(manifest['files']),'artifact_status':result['status'],'artifact_path':str((output/'result.json').relative_to(ROOT)),'artifact_sha256':hashlib.sha256((output/'result.json').read_bytes()).hexdigest(),'errors':errs})
report={'schema_version':'w6-recovery-1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'software_resubmission_status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'all_small_projects_complete':False,'full_goal_status':'ACTIVE_INCOMPLETE','physical_validation':'NOT_RUN','real_model_requests':0,'physical_cap_writes':0,'remaining_full_requirements':'COMPLETE_SCOPE_AUDIT.json','operator_confirmation':'UNCONFIRMED','scope_confirmation':'PENDING_USER_RESPONSE'}
(ROOT/'VERIFIED_RESUBMISSION_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(report['software_resubmission_status']!='PASS')
