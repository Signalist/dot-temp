from pathlib import Path
import sys,subprocess,json,os,hashlib
ROOT=Path(__file__).resolve().parents[1]
from source_guard import check
check(ROOT,sys.argv[2])
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(out),MPLCONFIGDIR=str(out/'mpl'),XDG_CACHE_HOME=str(out/'cache'))
checks=[]
for name,argv,expected in [('host_bridge_tests',[sys.executable,'-m','unittest','discover','-s',str(ROOT/'tests'),'-v'],0),('sealed_delivery_integrity',[sys.executable,str(ROOT.parent/'W6_Experiment_Results_20261005_cpu_audit_01/02_code/verify_delivery.py'),'--root',str(ROOT.parent/'W6_Experiment_Results_20261005_cpu_audit_01')],0)]:
 r=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=180);(out/(name+'.stdout.txt')).write_text(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr);checks.append({'check':name,'exit_code':r.returncode,'expected':expected})
result={'status':'PASS_CPU_INTEGRATION' if all(x['exit_code']==x['expected'] for x in checks) else 'FAIL','evidence':'CPU_TEST','GPU_requests':0,'cap_writes':0,'checks':checks,'physical_W6_admission':'NOT_RUN'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(result['status']!='PASS_CPU_INTEGRATION')
