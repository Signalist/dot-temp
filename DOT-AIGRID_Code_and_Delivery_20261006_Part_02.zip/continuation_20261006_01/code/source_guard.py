"""Verify whole submitted source set; a SHA is consistency, not human approval."""
from pathlib import Path,PurePosixPath
import json,hashlib

def check(root,receipt):
 root=Path(root).resolve();manifest=json.loads(Path(receipt).read_text())
 for row in manifest['files']:
  q=PurePosixPath(row['path'])
  if q.is_absolute() or '..' in q.parts or '\\' in row['path']:raise RuntimeError('unsafe_source_path')
  f=root/q
  if f.is_symlink() or not f.resolve().is_relative_to(root) or hashlib.sha256(f.read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('submitted_source_changed:'+row['path'])
 return manifest
