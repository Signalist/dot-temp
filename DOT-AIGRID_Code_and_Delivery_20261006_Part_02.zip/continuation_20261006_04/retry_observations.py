from pathlib import Path
import os,subprocess,json,hashlib,time
ROOT=Path(__file__).resolve().parent
report=json.loads((ROOT/'ALL_SUBMISSIONS_RECONCILED.json').read_text());env=dict(os.environ)
for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(k,None)
out=ROOT/'platform_retry_001';out.mkdir(exist_ok=False)
for row in report['all_known_workspace_jobs']:
 row['observation_failure_history']=list(row['errors'])
 for error in list(row['errors']):
  cmd=error.split(':')[0];id=row['job_id'];time.sleep(1)
  r=subprocess.run(['qzcli',cmd,id],env=env,capture_output=True,text=True,timeout=45);p=out/(id+'_'+cmd+'.json');p.write_text(r.stdout);d=json.loads(r.stdout)
  if r.returncode or not d.get('ok'):continue
  data=d['data'];row['errors'].remove(error);row[cmd+'_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();row[cmd+'_latest_receipt']=str(p.relative_to(ROOT))
  if cmd=='detail':row['platform_status']=data.get('status');row['dataset_count']=len(data.get('dataset_info',[]))
  elif cmd=='instances':row['instance_statuses']=[x.get('instance_status') for x in data]
  else:
   messages=[x.get('message','') for x in (data or {}).get('logs',[])];row['exit_zero_evidence']=any('exit code 0' in x for x in messages);row['python_missing_evidence']=any('python: not found' in x or 'python: command not found' in x for x in messages);row['log_count']=len(messages)
counts={}
for row in report['all_known_workspace_jobs']:counts[row.get('platform_status','UNKNOWN')]=counts.get(row.get('platform_status','UNKNOWN'),0)+1
report['counts']=counts;report['live_jobs']=[r['job_id'] for r in report['all_known_workspace_jobs'] if r.get('platform_status') in {'job_queuing','job_running','job_success_reserving'}];report['unknown_observation_jobs']=[r['job_id'] for r in report['all_known_workspace_jobs'] if 'platform_status' not in r]
report['rate_limit_repair']='Retried only failed observations sequentially with spacing; no jobs restarted or newly submitted.'
(ROOT/'ALL_SUBMISSIONS_RECONCILED_FINAL.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'counts':counts,'live_jobs':report['live_jobs'],'unresolved_observation_errors':sum(len(r['errors']) for r in report['all_known_workspace_jobs'])},indent=2))
