from pathlib import Path
import json,os,subprocess,hashlib,datetime,concurrent.futures
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent
roots=[WS/'qz_submissions',*[WS/f'continuation_20261006_{n:02d}/submissions' for n in [1,2,3]]]
jobs={}
for root in roots:
 for p in root.rglob('*.json'):
  if 'submit' not in p.name:continue
  try:
   d=json.loads(p.read_text());id=d.get('data',{}).get('job_id')
   if id:jobs[id]=str(p.relative_to(WS))
  except (ValueError,AttributeError):pass
env=dict(os.environ)
for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(k,None)
out=ROOT/'platform_snapshot';out.mkdir(exist_ok=False)
def fetch(pair):
 id,receipt=pair;row={'job_id':id,'submit_receipt':receipt,'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'errors':[]}
 for cmd in ['detail','instances','logs']:
  r=subprocess.run(['qzcli',cmd,id],env=env,capture_output=True,text=True,timeout=45);p=out/(id+'_'+cmd+'.json');p.write_text(r.stdout);(out/(id+'_'+cmd+'.stderr.txt')).write_text(r.stderr)
  try:d=json.loads(r.stdout)
  except ValueError:row['errors'].append(cmd+':invalid_json');continue
  if r.returncode or not d.get('ok'):row['errors'].append(cmd+':platform_observation_failed');continue
  data=d.get('data')
  if cmd=='detail':row['platform_status']=data.get('status');row['dataset_count']=len(data.get('dataset_info',[]))
  elif cmd=='instances':row['instance_statuses']=[x.get('instance_status') for x in data]
  else:
   messages=[x.get('message','') for x in (data or {}).get('logs',[])]
   row['exit_zero_evidence']=any('exit code 0' in x for x in messages);row['python_missing_evidence']=any('python: not found' in x or 'python: command not found' in x for x in messages);row['log_count']=len(messages)
  row[cmd+'_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(fetch,sorted(jobs.items())))
counts={}
for row in rows:counts[row.get('platform_status','UNKNOWN')]=counts.get(row.get('platform_status','UNKNOWN'),0)+1
report={'schema_version':'w6-reconciliation-2','goal_complete':False,'all_known_workspace_jobs':rows,'counts':counts,'live_jobs':[r['job_id'] for r in rows if r.get('platform_status') in {'job_queuing','job_running','job_success_reserving'}],'interpretation':'Software-only jobs and inventory, not completed W6 physical experiments. Observation errors do not justify resubmission.'}
(ROOT/'ALL_SUBMISSIONS_RECONCILED.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'counts':counts,'live_jobs':report['live_jobs'],'observation_errors':sum(len(r['errors']) for r in rows)},indent=2))
