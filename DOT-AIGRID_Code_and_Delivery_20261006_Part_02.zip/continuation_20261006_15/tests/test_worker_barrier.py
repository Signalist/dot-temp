import unittest,sys,time
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.worker_barrier import ClosureGate,BarrierError
class Fake:
 def __init__(self,nonempty=False,bad_boot=False,sinkfail=False):self.output_processor=NS(request_states={'r':1} if nonempty else {});self.calls=[];self.paused=False;self.bad_boot=bad_boot
 async def pause_generation(self,**kwargs):self.calls.append(('pause',kwargs));self.paused=True
 async def is_paused(self):self.calls.append(('paused',));return self.paused
 async def collective_rpc(self,method,timeout):
  self.calls.append(('rpc',));t=time.monotonic_ns();return [{'cuda_all_stream_sync_ack':True,'worker_query_begin_ns':t,'worker_return_ns':t,'boot_id':'wrong' if self.bad_boot else 'CPU_TEST','device':'cuda:0','semantics':'POST_DRAIN_SYNC_BOUND_NOT_DEVICE_EOS'}]
class ClosureTests(unittest.IsolatedAsyncioTestCase):
 async def test_unqualified_source_zero_calls(self):
  e=Fake();g=ClosureGate(e,lambda x:None,boot_id='CPU_TEST')
  with self.assertRaises(BarrierError):await g.close()
  self.assertEqual(e.calls,[]);self.assertEqual(g.state,'BLOCKED_NO_RESUME')
 async def test_order_and_no_resume(self):
  e=Fake();out=[];g=ClosureGate(e,out.append,source_qualified=True,boot_id='CPU_TEST');r=await g.close();self.assertEqual(e.calls[0],('pause',{'mode':'abort','clear_cache':False}));self.assertFalse(r['next_request_admitted']);self.assertIsNone(r['device_EOS_ns'])
  with self.assertRaises(BarrierError):await g.close()
 async def test_nonempty_frontend_prevents_RPC(self):
  e=Fake(nonempty=True);g=ClosureGate(e,lambda x:None,source_qualified=True,boot_id='CPU_TEST')
  with self.assertRaises(BarrierError):await g.close()
  self.assertFalse(any(c[0]=='rpc' for c in e.calls))
 async def test_clock_boot_mismatch_latches(self):
  g=ClosureGate(Fake(bad_boot=True),lambda x:None,source_qualified=True,boot_id='CPU_TEST')
  with self.assertRaises(BarrierError):await g.close()
  self.assertEqual(g.state,'BLOCKED_NO_RESUME')
 async def test_sink_failure_latches(self):
  g=ClosureGate(Fake(),lambda x:(_ for _ in ()).throw(OSError('CPU_TEST_disk_full')),source_qualified=True,boot_id='CPU_TEST')
  with self.assertRaises(OSError):await g.close()
  self.assertEqual(g.state,'BLOCKED_NO_RESUME')
from adapters.worker_barrier import PrivateSessionAdmission
class AdmissionTests(unittest.IsolatedAsyncioTestCase):
 async def test_closed_owner_rejects_new_request_without_call(self):
  owner=PrivateSessionAdmission(ClosureGate(Fake(),lambda x:None,source_qualified=True,boot_id='CPU_TEST'));await owner.close();calls=[]
  async def operation():calls.append(1)
  with self.assertRaises(BarrierError):await owner.run(operation)
  self.assertEqual(calls,[])
 async def test_request_failure_blocks_next(self):
  owner=PrivateSessionAdmission(ClosureGate(Fake(),lambda x:None,source_qualified=True,boot_id='CPU_TEST'))
  async def failure():raise RuntimeError('CPU_TEST_request_error')
  with self.assertRaises(RuntimeError):await owner.run(failure)
  with self.assertRaises(BarrierError):await owner.run(failure)
  self.assertEqual(owner.state,'BLOCKED')
 async def test_closure_cannot_race_inflight_request(self):
  owner=PrivateSessionAdmission(ClosureGate(Fake(),lambda x:None,source_qualified=True,boot_id='CPU_TEST'))
  async def operation():
   with self.assertRaises(BarrierError):await owner.close()
   self.assertEqual(owner.state,'OPEN')
  await owner.run(operation)
