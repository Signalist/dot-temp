from adapters.worker_barrier import synchronize_worker
class DOTWorkerExtension:
 def dot_sync_after_pause(self):return synchronize_worker(self)
