# DOT-AIGRID 代码与累计阶段交付

本包按用户最新要求封装为一个普通ZIP，放在DOT-AIGRID根目录；累计包可超过原分包18MB上限，内含各个原普通ZIP，不使用二进制分卷。

阅读顺序：
1. delivery/GPU_ONLY_Estimation_20261006/REPORT_ZH.md：本轮GPU_ONLY固定任务估计、质量失败及限制。
2. 同目录DELIVERY_INDEX.json、OFFLINE_VALIDATION.json、FINAL_COMPLETION_CHECK.json：当前结果与复算证据。
3. 同目录GPU_ONLY_Fixed_Task_Estimation_v2.zip：本轮完整代码/协议/原始及派生数据；请解压v2，不使用已淘汰v1。
4. continuation_20261006_50/DELIVERY_INDEX.json与README_ZH.md：历史补充包索引及原W6剩余条件。
5. delivery/PARTS.json及01_review.zip、02_code.zip、03_network.zip：初始CPU/源审计与复算交付。

修改后的代码直接保留在各continuation目录的code/tests/ops及根Python脚本中。最新GPU采集位于continuation_20261006_54，调度位于55，分析/封装位于56；历史完整证据位于各普通ZIP中。不要直接运行调度或采集脚本，除非有对应GPU授权。

离线复算本轮：在本包内新目录解压GPU_ONLY_Fixed_Task_Estimation_v2.zip，运行python continuation_20261006_56/analyze.py；需要Python/scipy。该操作不申请GPU。原始包不得覆盖。内部历史索引中的绝对服务器路径仅为来源记录，迁移后按相对路径定位。

本轮12会话/72主请求完成，全部自然EOS。写作与代码任务质量失败均保留；无质量匹配节能声明。物理控制/DC/PCC仍BLOCKED，J_W6为空，原W6全实验验证未完成。

MANIFEST.json覆盖所有打包的服务器payload；FILE_INDEX.csv便于阅读。外部ZIP_RECEIPT.json核验最终外层ZIP，避免自身hash循环。排除模型权重、环境、缓存、重复fresh_unpack和已淘汰v1当前结果包。此包未上传第三方。
