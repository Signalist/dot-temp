from pathlib import Path
import json,sys,subprocess,time
from source_guard import check
ROOT=Path(__file__).resolve().parents[1]
def run(case):
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);stages=[];started=time.monotonic_ns()
 try:
  for stage,script in [('terminal',case+'.py'),('fresh_recovery','recovery.py')]:
   dest=out/stage;begin=time.monotonic_ns()
   p=subprocess.run([sys.executable,str(ROOT/'code'/script),str(dest),sys.argv[2]],text=True,capture_output=True,timeout=300)
   end=time.monotonic_ns();(out/(stage+'_stdout.txt')).write_text(p.stdout);(out/(stage+'_stderr.txt')).write_text(p.stderr)
   r=json.loads((dest/'result.json').read_text()) if (dest/'result.json').exists() else {'status':'MISSING_RESULT'}
   stages.append({'stage':stage,'returncode':p.returncode,'status':r['status'],'process_wall_ns_including_import_hash_init_shutdown':end-begin})
   if p.returncode or not r['status'].startswith('PASS'):raise RuntimeError('stage_failed_no_next_engine:'+stage)
   shutdown=json.loads((dest/'shutdown_check.json').read_text())
   if shutdown['remaining_compute_processes']!=0:raise RuntimeError('worker_not_cleanly_shutdown')
   ack=json.loads((dest/'closure_ack.json').read_text())
   if not ack['worker_ack']['cuda_all_stream_sync_ack'] or ack['next_request_admitted']:raise RuntimeError('closure_not_qualified')
   if stage=='terminal':
    rejection=json.loads((dest/'admission_rejection.json').read_text())
    if rejection['new_operation_called'] or rejection['new_request_admitted']:raise RuntimeError('failed_session_admission_not_closed')
  devices=[];energies=[]
  for stage in ['terminal','fresh_recovery']:
   a=out/stage;b=json.loads((a/'gpu_before.json').read_text())[0];e=json.loads((a/'gpu_after.json').read_text())[0]
   key=(b['uuid_sha256'],b['power_limit_W'])
   if key!=(e['uuid_sha256'],e['power_limit_W']):raise RuntimeError('device_or_cap_changed')
   devices.append(key)
   marks={x['label']:x for x in json.loads((a/'energy_counter.json').read_text())}
   x,y=marks['cycle_start']['energy_mJ'],marks['cycle_end']['energy_mJ']
   if x is None or y is None:energies.append(None)
   elif y<x:raise RuntimeError('counter_reset')
   else:energies.append((y-x)/1000)
  if len(set(devices))!=1:raise RuntimeError('device_changed_before_restart')
  result={'status':'PASS_ISOLATED_TERMINAL_CLEAN_SHUTDOWN_AND_FRESH_ENGINE_SUCCESS','case':case,'stages':stages,'process_total_wall_ns':time.monotonic_ns()-started,'stage_counter_energy_J':energies,'energy_excludes_gap_between_subprocesses':True,'continuous_service_resume':False,'physical_initial_final_state_qualified':False,'new_request_on_closed_owner':False,'fresh_engine_recovery':True,'J_W6':None,'full_goal_complete':False}
 except BaseException as e:
  result={'status':'FAIL_RESTART_AUDIT_NO_FURTHER_STAGE','case':case,'error_type':type(e).__name__,'message':str(e),'stages':stages,'full_goal_complete':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'case':case,'status':result['status']}));raise SystemExit(not result['status'].startswith('PASS'))
