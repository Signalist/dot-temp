from restart_audit import run
if __name__=='__main__':run('stop_rule')
