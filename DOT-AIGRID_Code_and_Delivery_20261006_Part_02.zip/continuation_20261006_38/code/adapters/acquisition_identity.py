from pathlib import Path
import hashlib

def identity_for_output(output, workspace):
    root=Path(workspace).resolve();target=Path(output).resolve()
    if target==root or not target.is_relative_to(root):
        raise ValueError('acquisition_output_outside_workspace')
    relative=str(target.relative_to(root))
    digest=hashlib.sha256(relative.encode()).hexdigest()
    return {'acquisition_id':'w6_acq_'+digest[:32],
            'run_id':'w6_run_'+digest[:32],
            'session_id':'w6_session_'+hashlib.sha256(str(target.parent.relative_to(root)).encode()).hexdigest()[:32],
            'request_id':'w6_request_'+digest[:32],
            'acquisition_namespace':relative,
            'identity_source':'WORKSPACE_RELATIVE_PHYSICAL_OUTPUT_PATH_SHA256',
            'namespace_sha256':digest}

def verify_rows(rows, expected):
    if not rows:raise ValueError('empty_acquisition_rows')
    for row in rows:
        for key in ['acquisition_id','run_id','session_id','request_id','acquisition_namespace']:
            if row.get(key)!=expected[key]:raise ValueError('mixed_acquisition_identity:'+key)
