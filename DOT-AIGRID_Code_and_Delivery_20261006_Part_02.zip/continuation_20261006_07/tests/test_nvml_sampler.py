import unittest,tempfile,time,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.nvml_sampler import NVMLSampler
class Fake:
 def __init__(self,fail=False):self.n=0;self.fail=fail
 def nvmlDeviceGetPowerUsage(self,d):
  self.n+=1
  if self.fail and self.n>1:raise RuntimeError('CPU_TEST sensor fault')
  return 120123
 def nvmlDeviceGetTemperature(self,d,s):return 40
 def nvmlDeviceGetPowerManagementLimit(self,d):return 700000
class SamplerTests(unittest.TestCase):
 def test_units_identity_and_query_timing(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'raw';s=NVMLSampler(Fake(),0,p,{'acquisition_id':'CPU_TEST'},period_s=.005);s.start();time.sleep(.025);s.close();rows=[json.loads(x) for x in p.read_text().splitlines()]
   self.assertGreaterEqual(len(rows),2);self.assertTrue(all(r['power_W']==120.123 and r['arrival_ns']>=r['query_begin_ns'] and r['DC_boundary'] is False for r in rows))
 def test_sensor_failure_preserves_partial_and_fails_closed(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'raw';s=NVMLSampler(Fake(True),0,p,{'acquisition_id':'CPU_TEST'},period_s=.005);s.start();time.sleep(.025)
   with self.assertRaises(RuntimeError):s.close()
   self.assertEqual(len(p.read_text().splitlines()),1)
 def test_output_cannot_overwrite(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'raw';p.write_text('sealed');s=NVMLSampler(Fake(),0,p,{},period_s=.005)
   with self.assertRaises(FileExistsError):s.start()
   self.assertEqual(p.read_text(),'sealed')
