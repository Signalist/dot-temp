import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.tokenizer_input import single_token_ids
class TokenizerInputTests(unittest.TestCase):
 def test_mapping_matches_plain_list(self):self.assertEqual(single_token_ids({'input_ids':[10,20],'attention_mask':[1,1]},max_input_tokens=20),[10,20])
 def test_single_batch(self):self.assertEqual(single_token_ids({'input_ids':[[10,20]]},max_input_tokens=20),[10,20])
 def test_string_and_mapping_keys_rejected(self):
  for bad in ['input_ids',['input_ids'],{'attention_mask':[1]},[True]]:
   with self.assertRaises(ValueError):single_token_ids(bad,max_input_tokens=20)
 def test_multiple_batches_rejected(self):
  with self.assertRaises(ValueError):single_token_ids([[1],[2]],max_input_tokens=20)
 def test_bound_and_empty_rejected(self):
  for bad in [[],list(range(21))]:
   with self.assertRaises(ValueError):single_token_ids(bad,max_input_tokens=20)
