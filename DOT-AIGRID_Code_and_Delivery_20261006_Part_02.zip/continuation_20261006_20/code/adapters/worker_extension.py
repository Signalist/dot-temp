from adapters.worker_barrier import synchronize_worker
import time
class DOTWorkerExtension:
 def dot_sync_after_pause(self):return synchronize_worker(self)
 def dot_install_sample_events(self):
  import torch
  runner=self.model_runner
  if hasattr(runner,'_dot_sample_events'):raise RuntimeError('sample_hook_already_installed')
  if runner.speculative_config is not None:raise RuntimeError('speculative_sampling_unsupported')
  original=runner._sample
  rows=[]
  runner._dot_sample_events=rows
  anchor=torch.cuda.Event(enable_timing=True)
  anchor.record(torch.cuda.current_stream())
  begin=time.monotonic_ns();anchor.synchronize();end=time.monotonic_ns()
  runner._dot_anchor=(anchor,begin,end)
  def sample(*args,**kwargs):
   ids=list(runner.input_batch.req_ids)
   if len(ids)!=1:raise RuntimeError('single_request_hook_required')
   output=original(*args,**kwargs)
   event=torch.cuda.Event(enable_timing=True)
   event.record(torch.cuda.current_stream())
   rows.append((ids[0],event,time.monotonic_ns()))
   if len(rows)>32:raise RuntimeError('sample_hook_budget_exceeded')
   return output
  runner._sample=sample
  return {'installed':True,'anchor_sync_begin_ns':begin,'anchor_sync_end_ns':end,'semantics':'CURRENT_STREAM_POST_SAMPLE_EVENT_NOT_YET_EOS_QUALIFIED'}
 def dot_read_sample_events(self):
  runner=self.model_runner
  anchor,begin,end=runner._dot_anchor
  result=[]
  for step,(request,event,host_record) in enumerate(runner._dot_sample_events):
   event.synchronize()
   result.append({'request_id':request,'sample_step':step,'anchor_elapsed_ms':anchor.elapsed_time(event),'host_record_return_ns':host_record,'event_complete':event.query()})
  return {'rows':result,'anchor_sync_begin_ns':begin,'anchor_sync_end_ns':end,'device_EOS_ns':None,'clock_calibration':'NOT_QUALIFIED','cross_stream_dependencies':'NOT_QUALIFIED','instrumentation_overhead':'NOT_QUALIFIED'}
