import unittest,tempfile,sys,copy,json,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.service_v2 import fit_service,evaluate_service,WORKSPACE
from adapters.registry_v2 import canonical_hash
from w6kit.demo import demo
from w6kit.core import sha,write_json
class ServiceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);old=self.root/'demo';demo(old);self.raw=self.root/'raw';self.raw.mkdir()
  registry=json.loads((old/'frozen_split.json').read_text());registry['schema_version']='w6-registry-2'
  for r in registry['runs']:
   r['raw_relative_path']=f"GPU_DC/{r['stage']}/{r['session_id']}/{r['run_id']}/attempt_001";dst=self.raw/r['raw_relative_path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(old/r['run_id'],dst)
   seal={'session_id':r['session_id'],'run_id':r['run_id'],'attempt_id':'attempt_001','status':'SUCCESS','files':[{'path':n,'bytes':(dst/n).stat().st_size,'sha256':sha(dst/n)} for n in ['manifest.json','power.jsonl','events.jsonl']]};write_json(dst/'acquisition_manifest.json',seal)
  dev=[r for r in registry['runs'] if r['stage'] in {'identification','calibration'}];held=[r for r in registry['runs'] if r not in dev]
  required={stage:[r['run_id'] for r in registry['runs'] if r['stage']==stage] for stage in {r['stage'] for r in registry['runs']}}
  self.parent={**registry,'runs':dev,'prospective_child_slots':held,'child_required_by_stage':required,'required_by_stage':{s:ids for s,ids in required.items() if s in {'identification','calibration'}}}
  self.child={**registry,'parent_registry_sha256':canonical_hash(self.parent),'required_by_stage':required};self.p=self.root/'parent.json';self.c=self.root/'child.json';self.model=self.root/'model.json';write_json(self.p,self.parent);write_json(self.c,self.child)
 def fit(self):return fit_service(self.raw,self.p,self.c,self.model)
 def evaluate(self):return evaluate_service(self.raw,self.p,self.c,self.model,self.root/'eval.json',{'confirmation'})
 def held(self):return self.raw/next(r['raw_relative_path'] for r in self.child['runs'] if r['stage']=='confirmation')
 def test_nested_fit_matches_legacy_diagnostic(self):
  result=self.fit();legacy=json.loads((self.root/'demo/frozen_service_model.json').read_text());self.assertEqual(result['a'],legacy['a']);self.assertEqual(result['b'],legacy['b']);self.assertEqual(len(self.evaluate()['rows']),2)
 def test_fit_never_opens_confirmation_payload(self):
  (self.held()/'events.jsonl').write_text('BROKEN HOLDOUT');self.fit()
  with self.assertRaises(ValueError):self.evaluate()
 def test_missing_one_side_blocks_stage(self):
  self.fit();shutil.rmtree(self.held())
  with self.assertRaises(ValueError):self.evaluate()
 def test_failure_not_substituted_with_retry(self):
  self.fit();write_json(self.held()/'failure.json',{'reason':'SIMULATED FAILURE'})
  with self.assertRaises(ValueError):self.evaluate()
 def test_hash_tampering_rejected(self):
  first=self.raw/self.parent['runs'][0]['raw_relative_path'];(first/'power.jsonl').write_text('TAMPER')
  with self.assertRaises(ValueError):self.fit()
 def test_model_cannot_overwrite(self):
  self.fit()
  with self.assertRaises(ValueError):self.fit()
 def test_child_mutation_after_fit(self):
  self.fit();self.child['runs'][-1]['analysis_protocol']['max_tokens']=31;write_json(self.c,self.child)
  with self.assertRaises(ValueError):self.evaluate()
 def test_stage_required_omission(self):
  self.parent['required_by_stage']['identification'].pop();self.child['parent_registry_sha256']=canonical_hash(self.parent);write_json(self.p,self.parent);write_json(self.c,self.child)
  with self.assertRaises(ValueError):self.fit()
