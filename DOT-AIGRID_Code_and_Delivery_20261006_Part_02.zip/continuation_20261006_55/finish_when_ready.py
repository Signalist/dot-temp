import pathlib,time,subprocess,sys
B=pathlib.Path(__file__).resolve().parent.parent;P=pathlib.Path(__file__).resolve().parent
while not ((P/'SESSION_LEDGER_FINAL.json').exists() or (P/'BATCH_STOP.json').exists()):time.sleep(10)
r=subprocess.run([sys.executable,str(B/'continuation_20261006_56/finalize.py')],cwd=B)
raise SystemExit(r.returncode)
