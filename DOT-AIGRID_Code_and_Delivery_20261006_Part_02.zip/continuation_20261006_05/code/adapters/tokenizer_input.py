"""Accept explicit single-sample tokenizer outputs, never iterate mapping keys."""
from collections.abc import Mapping

def single_token_ids(value,*,max_input_tokens):
 if isinstance(value,Mapping):value=value.get('input_ids')
 if isinstance(value,(list,tuple)) and len(value)==1 and isinstance(value[0],(list,tuple)):value=value[0]
 if not isinstance(value,(list,tuple)) or not value or not 0<len(value)<=max_input_tokens:raise ValueError('invalid_single_tokenized_prompt')
 if any(type(token) is not int or token<0 for token in value):raise ValueError('prompt_ids_must_be_nonnegative_integers')
 return list(value)
