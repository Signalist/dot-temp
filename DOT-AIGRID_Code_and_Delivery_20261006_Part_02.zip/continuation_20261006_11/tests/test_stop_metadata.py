import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from test_host_bridge import output
from adapters.vllm_host import CumulativeObserver,RequestContract
class StopMetadataTests(unittest.TestCase):
 def contract(self,strings=()):return RequestContract('r1',8,(2,),17,stop_strings=strings)
 def test_declared_rule_records_actual_reason(self):
  x=output([7],'stop');x.outputs[0].stop_reason='OK';e=CumulativeObserver(self.contract(('OK',))).observe(x);self.assertEqual(e['actual_stop_reason'],'OK');self.assertEqual(e['stop_class'],'stop_rule');self.assertFalse(e['stop_reason_redacted'])
 def test_declared_rule_without_matching_engine_reason_is_unknown(self):
  e=CumulativeObserver(self.contract(('OK',))).observe(output([7],'stop'));self.assertEqual(e['stop_class'],'unknown')
 def test_unapproved_reason_is_redacted_and_unknown(self):
  x=output([7],'stop');x.outputs[0].stop_reason='PRIVATE_VALUE';e=CumulativeObserver(self.contract()).observe(x);self.assertEqual(e['stop_class'],'unknown');self.assertTrue(e['stop_reason_redacted']);self.assertNotIn('PRIVATE_VALUE',str(e))
 def test_eos_predicate_without_full_sequence(self):
  e=CumulativeObserver(self.contract()).observe(output([7,2],'stop'));self.assertEqual(e['terminal_eos_token_id'],2);self.assertEqual(e['stop_class'],'natural_eos_token_host_verified');self.assertNotIn('token_ids',e)
