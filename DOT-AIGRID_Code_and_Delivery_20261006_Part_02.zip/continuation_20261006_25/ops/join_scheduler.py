"""Require exact ordered tensor hashes across worker and scheduler boundaries."""
from pathlib import Path
import json,argparse

def join(worker, scheduler, binding):
    req=binding['internal_request_id'];samples=worker['rows']
    inputs=[]
    for row in scheduler:
        if row['boot_id']!=worker['boot_id']:raise ValueError('different_boot_clock')
        for item in row['before']:
            if item['request_id']!=req:raise ValueError('unexpected_scheduler_request')
            if item['sample_count']!=1:raise ValueError('unsupported_scheduler_sample_count')
            inputs.append((row,item))
    if len(inputs)!=len(samples):raise ValueError('incomplete_step_correspondence')
    result=[]
    for sample,(row,item) in zip(samples,inputs):
        if sample['request_id']!=req or sample['sample_token_sha256']!=item['sample_token_sha256']:
            raise ValueError('worker_scheduler_tensor_mismatch')
        emitted=[x for x in row['emitted'] if x['request_id']==req and x['emitted_count']]
        if len(emitted)>1:raise ValueError('multiple_output_rows')
        if emitted and (emitted[0]['emitted_count']!=1 or emitted[0]['emitted_token_sha256']!=item['sample_token_sha256']):
            raise ValueError('scheduler_output_tensor_mismatch')
        result.append({'sample_step':sample['sample_step'],'EOS_predicate':sample['sample_is_declared_eos'],
                       'request_present_before_update':item['present'],'request_finished_before_update':item['finished'],
                       'emitted_to_engine_output':bool(emitted),'finish_reason':emitted[0]['finish_reason'] if emitted else None})
    eos=[r for r in result if r['EOS_predicate'] and r['emitted_to_engine_output']]
    if len(eos)!=1:raise ValueError('ambiguous_accepted_EOS_sample')
    return {'status':'PASS_EXACT_ORDERED_WORKER_SCHEDULER_OUTPUT_JOIN','rows':result,
            'accepted_EOS_step':eos[0]['sample_step'],'device_EOS_time_qualified':False,
            'probe_overhead_qualified':False,'full_goal_complete':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('acquisition');args=p.parse_args();a=Path(args.acquisition)
    worker=json.loads((a/'sample_events.json').read_text());binding=json.loads((a/'request_bindings.json').read_text())
    if len(worker)!=1 or len(binding)!=1:raise ValueError('single_worker_request_required')
    scheduler=[json.loads(x) for x in (a/'scheduler_events.jsonl').read_text().splitlines()]
    result=join(worker[0],scheduler,binding[0]);out=a.parent.parent.parent/'SCHEDULER_JOIN_AUDIT.json'
    if out.exists():raise FileExistsError(out)
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
