"""Conditional affine interpolation; never a qualified device timestamp."""
import math
import json
from pathlib import Path

def interpolate(start, end, span_ms, event_ms):
    if any(type(x) is not int for x in (*start, *end)):
        raise ValueError('host_brackets_require_integer_ns')
    if not (start[0] <= start[1] < end[0] <= end[1]):
        raise ValueError('invalid_anchor_brackets')
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in (span_ms, event_ms)):
        raise ValueError('invalid_device_times')
    if not (span_ms > 0 and 0 <= event_ms <= span_ms):
        raise ValueError('extrapolation_or_nonpositive_span')
    alpha = event_ms / span_ms
    # Subtract the integer epoch before float arithmetic to preserve precision.
    epoch = start[0]
    low = epoch + math.floor(alpha * (end[0] - epoch))
    high = epoch + math.ceil((1-alpha)*(start[1]-epoch) + alpha*(end[1]-epoch))
    return {'conditional_lower_ns': low, 'conditional_upper_ns': high,
            'conditional_width_ns': high-low, 'assumption': 'EXACT_AFFINE_DEVICE_CLOCK',
            'timer_error_included': False, 'nonlinearity_included': False,
            'qualified_timestamp': False}

if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('acquisition');a=p.parse_args()
    directory=Path(a.acquisition);source=json.loads((directory/'sample_events.json').read_text())
    if len(source)!=1:raise ValueError('single_worker_required')
    s=source[0];e=s['endpoint_anchor']
    rows=[{**r, 'clock_candidate':interpolate(
        (s['anchor_sync_begin_ns'],s['anchor_sync_end_ns']),
        (e['host_record_begin_ns'],e['host_sync_end_ns']),e['device_elapsed_ms'],r['anchor_elapsed_ms'])}
        for r in s['rows']]
    result={'status':'CONDITIONAL_AFFINE_CANDIDATE_ONLY','rows':rows,
            'device_EOS_ns':None,'clock_calibration_qualified':False,
            'missing':['Timer accuracy bound','Clock nonlinearity bound','Independent calibration and overhead qualification']}
    out=directory.parent.parent.parent/'CLOCK_CANDIDATE.json'
    if out.exists():raise FileExistsError(out)
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'output':str(out)}))
