"""Read-only sealed attempt index. Failed, partial and missing attempts stay visible."""
from pathlib import Path
import json,hashlib
from adapters.registry_v2 import safe_relative,RegistryError
class IndexError(ValueError):pass

def contained_file(root,relative):
 root=Path(root).resolve();q=safe_relative(relative);p=root/q;current=root
 for part in q.parts:
  current=current/part
  if current.is_symlink():raise IndexError('symlink_in_payload_path')
 if not p.resolve().is_relative_to(root):raise IndexError('payload_path_escape')
 return p

def scan_attempts(raw_root):
 raw_root=Path(raw_root).resolve();rows=[]
 for attempt in sorted(raw_root.glob('*/*/*/*/*')):
  if not attempt.is_dir() or attempt.is_symlink():
   if attempt.is_symlink():raise IndexError('symlink_attempt')
   continue
  rel=attempt.relative_to(raw_root);current=raw_root
  for part in rel.parts:
   current=current/part
   if current.is_symlink():raise IndexError('symlink_in_attempt_ancestry')
  tier,stage,session,run,aid=rel.parts
  row={'tier':tier,'stage':stage,'session_id':session,'run_id':run,'attempt_id':aid,'path':str(attempt.relative_to(raw_root)),'seal_status':'MISSING','identity_status':'UNCONFIRMED','outcome_status':'UNKNOWN','errors':[],'physical_admission':'NOT_ESTABLISHED'}
  manifests=[p for p in [attempt/'acquisition_manifest.json',attempt/'manifest.json'] if p.is_file()]
  if not manifests:
   row['errors'].append('missing_manifest');rows.append(row);continue
  manifest=manifests[0]
  try:
   if manifest.is_symlink():raise IndexError('symlink_manifest')
   data=json.loads(manifest.read_text());row['manifest_sha256']=hashlib.sha256(manifest.read_bytes()).hexdigest()
   for key,expected in [('session_id',session),('run_id',run),('attempt_id',aid)]:
    if data.get(key) is None:row['errors'].append('manifest_identity_missing:'+key)
    elif data[key]!=expected:row['errors'].append('manifest_identity_mismatch:'+key)
   row['identity_status']='PASS' if not any('identity_' in e for e in row['errors']) else 'FAIL'
   records=data.get('files');seen=set()
   if not isinstance(records,list):raise IndexError('invalid_files_list')
   for record in records:
    name=record['path']
    if name in seen:raise IndexError('duplicate_payload_path')
    seen.add(name);file=contained_file(attempt,name)
    if not file.is_file():raise IndexError('missing_payload:'+name)
    content=file.read_bytes()
    if len(content)!=record['bytes'] or hashlib.sha256(content).hexdigest()!=record['sha256']:raise IndexError('payload_hash_mismatch:'+name)
   row['seal_status']='PASS'
   # Outcome evidence stays distinct from seal/identity/physical admission.
   fail=attempt/'failure.json'
   if fail.is_file():
    if fail.is_symlink():raise IndexError('symlink_failure')
    row['outcome_status']='FAIL';row['failure']=json.loads(fail.read_text()).get('reason')
   elif data.get('raw_result_status'):row['outcome_status']=data['raw_result_status']
   elif data.get('status'):row['outcome_status']=data['status']
   row['partial_files']=[str(p.relative_to(attempt)) for p in attempt.rglob('*.partial')]
  except (OSError,ValueError,KeyError,TypeError) as e:row['seal_status']='FAIL';row['errors'].append(str(e))
  rows.append(row)
 return rows

def required_run_audit(registry,index,stage):
 required=registry.get('required_by_stage',{}).get(stage)
 if not isinstance(required,list) or not required:raise IndexError('stage_required_set_not_frozen')
 slots={r['run_id']:r for r in registry['runs']}
 if set(required)!={r['run_id'] for r in registry['runs'] if r['stage']==stage}:raise IndexError('required_set_drops_registered_runs')
 records=[];missing=[]
 for id in required:
  matches=[r for r in index if r['run_id']==id and r['session_id']==slots[id]['session_id']]
  if not matches:missing.append(id)
  records.extend(matches)
 return {'status':'BLOCKED_MISSING_REQUIRED' if missing else 'ALL_REQUIRED_ATTEMPTS_INDEXED','missing_run_ids':missing,'all_attempts':records,'successful_only_filter_applied':False,'numerical_evaluation_admitted':False,'reason':'Hash/identity/physical data gates and model-v2 fit/evaluation remain separate'}
