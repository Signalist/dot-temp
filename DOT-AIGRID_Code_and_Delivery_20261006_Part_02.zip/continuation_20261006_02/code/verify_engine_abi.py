"""Check installed pinned vLLM ABI and real output objects; no inference workload."""
from pathlib import Path
import json,hashlib,importlib.metadata as md,inspect,sys
ROOT=Path(__file__).resolve().parents[1]
from source_guard import check
if __name__=="__main__":check(ROOT,sys.argv[2])
from adapters.vllm_host import RequestContract,CumulativeObserver

def verify():
 expected=json.loads((ROOT.parent/'gpu_preflight/vllm/attempt_002/inventory.json').read_text())
 errors=[];actual=[]
 dist=md.distribution('vllm')
 if dist.version!='0.20.2':errors.append('engine_version_drift')
 for row in expected['engine_source']:
  p=Path(dist.locate_file(row['relative_path']));digest=hashlib.sha256(p.read_bytes()).hexdigest();actual.append({'path':row['relative_path'],'sha256':digest})
  if digest!=row['sha256']:errors.append('engine_source_drift:'+row['relative_path'])
 if errors:return {'status':'FAIL','errors':errors,'installed_source_hashes':actual}
 from vllm.v1.engine.async_llm import AsyncLLM
 from vllm.outputs import RequestOutput,CompletionOutput
 for name in ['generate','abort','wait_for_requests_to_drain']:
  method=getattr(AsyncLLM,name,None)
  if method is None:errors.append('missing_method:'+name)
  elif name=='generate' and not inspect.isasyncgenfunction(method):errors.append('generate_not_async_iterator')
  elif name!='generate' and not inspect.iscoroutinefunction(method):errors.append('method_not_awaitable:'+name)
 c=CompletionOutput(index=0,text='',token_ids=[7,2],cumulative_logprob=None,logprobs=None,finish_reason='stop',stop_reason=None)
 o=RequestOutput(request_id='synthetic_abi_fixture',prompt=None,prompt_token_ids=None,prompt_logprobs=None,outputs=[c],finished=True)
 event=CumulativeObserver(RequestContract('synthetic_abi_fixture',8,(2,),17)).observe(o)
 if event['completed_tokens']!=2 or event['true_eos_ns'] is not None:errors.append('output_object_contract')
 return {'status':'PASS_SOFTWARE_ABI' if not errors else 'FAIL','errors':errors,'engine_package_version':dist.version,'installed_source_hashes':actual,'real_output_object_fixture':'CPU_TEST_SYNTHETIC_TOKEN_IDS_NOT_MODEL_GENERATED','event':event,'GPU_requests':0,'cap_writes':0,'model_loads':0,'device_completion_validation':'NOT_RUN','cancel_and_drain_real_engine_validation':'NOT_RUN','full_engine_git_commit':'UNCONFIRMED'}
if __name__=='__main__':
 out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 try:r=verify()
 except Exception as e:r={'status':'FAIL','error_type':type(e).__name__,'GPU_requests':0,'cap_writes':0,'model_loads':0};(out/'error_detail.txt').write_text(str(e)[:1000])
 (out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(r['status']!='PASS_SOFTWARE_ABI')
