from pathlib import Path
import sys,subprocess,json,os,hashlib
ROOT=Path(__file__).resolve().parents[1]
from source_guard import check
check(ROOT,sys.argv[2])
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(out),MPLCONFIGDIR=str(out/'mpl'),XDG_CACHE_HOME=str(out/'cache'))
checks=[]
for name,argv,expected in [('contract_tests',[sys.executable,'-m','unittest','discover','-s',str(ROOT/'tests'),'-v'],0),('sealed_delivery_integrity',[sys.executable,str(ROOT.parent/'W6_Experiment_Results_20261005_cpu_audit_01/02_code/verify_delivery.py'),'--root',str(ROOT.parent/'W6_Experiment_Results_20261005_cpu_audit_01')],0)]:
 r=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=180);(out/(name+'.stdout.txt')).write_text(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr);checks.append({'check':name,'exit_code':r.returncode,'expected':expected})
from adapters.run_index import scan_attempts
rows=scan_attempts(ROOT.parent/'W6_Experiment_Results_20261005_cpu_audit_01/04_raw')
(out/'raw_attempt_index.json').write_text(json.dumps({'all_attempts':rows,'successful_only_filter_applied':False,'physical_admission':'NOT_ESTABLISHED'},indent=2)+'\n')
checks.append({'check':'raw_attempt_index_retains_failure','exit_code':0 if rows and any(r['outcome_status']=='FAIL' for r in rows) else 1,'expected':0})
result={'status':'PASS_CPU_INTEGRATION' if all(x['exit_code']==x['expected'] for x in checks) else 'FAIL','evidence':'CPU_TEST','GPU_requests':0,'cap_writes':0,'checks':checks,'physical_W6_admission':'NOT_RUN'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(result['status']!='PASS_CPU_INTEGRATION')
