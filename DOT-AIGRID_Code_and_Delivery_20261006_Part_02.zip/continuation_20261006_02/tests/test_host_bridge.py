import unittest,asyncio,sys
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.vllm_host import *
C=RequestContract('r1',8,(2,),17)
def output(ids,reason=None,stop=None,finished=None,rid='r1'):
 return NS(request_id=rid,outputs=[NS(index=0,token_ids=ids,finish_reason=reason,stop_reason=stop)],finished=reason is not None if finished is None else finished)
def params(**kw):
 d=dict(n=1,max_tokens=8,seed=17,ignore_eos=False,stop=[],stop_token_ids=[],output_kind=NS(name='CUMULATIVE'));d.update(kw);return NS(**d)
class Fake:
 def __init__(self,outputs=(),slow=False,abort_fail=False,drain_fail=False,nonempty=False):self.outputs=outputs;self.slow=slow;self.abort_fail=abort_fail;self.drain_fail=drain_fail;self.nonempty=nonempty;self.aborts=0;self.output_processor=NS(request_states={})
 async def generate(self,*a):
  if self.slow:await asyncio.sleep(1)
  for item in self.outputs:yield item
 async def abort(self,rid):
  self.aborts+=1
  if self.abort_fail:raise RuntimeError('simulated_abort_failure')
 async def wait_for_requests_to_drain(self,drain_timeout):
  if self.drain_fail:raise TimeoutError('simulated_drain_failure')
  if self.nonempty:self.output_processor.request_states={'r1':1}
class ObserveTests(unittest.TestCase):
 def test_duplicate_cumulative_not_double_counted(self):
  o=CumulativeObserver(C);o.observe(output([7]));self.assertEqual(o.observe(output([7]))['new_tokens'],0);self.assertEqual(o.observe(output([7,2],'stop'))['completed_tokens'],2)
 def test_natural_host_does_not_create_device_time(self):
  e=CumulativeObserver(C).observe(output([2],'stop'));self.assertEqual(e['stop_class'],'natural_eos_token_host_verified');self.assertIsNone(e['true_eos_ns']);self.assertEqual(e['timestamp_source'],'host_engine_output')
 def test_stop_without_eos_is_unknown(self):self.assertEqual(CumulativeObserver(C).observe(output([7],'stop'))['stop_class'],'unknown')
 def test_length_never_natural(self):self.assertEqual(CumulativeObserver(C).observe(output([2],'length'))['stop_class'],'length')
 def test_prefix_change_rejected(self):
  o=CumulativeObserver(C);o.observe(output([7,8]));
  with self.assertRaises(ContractError):o.observe(output([7,9]))
 def test_shortened_cumulative_rejected(self):
  o=CumulativeObserver(C);o.observe(output([7,8]));
  with self.assertRaises(ContractError):o.observe(output([7]))
 def test_mixed_request_rejected(self):
  with self.assertRaises(ContractError):CumulativeObserver(C).observe(output([2],'stop',rid='r2'))
 def test_token_ids_not_saved(self):
  e=CumulativeObserver(C).observe(output([7,2],'stop'));self.assertNotIn('token_ids',e);self.assertNotIn('text',e)
class BridgeTests(unittest.IsolatedAsyncioTestCase):
 async def test_complete_requires_host_drain_but_not_device_pass(self):
  events=[];b=HostEngineBridge(Fake([output([7]),output([7,2],'stop')]),events.append);r=await b.run('SIMULATED',params(),C);self.assertEqual(r['physical_admission'],'BLOCKED_DEVICE_BARRIER_UNQUALIFIED');self.assertFalse(events[-1]['device_completion_verified'])
 async def test_absolute_timeout_aborts(self):
  f=Fake(slow=True);b=HostEngineBridge(f,lambda x:None,timeout_s=.01)
  with self.assertRaises(TimeoutError):await b.run('SIMULATED',params(),C)
  self.assertEqual(f.aborts,1);self.assertTrue(b.blocked)
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
 async def test_abort_failure_latches_no_next_request(self):
  f=Fake(slow=True,abort_fail=True);b=HostEngineBridge(f,lambda x:None,timeout_s=.01)
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
  self.assertEqual(f.aborts,1)
 async def test_nonempty_queue_latches(self):
  b=HostEngineBridge(Fake([output([2],'stop')],nonempty=True),lambda x:None)
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
  self.assertTrue(b.blocked)
 async def test_stream_close_is_failure(self):
  f=Fake([output([7])]);b=HostEngineBridge(f,lambda x:None)
  with self.assertRaises(ContractError):await b.run('SIMULATED',params(),C)
  self.assertEqual(f.aborts,1)
 async def test_sink_write_failure_still_aborts_and_latches(self):
  f=Fake();b=HostEngineBridge(f,lambda x:(_ for _ in ()).throw(OSError('simulated_disk_full')))
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
  self.assertEqual(f.aborts,1);self.assertTrue(b.blocked)
class AdditionalTests(unittest.IsolatedAsyncioTestCase):
 async def test_drain_failure_blocks_next_request(self):
  b=HostEngineBridge(Fake([output([2],'stop')],drain_fail=True),lambda x:None)
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
  with self.assertRaises(CleanupError):await b.run('SIMULATED',params(),C)
 async def test_n_and_delta_rejected_before_engine(self):
  f=Fake();b=HostEngineBridge(f,lambda x:None)
  with self.assertRaises(ContractError):await b.run('SIMULATED',params(n=2),C)
  with self.assertRaises(ContractError):await b.run('SIMULATED',params(output_kind=NS(name='DELTA')),C)
  self.assertFalse(b.busy)
if __name__=='__main__':unittest.main()
