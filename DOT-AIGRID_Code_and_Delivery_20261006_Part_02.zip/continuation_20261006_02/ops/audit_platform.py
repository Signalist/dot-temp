from pathlib import Path
import json,subprocess,os,datetime,csv
ROOT=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parents[1]/'platform_audit'
OUT.mkdir(exist_ok=True);env=dict(os.environ)
for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(k,None)
entries=[]
for p in sorted((ROOT/'qz_submissions').glob('*submit.json')):
 d=json.loads(p.read_text())
 if d.get('ok') and d.get('data',{}).get('job_id'):entries.append({'receipt':str(p.relative_to(ROOT)),'job_id':d['data']['job_id'],'name':d['data'].get('name'),'resolved':d['data'].get('resolved')})
for e in entries:
 snapshots={}
 for action,extra in [('detail',['--brief']),('instances',[]),('logs',['--tail','30'])]:
  x=subprocess.run(['qzcli',action,e['job_id'],*extra],env=env,text=True,capture_output=True,timeout=30)
  try:d=json.loads(x.stdout)
  except json.JSONDecodeError:d={'ok':False,'error_type':'INVALID_JSON','exit_code':x.returncode}
  file=OUT/(e['job_id']+'_'+action+'.json');file.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');snapshots[action]=d
 e['current_status']=snapshots['detail'].get('data',{}).get('status','UNKNOWN')
 e['log_messages']=[x.get('message','') for x in snapshots['logs'].get('data',{}).get('logs',[])]
 e['errors']=[s for s in e['log_messages'] if any(k in s.lower() for k in ['failed','error','exit code 127','no such file'])]
 e['artifact_status']='NEEDS_IDENTITY_CHECK'
summary={'schema_version':'w6-recovery-1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Existing DOT-AIGRID submission receipts; other projects not modified','jobs':entries,'failure_classification':{'python_command_missing':'Fixed launcher chooses python3 and verifies script/output paths before submission','proxy_TLS_EOF':'Remove proxy env only for the qzcli subprocess; do not alter global config','room_listing_429':'Use known compute-group/quota query, bounded backoff; never blindly submit after query failure','stopped_runtime_job':'Raw script completed successfully before workspace rename; platform STOPPED and raw PASS are distinct'}}
(OUT/'SUBMISSION_RECONCILIATION.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'job_id':e['job_id'],'status':e['current_status'],'errors':e['errors']} for e in entries],ensure_ascii=False))
