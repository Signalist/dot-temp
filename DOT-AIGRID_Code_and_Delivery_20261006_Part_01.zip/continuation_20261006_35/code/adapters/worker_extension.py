from adapters.worker_barrier import synchronize_worker
import time,hashlib,json
class DOTWorkerExtension:
 def dot_sync_after_pause(self):return synchronize_worker(self)
 def dot_install_sample_events(self,eos_token_ids):
  import torch
  runner=self.model_runner
  if hasattr(runner,'_dot_sample_events'):raise RuntimeError('sample_hook_already_installed')
  if runner.speculative_config is not None:raise RuntimeError('speculative_sampling_unsupported')
  original=runner._sample
  if not eos_token_ids or any(type(x) is not int for x in eos_token_ids):raise RuntimeError("invalid_eos_allowlist")
  runner._dot_eos=frozenset(eos_token_ids)
  rows=[]
  runner._dot_sample_events=rows
  anchor=torch.cuda.Event(enable_timing=True)
  begin=time.monotonic_ns()
  anchor.record(torch.cuda.current_stream())
  anchor.synchronize();end=time.monotonic_ns()
  runner._dot_anchor=(anchor,begin,end)
  def sample(*args,**kwargs):
   ids=list(runner.input_batch.req_ids)
   if len(ids)!=1:raise RuntimeError('single_request_hook_required')
   discard=bool(runner.discard_request_mask.np[0])
   stream_before=int(torch.cuda.current_stream().cuda_stream)
   metadata=runner.input_batch.sampling_metadata
   if not metadata.all_greedy or metadata.all_random:raise RuntimeError('greedy_sampling_required')
   sampler_class=type(runner.sampler).__module__+'.'+type(runner.sampler).__name__
   if sampler_class!='vllm.v1.sample.sampler.Sampler':raise RuntimeError('unexpected_sampler_implementation')
   logits=kwargs.get('logits',args[0] if args else None)
   if logits is None or logits.device.type!='cuda':raise RuntimeError('CUDA_logits_required')
   step=len(rows)
   with torch.profiler.record_function('DOT_SAMPLE_STEP_'+str(step)):
    output=original(*args,**kwargs)
   tensor_identity=hashlib.sha256(str(output.sampled_token_ids.data_ptr()).encode()).hexdigest()
   stream_after=int(torch.cuda.current_stream().cuda_stream)
   if stream_before!=stream_after or output.sampled_token_ids.device!=logits.device:raise RuntimeError('sampling_stream_or_device_changed')
   runtime_branch={'all_greedy':bool(metadata.all_greedy),'all_random':bool(metadata.all_random),'sampler_class':sampler_class,'stream_before':stream_before,'stream_after':stream_after,'logits_device':str(logits.device),'sample_device':str(output.sampled_token_ids.device)}
   event=torch.cuda.Event(enable_timing=True)
   record_begin=time.monotonic_ns()
   with torch.profiler.record_function('DOT_EVENT_RECORD_STEP_'+str(step)):
    event.record(torch.cuda.current_stream())
   rows.append((ids[0],event,time.monotonic_ns(),discard,output.sampled_token_ids,record_begin,runtime_branch,tensor_identity))
   if len(rows)>32:raise RuntimeError('sample_hook_budget_exceeded')
   return output
  runner._sample=sample
  return {'installed':True,'anchor_sync_begin_ns':begin,'anchor_sync_end_ns':end,'semantics':'CURRENT_STREAM_POST_SAMPLE_EVENT_NOT_YET_EOS_QUALIFIED'}
 def dot_read_sample_events(self):
  import torch
  from pathlib import Path
  runner=self.model_runner
  anchor,begin,end=runner._dot_anchor
  final_anchor=torch.cuda.Event(enable_timing=True)
  final_begin=time.monotonic_ns()
  final_anchor.record(torch.cuda.current_stream())
  final_anchor.synchronize();final_end=time.monotonic_ns()
  device_span_ms=anchor.elapsed_time(final_anchor)
  if device_span_ms<=0:raise RuntimeError("nonpositive_device_clock_span")
  result=[]
  for step,(request,event,host_record,discard,tokens,record_begin,runtime_branch,tensor_identity) in enumerate(runner._dot_sample_events):
   sync_begin=time.monotonic_ns()
   event.synchronize()
   complete=event.query()
   completion_observed=time.monotonic_ns()
   if not complete:raise RuntimeError("synchronized_event_not_complete")
   if not record_begin<=host_record<=sync_begin<=completion_observed:raise RuntimeError("event_host_clock_order")
   if hashlib.sha256(str(tokens.data_ptr()).encode()).hexdigest()!=tensor_identity:raise RuntimeError('sample_tensor_identity_changed')
   values=tokens.detach().cpu().reshape(-1).tolist()
   if len(values)!=1:raise RuntimeError('single_sample_tensor_required')
   result.append({'sample_tensor_identity_sha256':tensor_identity,'identity_check':'SAME_RETAINED_TENSOR_POINTER_ON_READ','runtime_branch':runtime_branch,'host_record_begin_ns':record_begin,'host_sync_begin_ns':sync_begin,'host_completion_observed_ns':completion_observed,'event_observation_interval_ns':[record_begin,completion_observed],'event_interval_semantics':'CURRENT_STREAM_EVENT_OCCURRENCE_BOUND_NOT_PRECISE_EOS','discard_mask':discard,'sample_is_declared_eos':values[0] in runner._dot_eos,'sample_token_sha256':hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest(),'sample_tensor_shape':list(tokens.shape),'request_id':request,'sample_step':step,'anchor_elapsed_ms':anchor.elapsed_time(event),'host_record_return_ns':host_record,'event_complete':complete})
  return {'endpoint_anchor':{'host_record_begin_ns':final_begin,'host_sync_end_ns':final_end,'device_elapsed_ms':device_span_ms},'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'anchor_order':'HOST_BEGIN_THEN_RECORD_THEN_SYNC_THEN_HOST_END','mapping_model':'Endpoint affine candidate only; timer error and nonlinearity bounds unqualified','rows':result,'anchor_sync_begin_ns':begin,'anchor_sync_end_ns':end,'device_EOS_ns':None,'clock_calibration':'NOT_QUALIFIED','cross_stream_dependencies':'NOT_QUALIFIED','instrumentation_overhead':'NOT_QUALIFIED'}

 def dot_start_cuda_trace(self):
  import torch
  if hasattr(self,'_dot_profiler'):raise RuntimeError('profiler_already_started')
  self._dot_profiler=torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA],record_shapes=False,profile_memory=False,with_stack=False)
  self._dot_profiler.start()
  return {'started':True,'scope':'DIAGNOSTIC_CUPTI_TRACE_NOT_PERFORMANCE_MEASUREMENT','overhead_qualified':False}
 def dot_stop_cuda_trace(self,path):
  from pathlib import Path
  dest=Path(path)
  if not dest.resolve().is_relative_to(Path(__file__).resolve().parents[3]):raise RuntimeError('trace_outside_workspace')
  if dest.exists():raise FileExistsError(dest)
  self._dot_profiler.stop()
  self._dot_profiler.export_chrome_trace(str(dest))
  return {'trace_written':True,'bytes':dest.stat().st_size,'overhead_qualified':False}

 def dot_clock_probe(self,label):
  import torch
  from pathlib import Path
  if label not in ['START','END']:raise RuntimeError('invalid_clock_probe_label')
  event=torch.cuda.Event(enable_timing=True)
  begin=time.monotonic_ns()
  with torch.profiler.record_function('DOT_CLOCK_PROBE_'+label):
   event.record(torch.cuda.current_stream())
   event.synchronize()
  end=time.monotonic_ns()
  return {'label':label,'host_begin_ns':begin,'host_end_ns':end,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'event_complete':event.query(),'scope':'Diagnostic anchor, not calibrated CUPTI accuracy bound'}
