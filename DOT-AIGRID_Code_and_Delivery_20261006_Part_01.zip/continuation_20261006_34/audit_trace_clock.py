from pathlib import Path
from decimal import Decimal,ROUND_FLOOR,ROUND_CEILING
import json,hashlib
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent
A=WS/'continuation_20261006_32/artifacts/real_smoke/attempt_001'
trace=json.loads((A/'cuda_trace.json').read_text(),parse_float=Decimal)
samples=json.loads((A/'sample_events.json').read_text())[0]['rows']
events=trace['traceEvents'];bounds=[]
floor=lambda x:int(x.to_integral_value(rounding=ROUND_FLOOR))
ceil=lambda x:int(x.to_integral_value(rounding=ROUND_CEILING))
for sample in samples:
 step=sample['sample_step']
 markers=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='DOT_EVENT_RECORD_STEP_'+str(step)]
 if len(markers)!=1:raise ValueError('ambiguous_marker')
 m=markers[0];start=Decimal(m['ts'])*1000;end=(Decimal(m['ts'])+Decimal(m['dur']))*1000
 lower=floor(Decimal(sample['host_record_begin_ns'])-start)
 upper=ceil(Decimal(sample['host_record_return_ns'])-end)
 if lower>upper:raise ValueError('marker_not_enclosed_under_constant_offset')
 bounds.append({'step':step,'offset_lower_ns':lower,'offset_upper_ns':upper,'width_ns':upper-lower})
lower=max(x['offset_lower_ns'] for x in bounds);upper=min(x['offset_upper_ns'] for x in bounds)
result={'status':'OBSERVED_CPU_TRACE_HOST_OFFSET_INTERSECTION' if lower<=upper else 'NO_COMMON_CONSTANT_OFFSET',
        'per_marker_bounds':bounds,'common_offset_lower_ns':lower,'common_offset_upper_ns':upper,
        'common_offset_width_ns':upper-lower if lower<=upper else None,
        'assumption':'CPU trace and host monotonic have unit slope and constant offset during this request',
        'CUPTI_GPU_CPU_clock_accuracy':'NOT_QUALIFIED','clock_drift_outside_observed_interval':'NOT_BOUNDED',
        'independent_validation_marker':'NOT_COLLECTED','profiler_overhead':'NOT_QUALIFIED',
        'precise_device_EOS_ns':None,'full_goal_complete':False,
        'source_sha256':{n:hashlib.sha256((A/n).read_bytes()).hexdigest() for n in ['cuda_trace.json','sample_events.json']}}
out=ROOT/'TRACE_HOST_CLOCK_AUDIT.json'
if out.exists():raise FileExistsError(out)
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
