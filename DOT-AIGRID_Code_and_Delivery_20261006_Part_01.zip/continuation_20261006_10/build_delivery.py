from pathlib import Path
import json,hashlib,zipfile,datetime,csv
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent
scope=json.loads((WS/'continuation_20261006_09/FULL_SCOPE_CURRENT_AUDIT.json').read_text());scope['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();scope['latest_job_reconciliation']='continuation_20261006_10/CURRENT_JOB_RECONCILIATION.json'
reasons={'I02':'Host ABI/request/drain bridge passed real GPU smoke; device event timing, qualified physical cancellation and policy/actuator bridge not completed.','I03':'Joint NVML/query-domain + request smoke passed; full gate still lacks qualified physical queue/device closure and fault qualification.','I05':'Four pilot pairs collected; no prespecified acceptability threshold; device instrumentation and NVML on/off overhead not measured.','I07':'Three stop classes demonstrated; actual stop-reason persistence, device timing, qualified cancel/timeout/residual execution remain incomplete.','I11':'Dependencies I03/I05/I07 have limited evidence only; no full route admission.','I01':'Public model, pinned engine and H100 identity inventoried; concrete physical control/operator and instrument contracts absent.','F04':'Local hashes verified; external time anchor/operator scientific freeze and new hardware-calibrated model/confirmation budget not established.'}
for row in scope['items']:
 if row['experiment_id'] in reasons:row['remaining_reason']=reasons[row['experiment_id']]
 elif row['experiment_id'].startswith('G') and row['experiment_id']!='G05':row['remaining_reason']='No real approved PCC boundary/instruments/topology/background/synchronized electrical channels or facility excitation scope.'
 elif row['prior_status']=='BLOCKED':row['remaining_reason']='Required measured DC/actuator/service qualification and/or independent frozen calibration/confirmation inputs not established; see original matrix gate and dependencies.'
scope['full_goal_complete']=False;scope['successfully_generated_model_requests']=14;scope['raw_request_population_warning']='Demonstration and warmup/AB requests; not iid independent confirmation samples.'
(ROOT/'FULL_SCOPE_CURRENT_AUDIT.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'EXPERIMENT_STATUS.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['experiment_id','title','full_status','full_completion_proved','new_evidence','remaining_reason']);w.writeheader()
 for r in scope['items']:w.writerow({'experiment_id':r['experiment_id'],'title':r['title'],'full_status':r['prior_status'],'full_completion_proved':r['full_completion_proved'],'new_evidence':r.get('new_software_progress'),'remaining_reason':r['remaining_reason']})
gate={'schema_version':'w6-plan-1','decision':'BLOCKED','route':'GPU_ONLY_full_pilot_admission','reason':'I03/I05/I07 have limited measured evidence, not full prerequisite qualification','allowed_current_claim':'Observed host callback counts/classes, NVML query-domain readings and four-pair host logging diagnostic only','DC_W6_route':'BLOCKED_MISSING_MEASUREMENT_AND_OPERATOR_SCOPE','PCC_route':'BLOCKED_MISSING_FACILITY_INPUTS','full_goal_complete':False,'no_further_result_driven_AB_expansion':True}
(ROOT/'PILOT_GATE.json').write_text(json.dumps(gate,indent=2)+'\n')
(ROOT/'README_ZH.txt').write_text('DOT-AIGRID GPU增量审计交付 v2。完整目标仍未完成；不是完整W6-DC/PCC结果包。\n平台最新核对19个已创建作业：15成功、3失败、1停止，无运行中/未知；另1次HTTP429未创建作业。完整失败与修复证据保留。\n实际成功生成14个请求：4次独立烟测（host-only自然、NVML联合自然、length、stop-rule），另2个A/B引擎会话各5请求（含预热），4对全部保留。不是14个iid confirmation样本。两A/B会话同一物理GPU。\n模型输入是平台既有Qwen2.5-0.5B-Instruct，8文件SHA一致；不包含权重、不安装依赖、不下载。引擎vLLM0.20.2固定5源码SHA，完整git commit未确认。\n已修复python入口、工作区路径、Unix IPC长度、tokenizer映射及提交HTTP429；NVML只读采样与host事件同次采集。无cap/burn/其他设置写入。host drain不是device barrier，NVML查询时间不是native sensor clock。\nI05四对B-A延迟中位数约0.530ms，未预设可接受阈值，INCONCLUSIVE。I07仅演示自然EOS/length/stop-rule；实际stop_reason持久化与device/cancel/timeout资格仍缺。全部38 ID和门禁见FULL_SCOPE_CURRENT_AUDIT/EXPERIMENT_STATUS/PILOT_GATE。\n本包为普通ZIP，成员保留工作区相对路径，与现有DOT-AIGRID合并。需要原始source_package、gpu_preflight和已封存CPU交付作为只读依赖；此前软件修复补充包continuation_20261006_04单独保留。\nZIP封存后外置DELIVERY_RECEIPT.json记录SHA、大小和CRC。PAYLOAD_MANIFEST不自包含自身。平台detail/profile原件保留本地，本包终态回执仅保留核验必需字段；日志仅保留exit0，没有账户信息。平台ls原始列表和编译/cache/tmp不打包。\n离线复算应在新解包副本运行verifier，报告可写，原始raw和封存包保持字节不变。剩余可实现软件包括原始停止元数据持久化、设备时序/worker适配、物理取消/排空证明和真实policy执行桥；不能把这些代码缺口都归因于缺仪表。\n')
files={}
def add(path):
 if path.is_file() and not path.is_symlink():files[str(path.relative_to(WS))]=path.read_bytes()
for n in [5,6,7,8,9]:
 base=WS/f'continuation_20261006_{n:02d}'
 for folder in ['code','tests','ops','source_revisions']:
  if not (base/folder).exists():continue
  for path in (base/folder).rglob('*'):
   if '__pycache__' not in path.parts and (path.suffix=='.py' or path.name=='MODEL_INPUT.json'):add(path)
 for path in base.glob('*.json'):add(path)
 add(base/'README_ZH.txt')
 for path in (base/'03_calibration').rglob('*') if (base/'03_calibration').exists() else []:add(path)
 for path in (base/'artifacts').glob('*tests*.txt'):add(path)
 for path in (base/'artifacts').glob('*/*/*'):
  if path.name in {'abi.json','gpu_before.json','gpu_after.json','host_events.jsonl','nvml.jsonl','all_requests.jsonl','result.json','runtime_paths.json','failure_traceback.txt','acquisition_manifest.json'}:add(path)
 for path in (base/'submissions').rglob('*.json'):
  if path.name in {'source_freeze.json','submit.stdout.json','launch.json','failure.json'}:add(path)
  if path.name.startswith(('detail_','instances_','logs_')):
   d=json.loads(path.read_text())
   if not d.get('ok'):continue
   if path.name.startswith('detail_'):data={'status':d['data'].get('status')}
   elif path.name.startswith('instances_'):data=[{'instance_status':r.get('instance_status')} for r in d.get('data',[])]
   else:data={'logs':[{'message':r['message']} for r in (d.get('data') or {}).get('logs',[]) if r.get('message')=='exit code 0']}
   files[str(path.relative_to(WS))]=(json.dumps({'ok':True,'data':data},indent=2)+'\n').encode()
for name in ['CURRENT_JOB_RECONCILIATION.json','FULL_SCOPE_CURRENT_AUDIT.json','EXPERIMENT_STATUS.csv','PILOT_GATE.json','README_ZH.txt','audit_jobs.py','build_delivery.py']:add(ROOT/name)
manifest={'schema_version':'w6-gpu-incremental-delivery-2','files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())],'self_excluded':True,'platform_receipts':'Sanitized copies; original byte hashes remain in source audit','all_small_projects_complete':False}
mp=ROOT/'PAYLOAD_MANIFEST_v3.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');add(mp)
archive=ROOT/'W6_GPU_Results_Audit_20261006_v3.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest['files']:
  b=z.read(row['path']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
assert archive.stat().st_size<18000000
receipt={'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'CRC_and_payload_hashes':'PASS','manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'full_goal_complete':False}
(ROOT/'DELIVERY_RECEIPT_v3.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
