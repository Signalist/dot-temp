import unittest,copy,tempfile,json,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from adapters.registry_v2 import *
from adapters.run_index import *

def slot(id,stage,session,device='devA',family='familyA',work='workA'):
 return {'run_id':id,'stage':stage,'session_id':session,'device_id_hash':device,'model_family':family,'device_model_unit':device+'_'+family,'workload_id':work,'phase_context_id':work,'raw_relative_path':f'GPU_DC/{stage}/{session}/{id}/attempt_001','analysis_protocol':{'max_tokens':32,'stratum':'fixed','model_revision':'model-r1','engine_revision':'engine-r1','stop_rules_id':'stop-r1','service_endpoint_rule':'first_progress_at_or_after_offset','endpoint_lag_max_ns':10,'service_window_offsets_ns':[[0,100]]}}
def registry(axis='device',transfer=False):
 runs=[slot('run_cal','calibration','session_cal'),slot('run_conf','confirmation','session_conf')]
 if transfer:runs.append(slot('run_transfer','transfer','session_transfer',device='devB' if axis=='device' else 'devA',family='familyB' if axis=='model_family' else 'familyA',work='workB'))
 return {'schema_version':SCHEMA,'evidence':'SIMULATED','declared_before_outcomes':True,'transfer_axis':axis,'runs':runs}
def linked():
 p=registry();p['runs']=p['runs'][:1];p['prospective_child_slots']=[slot('run_conf','confirmation','session_conf')];p['child_required_by_stage']={'calibration':['run_cal'],'confirmation':['run_conf']}
 c=copy.deepcopy(p);c['runs']+=copy.deepcopy(p['prospective_child_slots']);c['parent_registry_sha256']=canonical_hash(p);c['required_by_stage']=p['child_required_by_stage'];return p,c
class RegistryTests(unittest.TestCase):
 def test_no_transfer_supported_axis_and_none(self):
  validate(registry());validate(registry('none'))
 def test_workload_transfer_same_real_device(self):
  r=registry('workload',True);validate(r);self.assertEqual(r['runs'][0]['device_id_hash'],r['runs'][-1]['device_id_hash'])
 def test_phase_transfer_same_device(self):validate(registry('phase_context',True))
 def test_device_transfer_full_device_holdout(self):
  r=registry('device',True);validate(r);r['runs'][-1]['device_id_hash']='devA'
  with self.assertRaises(RegistryError):validate(r)
 def test_model_family_holdout_preserved(self):
  r=registry('model_family',True);validate(r);r['runs'][-1]['model_family']='familyA'
  with self.assertRaises(RegistryError):validate(r)
 def test_session_leakage(self):
  r=registry();r['runs'][1]['session_id']=r['runs'][0]['session_id']
  with self.assertRaises(RegistryError):validate(r)
 def test_none_cannot_hide_transfer(self):
  with self.assertRaises(RegistryError):validate(registry('none',True))
 def test_workload_leakage(self):
  r=registry('workload',True);r['runs'][-1]['workload_id']='workA'
  with self.assertRaises(RegistryError):validate(r)
 def test_nested_path_identity(self):
  r=registry();r['runs'][0]['raw_relative_path']='GPU_DC/calibration/wrong/run_cal/attempt_001'
  with self.assertRaises(RegistryError):validate(r)
 def test_parent_child_success_and_hash_mutation(self):
  p,c=linked();link_child(p,c);p['runs'][0]['analysis_protocol']['max_tokens']=33
  with self.assertRaises(RegistryError):link_child(p,c)
 def test_child_cannot_overwrite_role(self):
  p,c=linked();c['runs'][0]['stage']='confirmation'
  with self.assertRaises(RegistryError):link_child(p,c)
 def test_unused_reserved_slot_is_missing_not_removed(self):
  p,c=linked();c['runs'].pop()
  with self.assertRaises(RegistryError):link_child(p,c)
 def test_stage_required_set_cannot_omit(self):
  p,c=linked();p['child_required_by_stage']['confirmation']=[];c['parent_registry_sha256']=canonical_hash(p);c['required_by_stage']=p['child_required_by_stage']
  with self.assertRaises(RegistryError):link_child(p,c)
 def test_confirmation_never_fit_and_legacy_not_rebound(self):
  p,c=linked();m={'schema_version':'w6-service-model-2','parent_registry_sha256':canonical_hash(p),'evaluation_registry_sha256':canonical_hash(c),'fit_run_ids':['run_cal']};validate_model_binding(m,p,c);m['fit_run_ids']=['run_conf']
  with self.assertRaises(RegistryError):validate_model_binding(m,p,c)
  m['schema_version']='w6-1'
  with self.assertRaises(RegistryError):validate_model_binding(m,p,c)
class IndexTests(unittest.TestCase):
 def make(self,root,aid='attempt_001',fail=False,partial=False):
  d=root/'GPU_DC/confirmation/session_conf/run_conf'/aid;d.mkdir(parents=True);f=d/'events.jsonl';f.write_text('{}\n');m={'session_id':'session_conf','run_id':'run_conf','attempt_id':aid,'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}]}
  if fail:
   p=d/'failure.json';p.write_text('{"reason":"CPU_TEST_timeout"}');m['files'].append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  if partial:(d/'events.partial').write_text('bad partial')
  (d/'acquisition_manifest.json').write_text(json.dumps(m));return d
 def test_all_attempts_failure_and_retry_preserved(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root,fail=True);self.make(root,'attempt_002');rows=scan_attempts(root);self.assertEqual(len(rows),2);self.assertEqual(rows[0]['outcome_status'],'FAIL')
 def test_bad_hash_not_admitted(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);d=self.make(root);(d/'events.jsonl').write_text('tamper');rows=scan_attempts(root);self.assertEqual(rows[0]['seal_status'],'FAIL')
 def test_partial_is_reported(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root,partial=True);self.assertTrue(scan_attempts(root)[0]['partial_files'])
 def test_path_escape_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);d=self.make(root);p=d/'acquisition_manifest.json';m=json.loads(p.read_text());m['files'][0]['path']='../../secret';p.write_text(json.dumps(m));self.assertEqual(scan_attempts(root)[0]['seal_status'],'FAIL')
 def test_symlink_payload_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);d=self.make(root);p=d/'events.jsonl';p.unlink();p.symlink_to(d/'acquisition_manifest.json');self.assertEqual(scan_attempts(root)[0]['seal_status'],'FAIL')
 def test_mixed_run_identity_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);d=self.make(root);p=d/'acquisition_manifest.json';m=json.loads(p.read_text());m['run_id']='run_wrong';p.write_text(json.dumps(m));self.assertEqual(scan_attempts(root)[0]['identity_status'],'FAIL')
 def test_missing_required_run_blocks(self):
  r=registry();r['required_by_stage']={'confirmation':['run_conf']};a=required_run_audit(r,[],'confirmation');self.assertEqual(a['status'],'BLOCKED_MISSING_REQUIRED');self.assertEqual(a['missing_run_ids'],['run_conf'])
 def test_one_sided_failure_not_filtered(self):
  r=registry();r['required_by_stage']={'confirmation':['run_conf']}
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root,fail=True);a=required_run_audit(r,scan_attempts(root),'confirmation');self.assertEqual(len(a['all_attempts']),1);self.assertEqual(a['all_attempts'][0]['outcome_status'],'FAIL');self.assertFalse(a['numerical_evaluation_admitted'])
if __name__=='__main__':unittest.main()
