"""Versioned registry extensions; never modify frozen legacy inputs.

These validators certify declared structure and hashes, not physical truth,
pre-outcome timing or human approval. Legacy fit/evaluate are NOT silently
redirected to this protocol. A v2 statistical/model adapter is still required.
"""
from pathlib import PurePosixPath
import hashlib,json,re,copy
SCHEMA='w6-registry-2'
ROLES={'identification','calibration','confirmation','ablation','transfer'}
AXES={'device':'device_id_hash','model_family':'model_family','workload':'workload_id','phase_context':'phase_context_id','none':None}
class RegistryError(ValueError):pass

def canonical_hash(value):
 return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def safe_relative(value):
 if not isinstance(value,str) or not value or '\\' in value:raise RegistryError('unsafe_path')
 q=PurePosixPath(value)
 if q.is_absolute() or '..' in q.parts or q.as_posix()!=value or value=='.':raise RegistryError('unsafe_path')
 return q

def validate(registry):
 if registry.get('schema_version')!=SCHEMA:raise RegistryError('explicit_v2_schema_required')
 if registry.get('evidence') not in {'MEASURED','SIMULATED'}:raise RegistryError('invalid_evidence')
 if registry.get('declared_before_outcomes') is not True:raise RegistryError('prospective_declaration_missing')
 axis=registry.get('transfer_axis')
 if axis not in AXES:raise RegistryError('invalid_transfer_axis')
 runs=registry.get('runs')
 if not isinstance(runs,list) or not runs:raise RegistryError('empty_registry')
 sessions={};ids=set();units={};paths=set()
 for row in runs:
  if not isinstance(row.get('run_id'),str) or not re.fullmatch(r'run_[A-Za-z0-9_-]+',row['run_id']):raise RegistryError('unsafe_run_id')
  if row['run_id'] in ids:raise RegistryError('duplicate_run')
  ids.add(row['run_id']);stage=row.get('stage')
  if stage not in ROLES:raise RegistryError('invalid_stage')
  for name in ['session_id','device_id_hash','model_family','device_model_unit']:
   if not isinstance(row.get(name),str) or not row[name]:raise RegistryError('missing_identity:'+name)
  if sessions.setdefault(row['session_id'],stage)!=stage:raise RegistryError('session_role_leakage')
  unit=(row['device_id_hash'],row['model_family'])
  if units.setdefault(row['device_model_unit'],unit)!=unit:raise RegistryError('unit_identity_changed')
  protocol=row.get('analysis_protocol',{})
  if type(protocol.get('max_tokens')) is not int or protocol['max_tokens']<=0:raise RegistryError('unfrozen_max_tokens')
  for name in ['stratum','model_revision','engine_revision','stop_rules_id']:
   if not isinstance(protocol.get(name),str) or not protocol[name]:raise RegistryError('unfrozen_protocol:'+name)
  if protocol.get('service_endpoint_rule')!='first_progress_at_or_after_offset':raise RegistryError('unfrozen_endpoint_rule')
  lag=protocol.get('endpoint_lag_max_ns')
  if type(lag) is not int or lag<0:raise RegistryError('invalid_endpoint_lag')
  windows=protocol.get('service_window_offsets_ns');previous=-1
  if not isinstance(windows,list) or not windows:raise RegistryError('missing_service_windows')
  for window in windows:
   if not isinstance(window,list) or len(window)!=2 or any(type(t) is not int or t<0 for t in window) or not previous<=window[0]<window[1]:raise RegistryError('invalid_service_window')
   previous=window[1]
  if 'raw_relative_path' in row:
   path=str(safe_relative(row['raw_relative_path']))
   if path in paths:raise RegistryError('duplicate_raw_path')
   paths.add(path)
   if row['session_id'] not in PurePosixPath(path).parts or row['run_id'] not in PurePosixPath(path).parts:raise RegistryError('nested_path_identity_mismatch')
  if AXES[axis] is not None and not row.get(AXES[axis]):raise RegistryError('missing_transfer_group')
 transfer=[r for r in runs if r['stage']=='transfer'];development=[r for r in runs if r['stage']!='transfer']
 if axis=='none' and transfer:raise RegistryError('none_axis_cannot_have_transfer_roles')
 if transfer:
  key=AXES[axis]
  if {r[key] for r in transfer}&{r[key] for r in development}:raise RegistryError('transfer_axis_leakage')
  if axis in {'device','model_family'} and {r['device_model_unit'] for r in transfer}&{r['device_model_unit'] for r in development}:raise RegistryError('transfer_unit_leakage')
 return {'sessions':sessions,'registry_sha256':canonical_hash(registry),'physical_admission':'NOT_ESTABLISHED'}

def link_child(parent,child):
 """Validate an explicit immutable parent→child registry declaration.

The parent must predeclare complete additional slots and a REQUIRED set per
stage. This implementation supports full prospective slots, not adaptive N.
It never drops missing reservations or overwrites a model's legacy split hash.
"""
 validate(parent);validate(child)
 if child.get('parent_registry_sha256')!=canonical_hash(parent):raise RegistryError('parent_hash_changed')
 if child.get('evidence')!=parent['evidence'] or child.get('transfer_axis')!=parent['transfer_axis']:raise RegistryError('child_scope_changed')
 prior={r['run_id']:r for r in parent['runs']};now={r['run_id']:r for r in child['runs']}
 for id,row in prior.items():
  if id not in now or now[id]!=row:raise RegistryError('parent_roles_or_protocol_overwritten')
 additions=parent.get('prospective_child_slots',[])
 if not isinstance(additions,list):raise RegistryError('invalid_prospective_slots')
 reserved={r['run_id']:r for r in additions}
 if len(reserved)!=len(additions) or set(reserved)&set(prior):raise RegistryError('duplicate_reservations')
 if set(now)-set(prior)!=set(reserved):raise RegistryError('missing_or_extra_reserved_slot')
 for id,row in reserved.items():
  if now[id]!=row:raise RegistryError('reserved_slot_modified_after_parent')
 required=parent.get('child_required_by_stage')
 if not isinstance(required,dict) or required!=child.get('required_by_stage'):raise RegistryError('required_sets_not_parent_bound')
 for stage,ids in required.items():
  if stage not in ROLES or not isinstance(ids,list) or len(ids)!=len(set(ids)) or set(ids)!={r['run_id'] for r in child['runs'] if r['stage']==stage}:raise RegistryError('required_stage_set_incomplete')
 return {'parent_registry_sha256':canonical_hash(parent),'child_registry_sha256':canonical_hash(child),'mode':'PREDECLARED_COMPLETE_CHILD_SLOTS','legacy_frozen_split_overwrite':False,'adaptive_N_selection':'NOT_SUPPORTED_NOT_CLAIMED'}

def validate_model_binding(model,parent,child):
 links=link_child(parent,child)
 if model.get('schema_version')!='w6-service-model-2':raise RegistryError('legacy_model_requires_legacy_evaluate')
 if model.get('parent_registry_sha256')!=links['parent_registry_sha256'] or model.get('evaluation_registry_sha256')!=links['child_registry_sha256']:raise RegistryError('model_registry_hash_mismatch')
 allowed={r['run_id'] for r in parent['runs'] if r['stage'] in {'identification','calibration'}}
 used=model.get('fit_run_ids')
 if not isinstance(used,list) or not used or len(used)!=len(set(used)) or not set(used)<=allowed:raise RegistryError('confirmation_or_unknown_read_by_fit')
 return {'status':'PASS_STRUCTURAL_BINDING','physical_model_qualification':'NOT_ESTABLISHED'}
