from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parents[1]
receipt=ROOT/'submissions/integration/attempt_001'
out=ROOT/'artifacts/integration/attempt_001'
errors=[]
for name,status in [('detail','job_succeeded'),('instances','instance_success')]:
 data=json.loads((receipt/(name+'_003.json')).read_text())['data']
 if name=='detail' and data.get('status')!=status:errors.append('platform_not_terminal_success')
 if name=='instances' and not any(x.get('instance_status')==status for x in data):errors.append('instance_not_terminal_success')
logs=json.loads((receipt/'logs_003.json').read_text())['data']['logs']
if not any('exit code 0' in x.get('message','') for x in logs):errors.append('missing_exit_zero')
freeze=json.loads((receipt/'source_freeze.json').read_text())
for row in freeze['files']:
 if hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()!=row['sha256']:errors.append('source_changed:'+row['path'])
result=json.loads((out/'result.json').read_text())
if result['status']!='PASS_CPU_INTEGRATION' or any(c['exit_code']!=c['expected'] for c in result['checks']):errors.append('checks_failed')
if result['GPU_requests']!=0 or result['cap_writes']!=0:errors.append('unexpected_hardware_actions')
tests=(out/'contract_tests.stderr.txt').read_text()
if not re.search(r'Ran 38 tests',tests) or not tests.strip().endswith('OK'):errors.append('test_scope_not_38_passes')
index=json.loads((out/'raw_attempt_index.json').read_text())
if not any(r['outcome_status']=='FAIL' for r in index['all_attempts']):errors.append('failure_dropped')
report={'status':'PASS_SOFTWARE' if not errors else 'FAIL','errors':errors,'tests_passed':38,'indexed_attempts':len(index['all_attempts']),'failed_attempts_retained':sum(r['outcome_status']=='FAIL' for r in index['all_attempts']),'source_files_verified':len(freeze['files']),'all_small_projects_complete':False,'full_goal_status':'ACTIVE_INCOMPLETE','physical_admission':'NOT_RUN','unsupported':['real_model_inference','device_completion_barrier','physical_actuator_validation','DC_PCC_measurement','registry_v2_service_fit_evaluation','adaptive_sample_size'],'job_id':json.loads((receipt/'submit.stdout.json').read_text())['data']['job_id']}
(ROOT/'VERIFIED_RESUBMISSION_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2));raise SystemExit(bool(errors))
