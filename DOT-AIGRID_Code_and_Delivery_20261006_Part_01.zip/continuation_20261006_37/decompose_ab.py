from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent;DATA=WS/'continuation_20261006_36'
rows=[];bindings=[]
for session in ['s1','s2']:
 for arm in ['A','B']:
  a=DATA/'artifacts'/('pair_'+session)/'attempt_001'/arm
  host=[json.loads(x) for x in (a/'host_events.jsonl').read_text().splitlines()]
  def event(name):
   x=[e for e in host if e['event']==name]
   if len(x)!=1:raise ValueError('event_not_unique:'+name)
   return x[0]
  timing=json.loads((a/'instrumentation_timing.json').read_text())
  start=event('request_start')['host_visible_ns'];terminal=event('engine_terminal')['engine_visible_ns']
  drain=event('host_drain_observed')['host_visible_ns'];closure=event('closure_candidate_ack')
  points=[timing['begin_ns'],start,terminal,drain,closure['controller_issue_ns'],closure['controller_return_ns'],timing['end_ns']]
  if points!=sorted(points):raise ValueError('clock_order')
  names=['pre_request_configuration','request_to_host_terminal','host_terminal_to_host_drain','drain_to_close_issue','close_RPC','close_return_to_extraction_end']
  parts={n:y-x for n,x,y in zip(names,points,points[1:])}
  if sum(parts.values())!=timing['elapsed_ns']:raise ValueError('accounting_mismatch')
  rows.append({'session':session,'arm':arm,'source_namespace':str(a.relative_to(WS)),
               'raw_acquisition_id':event('request_start')['acquisition_id'],'components_ns':parts,
               'total_ns':timing['elapsed_ns']})
  for n in ['host_events.jsonl','instrumentation_timing.json']:
   p=a/n;bindings.append({'path':str(p.relative_to(WS)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
diff=[]
for session in ['s1','s2']:
 a,b=[next(x for x in rows if x['session']==session and x['arm']==arm) for arm in ['A','B']]
 parts={k:b['components_ns'][k]-a['components_ns'][k] for k in a['components_ns']}
 diff.append({'session':session,'B_minus_A_components_ns':parts,'B_minus_A_total_ns':b['total_ns']-a['total_ns']})
result={'status':'PASS_EXACT_OBSERVED_TIME_PARTITION','rows':rows,'paired_differences':diff,'sources':bindings,
        'unmeasured_setup_costs':['Audited scheduler construction/file open occurs during engine initialization outside this timing scope'],
        'first_request_compilation_cache_effect':'NOT_SEPARATED','raw_ID_reuse':'Use source_namespace and boot ID; identical acquisition label is not a global unique key',
        'overhead_acceptable':'NOT_QUALIFIED_NO_PRESPECIFIED_THRESHOLD','I05_complete':False,'full_goal_complete':False}
out=ROOT/'AB_COMPONENT_COST_AUDIT.json'
if out.exists():raise FileExistsError(out)
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'paired_differences':diff,'overhead_acceptable':result['overhead_acceptable']},indent=2))
