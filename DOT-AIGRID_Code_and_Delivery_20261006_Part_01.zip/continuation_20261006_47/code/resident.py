from pathlib import Path
import os,sys,json,time,hashlib,asyncio,subprocess,ast,statistics,traceback
from source_guard import check
ROOT=Path(__file__).resolve().parents[1];WS=ROOT.parent
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def inventory():
 p=subprocess.run(['nvidia-smi','--query-gpu=index,name,uuid,power.limit,temperature.gpu,memory.total','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10,check=True)
 rows=[]
 for line in p.stdout.splitlines():
  i,n,u,c,t,m=[x.strip() for x in line.split(',')];rows.append({'index':int(i),'name':n,'uuid_sha256':hashlib.sha256(u.encode()).hexdigest(),'cap_W':float(c),'temperature_C':float(t),'memory_MiB':float(m)})
 if len(rows)!=1:raise RuntimeError('one_allocated_GPU_required')
 return rows[0]
def no_compute():
 p=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True,timeout=10,check=True)
 if p.stdout.strip():raise RuntimeError('compute_process_remains_or_foreign')
def length_bin(n):
 for k,(a,b) in [('short',(64,128)),('medium',(256,512)),('long',(768,1280))]:
  if a<=n<=b:return k
 return 'outside_reference_bins'
def select(screen,tasks):
 selected=[]
 for label,target,preferred in [('short',96,'writing'),('medium',384,'code'),('long',1024,'reasoning')]:
  candidates=[x for x in screen if x['task_id'] not in selected and tasks[x['task_id']]['domain']==preferred]
  candidates.sort(key=lambda x:(x['censored'],x['actual_length_bin']!=label,tasks[x['task_id']]['domain']!=preferred,abs(x['useful_tokens']-target),x['task_id']))
  selected.append(candidates[0]['task_id'])
 return selected
class Resident:
 def __init__(self,nv,device,out,deadline):self.nv=nv;self.device=device;self.out=out;self.deadline=deadline;self.engine=None;self.context=None;self.blocked=False;self.counter=[]
 def energy(self,label):
  a=time.monotonic_ns();v=self.nv.nvmlDeviceGetTotalEnergyConsumption(self.device);b=time.monotonic_ns()
  if type(v) is not int or v<0:raise RuntimeError('invalid_energy_counter')
  x={'label':label,'query_begin_ns':a,'arrival_ns':b,'energy_mJ':v,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'boundary':'GPU_REPORTED_NVML_NOT_DC_OR_ALL_RAILS'};self.counter.append(x);return x
 async def idle(self):
  rows=[]
  for _ in range(8):
   a=time.monotonic_ns();p=self.nv.nvmlDeviceGetPowerUsage(self.device);t=self.nv.nvmlDeviceGetTemperature(self.device,0);b=time.monotonic_ns()
   rows.append({'query_begin_ns':a,'arrival_ns':b,'power_W':p/1000,'temperature_C':t,'native_sensor_timestamp':None});await asyncio.sleep(.25)
  return rows
 async def close(self):
  from adapters.worker_barrier import ClosureGate
  ack=await ClosureGate(self.engine,lambda x:None,source_qualified=True,timeout_s=10).close()
  if await self.engine.reset_prefix_cache() is not True:raise RuntimeError('cache_reset_not_acknowledged')
  return ack
 async def initialize(self,session):
  from vllm.engine.arg_utils import AsyncEngineArgs
  from vllm.v1.engine.async_llm import AsyncLLM
  os.environ['W6_SCHED_AUDIT_PATH']=str(session/'scheduler_all.jsonl');self.scheduler_path=session/'scheduler_all.jsonl'
  model=json.loads((ROOT/'MODEL_INPUT.json').read_text())['local_model_root'];self.model=Path(model)
  args=AsyncEngineArgs(model=model,tokenizer=model,trust_remote_code=False,dtype='bfloat16',max_model_len=4096,max_num_seqs=1,max_num_batched_tokens=4096,enable_prefix_caching=False,gpu_memory_utilization=.15,enforce_eager=True,enable_log_requests=False,disable_log_stats=True,seed=17,async_scheduling=True,scheduler_cls='adapters.scheduler_audit.AuditedAsyncScheduler',worker_extension_cls='adapters.worker_extension.DOTWorkerExtension')
  self.engine=AsyncLLM.from_engine_args(args)
  if type(self.engine.engine_core).__name__!='AsyncMPClient':raise RuntimeError('private_engine_client_required')
  c=self.engine.vllm_config.parallel_config
  if any(getattr(c,k)!=1 for k in ['tensor_parallel_size','pipeline_parallel_size','data_parallel_size']):raise RuntimeError('single_worker_required')
  self.tokenizer=self.engine.get_tokenizer();e=json.loads((self.model/'generation_config.json').read_text())['eos_token_id'];self.eos=tuple(e if isinstance(e,list) else [e])
  original_add=self.engine._add_request
  async def add(request,*args,**kwargs):
   if self.context is None or self.context['binding']:raise RuntimeError('unowned_or_multiple_request')
   self.context['binding'].append({'external_request_id':self.context['identity']['request_id'],'internal_request_id':request.request_id,'binding_source':'AFTER_OFFICIAL_ASSIGN_REQUEST_ID','host_observed_ns':time.monotonic_ns()})
   return await original_add(request,*args,**kwargs)
  self.engine._add_request=add
  original_generate=self.engine.generate
  async def generate(*args,**kwargs):
   async for output in original_generate(*args,**kwargs):
    if self.context is None:raise RuntimeError('unowned_output')
    if output.finished:self.context['text']=output.outputs[0].text
    yield output
  self.engine.generate=generate
  return await self.close()
 async def request(self,task,mode,dest,phase,max_tokens=1536):
  if self.blocked or time.monotonic()+150>=self.deadline:raise RuntimeError('ADMISSION_CLOSED_OR_BUDGET_STOP')
  if not await self.engine.is_paused() or self.engine.output_processor.request_states:raise RuntimeError('resident_idle_not_ready')
  dest.mkdir(parents=True,exist_ok=False)
  from adapters.acquisition_identity import identity_for_output
  identity=identity_for_output(dest,WS);identity['request_id']=mode+'_'+identity['request_id'];identity['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
  self.context={'identity':identity,'binding':[],'text':''};events=[];sampler=None;hook=False;begin=time.monotonic_ns();start=self.energy(str(dest.relative_to(self.out))+':cycle_start')
  write(dest/'identity.json',identity);pre=await self.idle();write(dest/'pre_idle.json',pre)
  stream=(dest/'host_events.jsonl').open('x')
  def sink(event):
   if sampler:sampler.check()
   e={**event,**identity};events.append(e)
   if mode!='OFF':stream.write(json.dumps(e)+'\n');stream.flush()
  try:
   if mode!='OFF':
    from adapters.nvml_sampler import NVMLSampler
    sampler=NVMLSampler(self.nv,self.device,dest/'nvml.jsonl',identity);sampler.start()
   offset=self.scheduler_path.stat().st_size
   if mode=='FULL':
    installed=await self.engine.collective_rpc('dot_install_sample_events',args=(list(self.eos),));write(dest/'hook_install.json',installed);hook=True
   await self.engine.resume_generation()
   if await self.engine.is_paused():raise RuntimeError('resume_not_acknowledged')
   from adapters.vllm_host import HostEngineBridge,RequestContract
   from adapters.tokenizer_input import single_token_ids
   from vllm.sampling_params import SamplingParams,RequestOutputKind
   prompt=single_token_ids(self.tokenizer.apply_chat_template([{'role':'user','content':task['prompt']}],tokenize=True,add_generation_prompt=True),max_input_tokens=1024)
   params=SamplingParams(n=1,max_tokens=max_tokens,temperature=0.,seed=17,ignore_eos=False,output_kind=RequestOutputKind.CUMULATIVE)
   await HostEngineBridge(self.engine,sink,timeout_s=120,cleanup_timeout_s=10).run({'prompt_token_ids':prompt},params,RequestContract(identity['request_id'],max_tokens,self.eos,17))
   async with asyncio.timeout(20):
    ack=await self.close();write(dest/'closure_ack.json',ack)
    if hook:
     data=await self.engine.collective_rpc('dot_read_sample_events');write(dest/'sample_events.json',data)
     release=await self.engine.collective_rpc('dot_release_sample_events');write(dest/'hook_release.json',release);hook=False
     with self.scheduler_path.open() as f:f.seek(offset);(dest/'scheduler_events.jsonl').write_text(f.read())
    post=await self.idle();write(dest/'post_idle.json',post)
   if sampler:sampler.close();sampler=None
   write(dest/'request_binding.json',self.context['binding']);write(dest/'host_observations.json',events)
   (dest/'public_output.txt').write_text(self.context['text'])
   terminal=[x for x in events if x['event']=='engine_terminal']
   if len(terminal)!=1 or terminal[0]['stop_class'] not in ['natural_eos_token_host_verified','length']:raise RuntimeError('unsupported_terminal_reason')
   t=terminal[0];natural=t['stop_class']=='natural_eos_token_host_verified';useful=t['completed_tokens']-int(natural)
   if mode=='FULL':
    from adapters.resident_join import join
    binding=self.context['binding']
    if len(data)!=1 or len(binding)!=1 or binding[0]['external_request_id']!=identity['request_id']:raise RuntimeError('FULL_request_binding_failed')
    sched=[json.loads(x) for x in (dest/'scheduler_events.jsonl').read_text().splitlines()]
    joined=join(data[0],sched,binding[0],natural);write(dest/'sample_join.json',joined)
    if any(not x.get('released') or not x.get('restored_original_sample') for x in release):raise RuntimeError('hook_restoration_failed')

   useful_events=[]
   for x in events:
    if x['event'] in ['host_progress','engine_terminal']:
     count=x['new_tokens']-int(x['event']=='engine_terminal' and natural)
     if count>0:useful_events.append((x['engine_visible_ns'],count))
   request_start=next(x['host_visible_ns'] for x in events if x['event']=='request_start');times=[x[0] for x in useful_events];batch=any(x[1]!=1 for x in useful_events)
   code_syntax=None
   if task['domain']=='code':
    text=self.context['text'].strip()
    if text.startswith('```'):text='\n'.join(text.splitlines()[1:-1])
    try:ast.parse(text);code_syntax=True
    except SyntaxError:code_syntax=False
   end=self.energy(str(dest.relative_to(self.out))+':cycle_end')
   if end['energy_mJ']<start['energy_mJ']:raise RuntimeError('energy_counter_reset')
   result={'status':'PASS_RESIDENT_REQUEST_OBSERVATION','phase':phase,'task_id':task['id'],'mode':mode,'identity':identity,'generated_token_sha256':t['generated_token_sha256'],'output_text_sha256':hashlib.sha256(self.context['text'].encode()).hexdigest(),'reported_tokens':t['completed_tokens'],'useful_tokens':useful,'actual_length_bin':length_bin(useful),'stop_class':t['stop_class'],'censored':not natural,'code_syntax_valid':code_syntax,'semantic_quality_certified':False,'cycle_energy_J':(end['energy_mJ']-start['energy_mJ'])/1000,'cycle_latency_ms':(end['arrival_ns']-start['query_begin_ns'])/1e6,'TTFT_ms':(times[0]-request_start)/1e6 if times else None,'TPOT_ms':(times[-1]-times[0])/1e6/(useful-1) if useful>1 and times else None,'ITL_ms':[(b-a)/1e6 for a,b in zip(times,times[1:])] if not batch else None,'host_output_batched':batch,'e2e_ms':(t['engine_visible_ns']-request_start)/1e6,'pre_idle_power_mean_W':statistics.mean(x['power_W'] for x in pre),'post_idle_power_mean_W':statistics.mean(x['power_W'] for x in post),'pre_temperature_C':pre[-1]['temperature_C'],'post_temperature_C':post[-1]['temperature_C'],'operational_recovery_completed':True,'physical_state_equivalence':False,'energy_start':start,'energy_end':end,'J_W6':None,'acceptability_decision':None}
   write(dest/'result.json',result);return result
  except BaseException:
   self.blocked=True;(dest/'failure_traceback.txt').write_text(traceback.format_exc());write(dest/'result.json',{'status':'FAIL_REQUEST_ADMISSION_CLOSED','task_id':task['id'],'mode':mode,'phase':phase,'J_W6':None});raise
  finally:
   stream.close()
   if sampler:sampler.close()
   self.context=None
 async def shutdown(self):
  if self.engine is not None:self.engine.shutdown(timeout=10);self.engine=None

async def run(out):
 import pynvml as nv
 nv.nvmlInit();nvdev=nv.nvmlDeviceGetHandleByIndex(0);before=inventory();no_compute();write(out/'gpu_before.json',before)
 r=Resident(nv,nvdev,out,time.monotonic()+6400);allocation_start=r.energy('job_start');sessions=[];selected=None
 try:
  from verify_engine_abi import verify
  abi=verify();write(out/'abi.json',abi)
  if abi['status']!='PASS_SOFTWARE_ABI':raise RuntimeError('engine_ABI_drift')
  import importlib.metadata as md
  dist=md.distribution('vllm')
  for label in ['12','24','28']:
   source=json.loads((WS/f'continuation_20261006_{label}/artifacts/engine_source/attempt_001/result.json').read_text())
   for x in source['files']:
    if hashlib.sha256(Path(dist.locate_file(x['path'])).read_bytes()).hexdigest()!=x['sha256']:raise RuntimeError('pinned_source_drift')
  import vllm.envs as ve
  if ve.VLLM_ALLOW_INSECURE_SERIALIZATION:raise RuntimeError('insecure_serialization_enabled')
  model=json.loads((ROOT/'MODEL_INPUT.json').read_text())
  for x in model['files']:
   p=Path(model['local_model_root'])/x['path'];h=hashlib.sha256()
   with p.open('rb') as f:
    for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
   if p.stat().st_size!=x['bytes'] or h.hexdigest()!=x['sha256']:raise RuntimeError('model_input_drift')
  pool=json.loads((ROOT/'TASK_POOL.json').read_text())['tasks'];tasks={x['id']:x for x in pool};protocol=json.loads((ROOT/'AB_DEVICE_PROTOCOL.json').read_text())
  for sid in protocol['sessions']:
   if time.monotonic()+150>=r.deadline:break
   session=out/sid;session.mkdir();start=r.energy(sid+':session_start');beg=time.monotonic_ns()
   ack=await r.initialize(session);write(session/'initial_closure.json',ack);ready=r.energy(sid+':engine_ready')
   for i in range(3):await r.request({'id':'warmup','domain':'writing','prompt':'Reply with only the word OK.'},'OFF',session/'warmup'/str(i),'WARMUP',32)
   warm=r.energy(sid+':warmup_end')
   if selected is None:
    screen=[]
    for task in pool:screen.append(await r.request(task,'MIN',session/'screen'/task['id'],'SCREEN'))
    selected=select(screen,tasks);write(out/'TASK_SELECTION.json',{'selected_ids':selected,'selection_uses':'Length/domain/censoring only; no energy or latency','screen_results':[{'task_id':x['task_id'],'useful_tokens':x['useful_tokens'],'actual_length_bin':x['actual_length_bin'],'censored':x['censored']} for x in screen]})
   main=[]
   for task_id in selected:
    for rep,order in enumerate(protocol['main_orders'][sid],1):
     for mode in order:main.append(await r.request(tasks[task_id],mode,session/'main'/task_id/f'r{rep}'/mode,'MAIN'))
   for task_id in selected:
    for rep in range(2):
     group=main[rep*3+selected.index(task_id)*6:rep*3+selected.index(task_id)*6+3]
     if len({(x['generated_token_sha256'],x['stop_class'],x['useful_tokens']) for x in group})!=1:
      write(session/'output_mismatch.json',{'task_id':task_id,'rep':rep+1,'reason':'All observations retained; no matched-output effect claim'})
   before_exit=r.energy(sid+':before_shutdown');await r.shutdown();no_compute();end=r.energy(sid+':session_end')
   record={'session':sid,'status':'PASS_RESIDENT_SESSION','main_requests':len(main),'initialization_energy_J':(ready['energy_mJ']-start['energy_mJ'])/1000,'warmup_energy_J':(warm['energy_mJ']-ready['energy_mJ'])/1000,'shutdown_energy_J':(end['energy_mJ']-before_exit['energy_mJ'])/1000,'session_energy_J':(end['energy_mJ']-start['energy_mJ'])/1000,'session_wall_ns':time.monotonic_ns()-beg,'J_W6':None};write(session/'result.json',record);sessions.append(record)
   print(json.dumps({'session':sid,'status':record['status'],'main_requests':len(main)}),flush=True)
  after=inventory();write(out/'gpu_after.json',after)
  if (before['uuid_sha256'],before['cap_W'])!=(after['uuid_sha256'],after['cap_W']):raise RuntimeError('GPU_or_cap_changed')
  job_end=r.energy('job_end');return {'status':'PASS_RESIDENT_DEVELOPMENT_RUN' if len(sessions)==3 else 'PARTIAL_BUDGET_STOP','sessions':sessions,'selected_task_ids':selected,'total_counter_energy_J':(job_end['energy_mJ']-allocation_start['energy_mJ'])/1000,'allocated_GPU_count':1,'model_initializations':len(sessions),'physical_control_writes':0,'J_W6':None,'formal_confirmation':False,'full_original_W6_complete':False}
 finally:
  try:await r.shutdown()
  finally:write(out/'job_energy_marks.json',r.counter);nv.nvmlShutdown()

if __name__=='__main__':
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 for key,name in {'XDG_CACHE_HOME':'cache','HF_HOME':'hf','VLLM_CACHE_ROOT':'vllm','TORCHINDUCTOR_CACHE_DIR':'torch','TRITON_CACHE_DIR':'triton'}.items():
  p=out/name;p.mkdir();os.environ[key]=str(p)
 short=WS/'t'/hashlib.sha256(str(out).encode()).hexdigest()[:5];short.mkdir(exist_ok=False)
 if len(str(short).encode())+37>107:raise RuntimeError('IPC_path_too_long')
 os.environ.update(TMPDIR=str(short),VLLM_RPC_BASE_PATH=str(short),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',VLLM_LOGGING_LEVEL='WARNING',TOKENIZERS_PARALLELISM='false')
 try:result=asyncio.run(run(out))
 except BaseException as e:
  (out/'failure_traceback.txt').write_text(traceback.format_exc());result={'status':'FAIL_RESIDENT_RUN','error_type':type(e).__name__,'J_W6':None,'full_original_W6_complete':False}
 write(out/'result.json',result);print(json.dumps(result));raise SystemExit(not result['status'].startswith(('PASS','PARTIAL')))
