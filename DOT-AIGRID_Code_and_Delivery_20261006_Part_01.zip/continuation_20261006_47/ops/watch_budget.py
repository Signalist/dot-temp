from pathlib import Path
import json,os,time,subprocess,datetime
ROOT=Path(__file__).resolve().parents[1];REC=ROOT/'submissions/resident/attempt_001'
job=json.loads((REC/'submit.stdout.json').read_text())['data']['job_id'];OUT=REC/'watch';OUT.mkdir(exist_ok=False)
env=dict(os.environ)
for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(k,None)
created=None
for index in range(300):
 try:
  p=subprocess.run(['qzcli','detail',job,'--brief'],env=env,capture_output=True,text=True,timeout=30)
  (OUT/f'detail_{index:03}.json').write_text(p.stdout);d=json.loads(p.stdout)
  if d.get('ok'):
   data=d['data'];created=int(data['created_at'])/1000;status=data['status'];elapsed=time.time()-created
   print(json.dumps({'job':job,'status':status,'conservative_seconds_since_job_creation':round(elapsed)}),flush=True)
   if status in ['job_succeeded','job_failed','job_stopped']:break
  else:print(json.dumps({'observation_failed':True,'same_job_retained':job}),flush=True)
 except (subprocess.TimeoutExpired,json.JSONDecodeError) as e:print(json.dumps({'observation_error':type(e).__name__,'same_job_retained':job}),flush=True)
 if created is not None and time.time()-created>=7100:
  p=subprocess.run(['qzcli','stop',job],env=env,capture_output=True,text=True,timeout=30);(OUT/'budget_stop.json').write_text(p.stdout)
  print('BUDGET_STOP_REQUESTED_NO_RESUBMISSION',flush=True)
 time.sleep(30)
