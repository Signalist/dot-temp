"""Current-path, python3-only qzcli repair launcher. Default dry-run; append-only receipts."""
from pathlib import Path
import argparse,json,os,subprocess,hashlib,shlex,datetime
ROOT=Path(__file__).resolve().parents[1];WORKSPACE=ROOT.parent
CONFIG={'workspace':'ws-9dcc0e1f-80a4-4af2-bc2f-0e352e7b17e6','group':'lcg-79b2ad0e-a375-43f3-a0b1-b4ce79710fd7','project':'project-4493c9f7-2fbf-459a-ad90-749a5a420b91','quota':'79fe954a-be92-4772-ac0b-94ad8a79b7bb','gpu':1,'priority':4}
TASKS={'engine_source':('capture_engine_source.py','docker.sii.shaipower.online/inspire-studio/vllm-openai:v0.20.2'),'real_smoke':('real_smoke.py','docker.sii.shaipower.online/inspire-studio/vllm-openai:v0.20.2'),'engine_abi':('verify_engine_abi.py','docker.sii.shaipower.online/inspire-studio/vllm-openai:v0.20.2'),'integration':('run_integration.py','docker.sii.shaipower.online/inspire-studio/pytorch:25.06-py3')}
def command_for(task,out,freeze):
 script=ROOT/'code'/TASKS[task][0]
 if not script.is_file() or not script.resolve().is_relative_to(WORKSPACE):raise ValueError('missing_or_unsafe_script')
 if 'DOT-GFM' in str(script) or not out.resolve().is_relative_to(WORKSPACE):raise ValueError('stale_or_unsafe_path')
 return ' '.join(shlex.quote(s) for s in ['env','PYTHONDONTWRITEBYTECODE=1','HF_HUB_OFFLINE=1','TRANSFORMERS_OFFLINE=1','timeout','240s','python3',str(script),str(out),str(freeze)])
def launch(task,execute):
 parent=ROOT/'submissions'/task;parent.mkdir(parents=True,exist_ok=True)
 attempt=1
 while (parent/f'attempt_{attempt:03}').exists():attempt+=1
 receipt=parent/f'attempt_{attempt:03}';receipt.mkdir();out=ROOT/'artifacts'/task/f'attempt_{attempt:03}'
 files=[{'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for folder in ['code','tests'] for p in sorted((ROOT/folder).rglob('*.py'))]
 files.append({'path':'MODEL_INPUT.json','sha256':hashlib.sha256((ROOT/'MODEL_INPUT.json').read_bytes()).hexdigest()})
 files.append({'path':'STOP_PROTOCOL.json','sha256':hashlib.sha256((ROOT/'STOP_PROTOCOL.json').read_bytes()).hexdigest()})
 freeze=receipt/'source_freeze.json';freeze.write_text(json.dumps({'schema_version':'w6-recovery-1','timestamp_status':'LOCAL_TIMESTAMP_ONLY','operator_freeze_status':'UNCONFIRMED','files':files},indent=2)+'\n')
 argv=['qzcli','create','--name',f'w6-aigrid-scheduler-source-1006-a{attempt:03}','-w',CONFIG['workspace'],'-g',CONFIG['group'],'--project',CONFIG['project'],'--quota-id',CONFIG['quota'],'--gpu','1','--priority','4','--no-wait','--image',TASKS[task][1],'--cmd',command_for(task,out,freeze)]
 env=dict(os.environ)
 for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(k,None)
 for stage,extra in [('dryrun',['--dry-run']),*([('submit',[])] if execute else [])]:
  result=subprocess.run(argv+extra,env=env,capture_output=True,text=True,timeout=60)
  (receipt/(stage+'.stdout.json')).write_text(result.stdout);(receipt/(stage+'.stderr.txt')).write_text(result.stderr)
  d=json.loads(result.stdout)
  if result.returncode or not d.get('ok'):
   (receipt/'failure.json').write_text(json.dumps({'stage':stage,'exit_code':result.returncode,'platform_error':d.get('error')},indent=2));raise RuntimeError('platform_'+stage+'_failed_see_receipt')
 (receipt/'launch.json').write_text(json.dumps({'schema_version':'w6-recovery-1','task':task,'attempt':attempt,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'artifact_directory':str(out),'execute_submission':execute,'source_sha256':hashlib.sha256((ROOT/'code'/TASKS[task][0]).read_bytes()).hexdigest(),'known_contract':'BOUNDED_PUBLIC_LOCAL_MODEL_SINGLE_REQUEST_NO_CAP_WRITES'},indent=2)+'\n')
 print(json.dumps({'task':task,'attempt':attempt,'receipt':str(receipt),'job_id':d.get('data',{}).get('job_id'),'dry_run_only':not execute}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--task',required=True,choices=TASKS);p.add_argument('--execute-submission',action='store_true');a=p.parse_args();launch(a.task,a.execute_submission)
