from pathlib import Path
import json,hashlib,sys,argparse
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from adapters.acquisition_identity import identity_for_output,verify_rows
from source_guard import check
def verify(case,snapshot):
 rec=ROOT/'submissions'/case/'attempt_001';out=ROOT/'artifacts'/case/'attempt_001';check(ROOT,rec/'source_freeze.json')
 d=json.loads((rec/f'detail_{snapshot}.json').read_text());i=json.loads((rec/f'instances_{snapshot}.json').read_text());l=json.loads((rec/f'logs_{snapshot}.json').read_text())
 if not d.get('ok') or d['data']['status']!='job_succeeded' or not i.get('ok') or len(i['data'])!=1 or i['data'][0]['instance_status']!='instance_success':raise ValueError('platform_not_verified_success')
 if not l.get('ok') or not any('exit code 0' in x.get('message','').lower() for x in l.get('data',{}).get('logs',[])):raise ValueError('exit_zero_unproven')
 r=json.loads((out/'result.json').read_text())
 if not r['status'].startswith('PASS_ISOLATED_TERMINAL'):raise ValueError('restart_audit_not_complete')
 ids=[];rows=[];bindings=[];stage_marks={}
 for stage in ['terminal','fresh_recovery']:
  a=out/stage;expected=identity_for_output(a,ROOT.parent);ids.append(expected['acquisition_id'])
  if json.loads((a/'acquisition_identity.json').read_text())!=expected:raise ValueError('identity_namespace_mismatch')
  host=[json.loads(x) for x in (a/'host_events.jsonl').read_text().splitlines()];nvml=[json.loads(x) for x in (a/'nvml.jsonl').read_text().splitlines()];marks=json.loads((a/'energy_counter.json').read_text())
  verify_rows(host,expected);verify_rows(nvml,expected);verify_rows(marks,expected)
  ack=json.loads((a/'closure_ack.json').read_text());w=ack['worker_ack']
  if ack['frontend_request_states']!=0 or not w['cuda_all_stream_sync_ack'] or ack['next_request_admitted']:raise ValueError('closure_invalid')
  if not ack['controller_issue_ns']<=w['worker_query_begin_ns']<=w['worker_return_ns']<=ack['controller_return_ns']:raise ValueError('worker_clock_order')
  if any(x['boot_id']!=w['boot_id'] for x in host+nvml+marks):raise ValueError('clock_domain_mismatch')
  if json.loads((a/'shutdown_check.json').read_text())['remaining_compute_processes']!=0:raise ValueError('shutdown_unconfirmed')
  if stage=='terminal':
   rejection=json.loads((a/'admission_rejection.json').read_text())
   if rejection['new_operation_called'] or rejection['new_request_admitted'] or rejection['state']!='CLOSED':raise ValueError('admission_not_closed')
  else:
   terminal=[x for x in host if x['event']=='engine_terminal']
   if len(terminal)!=1 or terminal[0]['stop_class']!='natural_eos_token_host_verified':raise ValueError('fresh_recovery_failed')
   reference=json.loads((ROOT.parent/'continuation_20261006_43/artifacts/pilot_s1/attempt_001/OFF/metrics.json').read_text())
   if terminal[0]['generated_token_sha256']!=reference['generated_token_sha256']:raise ValueError('fresh_task_output_changed')
  stage_marks[stage]={x['label']:x for x in marks}
  rows.append({'stage':stage,'acquisition_id':expected['acquisition_id'],'host_rows':len(host),'NVML_rows':len(nvml),'worker_sync_ack':True,'remaining_compute_processes':0})
  for p in sorted(a.rglob('*')):
   if p.is_file() and not {'cache','hf','torch','triton','vllm','__pycache__'}.intersection(p.relative_to(a).parts) and p.suffix in ['.json','.jsonl','.txt']:bindings.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 if len(set(ids))!=2:raise ValueError('duplicate_acquisition_identity')
 first=stage_marks['terminal']['cycle_start'];last=stage_marks['fresh_recovery']['cycle_end'];aend=stage_marks['terminal']['cycle_end'];bstart=stage_marks['fresh_recovery']['cycle_start']
 if first['boot_id']!=last['boot_id'] or aend['arrival_ns']>bstart['query_begin_ns']:raise ValueError('restart_clock_order')
 if any(x['energy_mJ'] is None for x in [first,last,aend,bstart]):raise ValueError('counter_missing')
 if not first['energy_mJ']<=aend['energy_mJ']<=bstart['energy_mJ']<=last['energy_mJ']:raise ValueError('counter_reset_or_reordering')
 energy=(last['energy_mJ']-first['energy_mJ'])/1000;gap=(bstart['energy_mJ']-aend['energy_mJ'])/1000
 instance=i['data'][0];running=(int(instance['finished_at'])-int(instance['started_at']))*1000000
 if running!=int(instance['running_time_ms'])*1000000:raise ValueError('platform_duration_inconsistent')
 report={'status':'PASS_ISOLATED_TERMINAL_REJECTION_SHUTDOWN_FRESH_RECOVERY_AND_RAW_INTEGRITY','case':case,'stages':rows,'raw_bindings':bindings,'whole_restart_counter_energy_J_including_interprocess_gap':energy,'interprocess_gap_counter_energy_J':gap,'counter_window_latency_ms':(last['arrival_ns']-first['query_begin_ns'])/1e6,'platform_running_ns':running,'parent_all_stage_wall_ns':r['process_total_wall_ns'],'energy_boundary':'GPU_REPORTED_NVML_NOT_DC_OR_PCC','physical_initial_final_state_equivalence':False,'same_failed_engine_resume':False,'continuous_service_recovery_qualified':False,'J_W6':None,'full_goal_complete':False}
 p=ROOT/f'VERIFIED_{case}_{snapshot}.json'
 if p.exists():raise FileExistsError(p)
 p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'case':case,'status':report['status'],'energy_counter_window_J':energy}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--snapshot',required=True);a=p.parse_args();verify(a.case,a.snapshot)
