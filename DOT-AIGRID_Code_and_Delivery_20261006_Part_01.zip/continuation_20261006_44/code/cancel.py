"""Single bounded local public-model GPU smoke, no actuator or device timing claims."""
from pathlib import Path
import sys,os,json,hashlib,subprocess,time,asyncio
ROOT=Path(__file__).resolve().parents[1]
from source_guard import check

def gpu_inventory():
 r=subprocess.run(['nvidia-smi','--query-gpu=index,name,uuid,power.limit,temperature.gpu,memory.total','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10,check=True)
 rows=[]
 for line in r.stdout.splitlines():
  index,name,uuid,cap,temp,memory=[x.strip() for x in line.split(',')]
  rows.append({'index':int(index),'name':name,'uuid_sha256':hashlib.sha256(uuid.encode()).hexdigest(),'power_limit_W':float(cap),'temperature_C':float(temp),'memory_MiB':float(memory)})
 return rows

async def smoke(out):
 from verify_engine_abi import verify
 abi=verify();(out/'abi.json').write_text(json.dumps(abi,indent=2)+'\n')
 if abi['status']!='PASS_SOFTWARE_ABI':raise RuntimeError('pinned_engine_ABI_failed')
 capture=ROOT.parent/'continuation_20261006_12/artifacts/engine_source/attempt_001/result.json'
 import importlib.metadata as metadata
 dist=metadata.distribution('vllm')
 for row in json.loads(capture.read_text())['files']:
  if hashlib.sha256(Path(dist.locate_file(row['path'])).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('closure_source_drift')
 import vllm.envs as venv
 if venv.VLLM_ALLOW_INSECURE_SERIALIZATION:raise RuntimeError('insecure_serialization_must_remain_disabled')
 inputs=json.loads((ROOT/'MODEL_INPUT.json').read_text());model=Path(inputs['local_model_root'])
 for row in inputs['files']:
  p=model/row['path'];h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
  if p.stat().st_size!=row['bytes'] or h.hexdigest()!=row['sha256']:raise RuntimeError('local_model_hash_drift')
 before=gpu_inventory();(out/'gpu_before.json').write_text(json.dumps(before,indent=2)+'\n')
 if len(before)!=1:raise RuntimeError('single_allocated_GPU_required')
 process=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True,timeout=10,check=True)
 if process.stdout.strip():raise RuntimeError('GPU_compute_process_present_before_session')
 from vllm.engine.arg_utils import AsyncEngineArgs
 from vllm.v1.engine.async_llm import AsyncLLM
 from vllm.sampling_params import SamplingParams,RequestOutputKind
 from adapters.vllm_host import RequestContract,HostEngineBridge
 args=AsyncEngineArgs(model=str(model),tokenizer=str(model),trust_remote_code=False,dtype='bfloat16',max_model_len=512,max_num_seqs=1,gpu_memory_utilization=0.15,enforce_eager=True,enable_log_requests=False,disable_log_stats=True,seed=17,worker_extension_cls='adapters.worker_extension.DOTWorkerExtension')
 import pynvml
 from adapters.nvml_sampler import NVMLSampler
 pynvml.nvmlInit();device=pynvml.nvmlDeviceGetHandleByIndex(0)
 uuid=pynvml.nvmlDeviceGetUUID(device);uuid=uuid.decode() if isinstance(uuid,bytes) else uuid
 if hashlib.sha256(uuid.encode()).hexdigest()!=before[0]['uuid_sha256']:raise RuntimeError('NVML_device_identity_mismatch')
 identity={'acquisition_id':'gpu_only_cancel_001','run_id':'run_cancel','session_id':'session_cancel','request_id':'w6_public_cancel_001','boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'clock_id':'host_monotonic_ns','evidence':'MEASURED_GPU_ONLY'}
 from adapters.acquisition_identity import identity_for_output
 unique_identity=identity_for_output(out,ROOT.parent);identity.update(unique_identity)
 (out/'acquisition_identity.json').write_text(json.dumps(unique_identity,indent=2)+'\n')
 from adapters.pilot_meter import PilotMeter
 sampler=PilotMeter(pynvml,device,out,identity,periodic=True)
 engine=None;started=time.monotonic_ns();terminal=[];abort_tasks=[];cancel_evidence={};request_error=None
 sampler.mark('cycle_start')
 with (out/'host_events.jsonl').open('x') as stream:
  def sink(event):
   sampler.check();event={**event,**identity}
   stream.write(json.dumps(event,allow_nan=False)+'\n');stream.flush()
   if event['event']=='engine_terminal':terminal.append(event)
   if event['event']=='host_progress' and not abort_tasks:
    cancel_evidence['trigger_completed_tokens']=event['completed_tokens']
    abort_tasks.append(asyncio.create_task(do_abort()))
  async def do_abort():
   cancel_evidence['abort_issue_ns']=time.monotonic_ns()
   await engine.abort(identity['request_id'])
   cancel_evidence['abort_return_ns']=time.monotonic_ns()
   sink({'event':'official_abort_return','host_visible_ns':cancel_evidence['abort_return_ns']})
  try:
   sampler.start()
   engine=AsyncLLM.from_engine_args(args)
   sampler.mark('engine_ready');await asyncio.sleep(.5);sampler.check()
   tokenizer=engine.get_tokenizer()
   prompt=tokenizer.apply_chat_template([{'role':'user','content':'List integers from one to twenty, one per line.'}],tokenize=True,add_generation_prompt=True)
   from adapters.tokenizer_input import single_token_ids
   prompt=single_token_ids(prompt,max_input_tokens=480)
   config=json.loads((model/'generation_config.json').read_text());eos=config['eos_token_id'];eos=tuple(eos if isinstance(eos,list) else [eos])
   params=SamplingParams(n=1,max_tokens=32,temperature=0.0,seed=17,ignore_eos=False,output_kind=RequestOutputKind.CUMULATIVE)
   contract=RequestContract(identity['request_id'],32,eos,17)
   bridge=HostEngineBridge(engine,sink,timeout_s=30,cleanup_timeout_s=10)
   from adapters.worker_barrier import ClosureGate,PrivateSessionAdmission
   client_type=type(engine.engine_core).__name__
   if client_type!='AsyncMPClient':raise RuntimeError('unsupported_engine_client')
   config=engine.vllm_config.parallel_config
   if any(getattr(config,k)!=1 for k in ['tensor_parallel_size','pipeline_parallel_size','data_parallel_size']):raise RuntimeError('single_worker_parallelism_required')
   (out/'closure_scope.json').write_text(json.dumps({'client_type':client_type,'TP':1,'PP':1,'DP':1,'extension':config.worker_extension_cls,'RPC':'string_method_no_insecure_serialization'},indent=2)+'\n')
   gate=ClosureGate(engine,sink,source_qualified=True,timeout_s=10)
   owner=PrivateSessionAdmission(gate)
   try:
    result=await owner.run(lambda:bridge.run({'prompt_token_ids':prompt},params,contract))
   except Exception as error:
    request_error={'type':type(error).__name__,'message':str(error)}
    (out/'request_error.json').write_text(json.dumps(request_error,indent=2)+'\n')
    result={'status':'REQUEST_INTERRUPTED','completed_tokens':cancel_evidence.get('trigger_completed_tokens',0)}
   if not abort_tasks:raise RuntimeError('prespecified_abort_trigger_not_observed')
   await asyncio.wait_for(abort_tasks[0],10)
   closure=await owner.close()
   (out/'closure_ack.json').write_text(json.dumps(closure,indent=2)+'\n')
   from adapters.worker_barrier import BarrierError
   forbidden_calls=[]
   async def forbidden_operation():
    forbidden_calls.append(True)
    raise RuntimeError('FAILED_SESSION_ADMITTED_NEW_REQUEST')
   try:await owner.run(forbidden_operation)
   except BarrierError:pass
   else:raise RuntimeError('closed_admission_not_rejected')
   if forbidden_calls:raise RuntimeError('closed_admission_invoked_operation')
   (out/'admission_rejection.json').write_text(json.dumps({'state':owner.state,'new_operation_called':False,'new_request_admitted':False})+'\n')

   if terminal and terminal[-1]['stop_class']!='cancel':raise RuntimeError('request_finished_before_cancel_case_observed')
   if request_error and (request_error['type']!='ContractError' or request_error['message']!='stream_closed_without_terminal'):raise RuntimeError('unexpected_request_error_not_cancel_evidence')
   cancel_evidence.update(request_error=request_error,terminal_stop_class=terminal[-1]['stop_class'] if terminal else 'NO_TERMINAL_AFTER_ABORT',next_request_started=False,cancel_mechanism='official_abort_then_abort_pause_and_worker_sync')
   (out/'cancel_evidence.json').write_text(json.dumps(cancel_evidence,indent=2)+'\n')
   await asyncio.sleep(.5);sampler.check()
  finally:
   try:
    if engine is not None:engine.shutdown(timeout=10)
    sampler.mark('cycle_end')
   finally:
    try:sampler.close()
    finally:pynvml.nvmlShutdown()
 processes_after=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True,timeout=10,check=True)
 if processes_after.stdout.strip():raise RuntimeError('compute_process_remains_after_shutdown')
 (out/'shutdown_check.json').write_text(json.dumps({'remaining_compute_processes':0,'thermal_return_to_initial':'NOT_QUALIFIED'})+'\n')
 after=gpu_inventory();(out/'gpu_after.json').write_text(json.dumps(after,indent=2)+'\n')
 if [(r['uuid_sha256'],r['power_limit_W']) for r in before]!=[(r['uuid_sha256'],r['power_limit_W']) for r in after]:raise RuntimeError('power_limit_or_device_changed')
 return {'status':'PASS_OBSERVED_BOUNDED_CANCEL_CLOSURE','evidence':'MEASURED_HOST_OUTPUT_GPU_ONLY','engine_version':'0.20.2','NVML_rows':sampler.rows,'same_acquisition_id':identity['acquisition_id'],'sensor_time_mapping':'NOT_CALIBRATED_QUERY_DOMAIN_ONLY','GPU_requests':1,'model_loads':1,'cap_writes':0,'max_tokens':32,'concurrency':1,'prespecified_expected_stop_class':'cancel_path','terminal_censored':True,'terminal_stop_class':cancel_evidence['terminal_stop_class'],'completed_tokens':result['completed_tokens'],'host_bridge':result,'host_wall_duration_ns':time.monotonic_ns()-started,'natural_eos_device_time':None,'device_completion_barrier':'POST_COMPLETION_SINGLE_WORKER_SYNC_ACK_ONLY','physical_power_measurement':'NOT_RUN','DC_PCC':'NOT_RUN','operator_scientific_freeze':'UNCONFIRMED','full_goal_complete':False}

if __name__=='__main__':
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 for key,folder in {'XDG_CACHE_HOME':'cache','HF_HOME':'hf','VLLM_CACHE_ROOT':'vllm','TORCHINDUCTOR_CACHE_DIR':'torch','TRITON_CACHE_DIR':'triton'}.items():
  p=out/folder;p.mkdir();os.environ[key]=str(p)
 short_parent=ROOT.parent/'t';short_parent.mkdir(exist_ok=True)
 short=short_parent/hashlib.sha256(str(out).encode()).hexdigest()[:4];short.mkdir(exist_ok=False)
 if len(str(short).encode())+1+36>107:raise RuntimeError('IPC_directory_too_long')
 os.environ['TMPDIR']=str(short);os.environ['VLLM_RPC_BASE_PATH']=str(short)
 (out/'runtime_paths.json').write_text(json.dumps({'temporary_directory':str(short),'maximum_generated_socket_path_bytes':len(str(short).encode())+37,'workspace_contained':True},indent=2)+'\n')
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',VLLM_LOGGING_LEVEL='WARNING',TOKENIZERS_PARALLELISM='false')
 try:result=asyncio.run(smoke(out))
 except BaseException as e:
  import traceback
  (out/'failure_traceback.txt').write_text(traceback.format_exc());result={'status':'FAIL_REAL_GPU_SMOKE','error_type':type(e).__name__,'cap_writes':0,'GPU_requests':'UNCONFIRMED_SEE_EVENTS','full_goal_complete':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(not result['status'].startswith('PASS'))
