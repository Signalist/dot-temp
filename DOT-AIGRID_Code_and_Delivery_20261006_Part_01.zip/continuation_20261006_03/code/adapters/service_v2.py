"""Explicit v2 diagnostic analysis. No safety or physical qualification.
Uses unchanged legacy measurement validation and its diagnostic OLS algorithm.
All selected attempts must be sealed, successful and registry bound; failures
remain in the all-attempt ledger. No adaptive N or success-only substitution.
"""
from pathlib import Path
import sys,json
WORKSPACE=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(WORKSPACE/'source_package/W6_CPU_Research_and_GPU_Handoff_20261004/gpu_handoff'))
from w6kit.core import validate_run,require,integrate,read_json,sha
from adapters.registry_v2 import validate,canonical_hash,link_child,validate_model_binding
from adapters.run_index import scan_attempts,contained_file

def write_exclusive(output,value):
    with Path(output).open('x') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def selected_folders(root,split,stages):
    validate(split)
    expected=[r for r in split['runs'] if r['stage'] in stages]
    require(bool(expected),'no registered runs for selected stages')
    required=split.get('required_by_stage',{})
    for stage in stages:
        require(set(required.get(stage,[]))=={r['run_id'] for r in expected if r['stage']==stage},'stage required set incomplete')
    # Only selected development paths are opened by fitting.
    for row in expected:
        path=row.get('raw_relative_path')
        require(isinstance(path,str),'explicit attempt path required')
        parts=Path(path).parts
        require(len(parts)==5 and parts[1]==row['stage'] and parts[2]==row['session_id'] and parts[3]==row['run_id'],'nested path identity mismatch')
        folder=contained_file(root,path)
        require(folder.is_dir(),'missing preregistered attempt:'+row['run_id'])
        seal=contained_file(folder,'acquisition_manifest.json')
        require(seal.is_file(),'missing acquisition seal')
        m=read_json(seal)
        for key,value in [('session_id',row['session_id']),('run_id',row['run_id']),('attempt_id',parts[4])]:require(m.get(key)==value,'seal identity mismatch:'+key)
        require(m.get('status')=='SUCCESS','selected attempt failed or incomplete')
        require(not (folder/'failure.json').exists(),'selected failure must not be dropped')
        records=m.get('files',[])
        require({r['path'] for r in records}>={'manifest.json','power.jsonl','events.jsonl'},'missing sealed numerical payload')
        require(len({r['path'] for r in records})==len(records),'duplicate payload')
        for record in records:
            file=contained_file(folder,record['path']);require(file.is_file() and file.stat().st_size==record['bytes'] and sha(file)==record['sha256'],'payload integrity mismatch')
        yield row,folder

def admitted_windows(folder, split, expected_run_id):
    m, channels, events = validate_run(folder, "w6-dc")
    require(m["run_id"] == expected_run_id, "manifest differs from selected registry run")
    validate(split)
    require(m["evidence"] == split["evidence"], "split evidence mismatch")
    registry = {r["run_id"]: r for r in split["runs"]}
    require(m["run_id"] in registry, "run absent from frozen split")
    r = registry[m["run_id"]]
    require(r["session_id"] == m["session_id"] and r["stage"] == m["stage"], "split mismatch")
    require(r["device_model_unit"] == m["device_model_unit"], "device/model split mismatch")
    require(r["device_id_hash"] == m["device_id_hash"] and r["model_family"] == m["model_family"], "physical device/model family mismatch")
    for key, value in r["analysis_protocol"].items():
        require(m.get(key) == value, "manifest differs from frozen analysis protocol: " + key)
    points = []
    prog = {p["t_ns"]: p["completed_tokens"] for p in events["progress"]}
    eos = events["eos_visible"][0]["true_eos_ns"]
    for window in m.get("service_window_offsets_ns", []):
        selected = []
        for offset in window:
            target = offset+events["request_start"][0]["t_ns"]
            candidates = [t for t in prog if target <= t <= target+m["endpoint_lag_max_ns"]]
            require(bool(candidates), "no progress endpoint within frozen lag bound")
            selected.append(min(candidates))
        a, b = selected
        require(a < b, "bracketed service window collapsed")
        require(events["request_start"][0]["t_ns"] <= a < b <= eos, "service window outside useful work")
        dt = (b-a)/1e9
        require(b-a > 2*m["clock_error_ns"], "service window too short for timing error")
        delta = prog[b]-prog[a]
        require(delta >= 0, "decreasing count")
        mean_p = integrate(channels["gpu_dc"], a, b, True)/dt
        points.append({"run_id": m["run_id"], "session_id": m["session_id"],
                       "stage": m["stage"], "stratum": m["stratum"], "actual_dynamic_mean_W": mean_p,
                       "interval_rate_tokens_s": delta/dt,
                       "rate_clock_only_lower": delta/(dt+2*m["clock_error_ns"]/1e9),
                       "rate_clock_only_upper": delta/(dt-2*m["clock_error_ns"]/1e9)})
    require(bool(points), "no predeclared service windows")
    return m, points

def fit_service(root, split_path, child_path, output):
    split = read_json(split_path)
    child = read_json(child_path)
    links = link_child(split, child)
    points, inputs, strata, labels = [], {}, set(), set()
    for record, folder in selected_folders(root, split, {"identification", "calibration"}):
        # Confirmation outcomes are never opened by fitting.
        m, rows = admitted_windows(folder, split, record["run_id"])
        points.extend(rows)
        strata.add(m["stratum"])
        labels.add(m["evidence"])
        inputs[record["run_id"]] = {name: sha(folder / name) for name in ("manifest.json", "power.jsonl", "events.jsonl")}
    require(len(strata) == 1 and len(labels) == 1, "do not pool strata or simulation with measurements")
    require(len(points) >= 3, "too few identification points")
    xs = [p["actual_dynamic_mean_W"] for p in points]
    ys = [p["interval_rate_tokens_s"] for p in points]
    require(len(set(xs)) >= 3, "fewer than 3 attained power levels")
    xbar, ybar = sum(xs)/len(xs), sum(ys)/len(ys)
    denom = sum((x-xbar)**2 for x in xs)
    b = sum((x-xbar)*(y-ybar) for x, y in zip(xs, ys))/denom
    a = ybar-b*xbar
    grouped = {}
    for x, y in zip(xs, ys):
        grouped.setdefault(x, []).append(y)
    ordered = sorted((x, sum(v)/len(v)) for x, v in grouped.items())
    slopes = [(y1-y0)/(x1-x0) for (x0, y0), (x1, y1) in zip(ordered, ordered[1:])]
    out = {"evidence": labels.pop(), "model": "diagnostic_OLS_rate=a+b*interval_actual_dynamic_power",
           "a": a, "b": b, "stratum": strata.pop(), "domain_W": [min(xs), max(xs)],
           "points": points, "source_sha256": inputs, "split_sha256": sha(split_path),
           "empirical_nondecreasing_means": all(x >= 0 for x in slopes),
           "empirical_concave_secants": all(a >= b for a, b in zip(slopes, slopes[1:])),
           "residual_max_abs_tokens_s": max(abs(y-(a+b*x)) for x, y in zip(xs, ys)),
           "claims": "Point estimate only; interval means do not identify pointwise causal s(p), hard envelopes, concavity, or independence."}
    out.update({"schema_version":"w6-service-model-2", **links, "evaluation_registry_sha256":canonical_hash(child), "fit_run_ids":sorted(inputs)})
    require(not Path(output).exists(), "model output already exists: do not overwrite a frozen fit")
    write_exclusive(output, out)
    return out

def evaluate_service(root, parent_path, split_path, model_path, output, stages):
    model, split = read_json(model_path), read_json(split_path)
    validate_model_binding(model, read_json(parent_path), split)
    require(set(stages) <= {"confirmation","ablation","transfer"} and bool(stages), "invalid evaluation stages")
    rows = []
    for record, folder in selected_folders(root, split, set(stages)):
        m, points = admitted_windows(folder, split, record["run_id"])
        require(m["evidence"] == model["evidence"], "simulation/measurement mixing")
        for p in points:
            x = p["actual_dynamic_mean_W"]
            predicted = model["a"]+model["b"]*x
            rows.append({**p, "prediction": predicted,
                         "residual_tokens_s": p["interval_rate_tokens_s"]-predicted,
                         "in_calibration_stratum": m["stratum"] == model["stratum"],
                         "in_calibration_power_domain": model["domain_W"][0] <= x <= model["domain_W"][1]})
    require(rows, "no test runs")
    out = {"evidence": model["evidence"], "frozen_model_sha256": sha(model_path), "rows": rows,
           "warning": "No refitting; diagnostic residuals only. No safety or inferential pass threshold was specified."}
    require(not Path(output).exists(), "evaluation exists; preserve original")
    out.update({"evaluation_registry_sha256":canonical_hash(split), "stages":sorted(stages), "all_attempts":scan_attempts(root), "successful_only_filter_applied":False})
    write_exclusive(output, out)
    return out
