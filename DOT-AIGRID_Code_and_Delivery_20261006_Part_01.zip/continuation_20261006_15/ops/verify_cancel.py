from pathlib import Path
import json,hashlib,argparse
ROOT=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);a=p.parse_args();receipt=ROOT/'submissions/real_smoke/attempt_001';out=ROOT/'artifacts/real_smoke/attempt_001';errors=[]
d=json.loads((receipt/f'detail_{a.snapshot}.json').read_text());status=d.get('data',{}).get('status')
if status not in ['job_succeeded','job_failed','job_stopped']:print(json.dumps({'status':'PENDING','platform_status':status,'restart':False}));raise SystemExit(2)
if status!='job_succeeded':errors.append('job_not_success')
instances=json.loads((receipt/f'instances_{a.snapshot}.json').read_text()).get('data',[])
if not any(r.get('instance_status')=='instance_success' for r in instances):errors.append('instance_not_success')
logs=json.loads((receipt/f'logs_{a.snapshot}.json').read_text()).get('data',{}) or {}
if not any('exit code 0' in r.get('message','') for r in logs.get('logs',[])):errors.append('exit_zero_missing')
for r in json.loads((receipt/'source_freeze.json').read_text())['files']:
 if hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()!=r['sha256']:errors.append('source_changed:'+r['path'])
if (out/'closure_ack.json').is_file():
 ack=json.loads((out/'closure_ack.json').read_text());scope=json.loads((out/'closure_scope.json').read_text());result=json.loads((out/'result.json').read_text());events=[json.loads(x) for x in (out/'host_events.jsonl').read_text().splitlines()]
 if scope['client_type']!='AsyncMPClient' or [scope[k] for k in ['TP','PP','DP']]!=[1,1,1]:errors.append('unsupported_scope')
 if scope['extension']!='adapters.worker_extension.DOTWorkerExtension':errors.append('extension_mismatch')
 w=ack['worker_ack']
 if not (ack['controller_issue_ns']<=w['worker_query_begin_ns']<=w['worker_return_ns']<=ack['controller_return_ns']):errors.append('clock_order')
 if w['cuda_all_stream_sync_ack'] is not True or w['boot_id']!=events[0]['boot_id']:errors.append('worker_ack_or_clock_domain')
 if ack['next_request_admitted'] is not False or ack['device_EOS_ns'] is not None or ack['physical_safety_certified'] is not False:errors.append('unsupported_claim_or_resume')
 if result['status']!='PASS_OBSERVED_BOUNDED_CANCEL_CLOSURE' or result['terminal_stop_class'] not in {'cancel','NO_TERMINAL_AFTER_ABORT'} or result['GPU_requests']!=1 or result['cap_writes']!=0:errors.append('invalid_result')
 before=json.loads((out/'gpu_before.json').read_text());after=json.loads((out/'gpu_after.json').read_text())
 if [(r['uuid_sha256'],r['power_limit_W']) for r in before]!=[(r['uuid_sha256'],r['power_limit_W']) for r in after]:errors.append('device_cap_changed')
 cancel=json.loads((out/'cancel_evidence.json').read_text())
 if not cancel['abort_issue_ns']<=cancel['abort_return_ns']<=ack['controller_issue_ns']:errors.append('abort_closure_order_invalid')
 if cancel['next_request_started'] is not False or not 0<cancel['trigger_completed_tokens']<32:errors.append('cancel_trigger_or_admission_invalid')
 terminal=[r for r in events if r['event']=='engine_terminal']
 if terminal and (len(terminal)!=1 or terminal[0]['stop_class']!='cancel' or terminal[0]['censored'] is not True):errors.append('cancel_terminal_not_verified')
 if not terminal and cancel.get('request_error')!={'type':'ContractError','message':'stream_closed_without_terminal'}:errors.append('unexplained_missing_cancel_terminal')
else:errors.append('missing_closure_ack');ack=None
report={'status':'PASS_OBSERVED_SINGLE_WORKER_CANCEL_CLOSURE' if not errors else 'FAIL','errors':errors,'ack':ack,'insecure_serialization_enabled':False,'claim':'Observed first-host-progress official cancellation followed by abort-pause and model-owning worker CUDA synchronize; no resume','full_device_EOS_timing':'NOT_QUALIFIED','cancel_timeout_recovery':'ONE_CANCEL_CLOSURE_ONLY_NO_RECOVERY_OR_TIMEOUT_TEST','GPU_inflight_at_abort':'NOT_MEASURED','work_saved_by_cancel':'NOT_PROVED','runtime_completed_tokens_semantics':'Host count at cancel trigger, not total completed useful work','device_exclusivity_and_external_clients':'NOT_CERTIFIED','physical_safety_or_DC_PCC':'NOT_CERTIFIED','full_goal_complete':False}
(ROOT/f'VERIFIED_CANCEL_{a.snapshot}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(bool(errors))
