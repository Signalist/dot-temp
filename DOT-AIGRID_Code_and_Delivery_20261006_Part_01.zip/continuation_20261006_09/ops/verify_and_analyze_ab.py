from pathlib import Path
import json,hashlib,csv,statistics,argparse
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);args=p.parse_args()
protocol=json.loads((ROOT/'AB_PROTOCOL.json').read_text());errors=[];pairs=[];sessions=[]
for task,attempt,session in [('ab_s1','attempt_001','s1'),('ab_s2','attempt_002','s2')]:
 receipt=ROOT/'submissions'/task/attempt;out=ROOT/'artifacts'/task/attempt
 detail=json.loads((receipt/f'detail_{args.snapshot}.json').read_text());status=detail.get('data',{}).get('status')
 if status not in {'job_succeeded','job_failed','job_stopped'}:print(json.dumps({'status':'PENDING','task':task,'platform_status':status,'do_not_restart':True}));raise SystemExit(2)
 if status!='job_succeeded':errors.append(task+':platform_not_success')
 instances=json.loads((receipt/f'instances_{args.snapshot}.json').read_text()).get('data',[])
 if not any(x.get('instance_status')=='instance_success' for x in instances):errors.append(task+':instance_not_success')
 logs=json.loads((receipt/f'logs_{args.snapshot}.json').read_text()).get('data',{}) or {}
 if not any('exit code 0' in x.get('message','') for x in logs.get('logs',[])):errors.append(task+':exit_zero_missing')
 freeze=json.loads((receipt/'source_freeze.json').read_text())
 for row in freeze['files']:
  if hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()!=row['sha256']:errors.append(task+':source_changed:'+row['path'])
 if not (out/'result.json').is_file():errors.append(task+':missing_result');continue
 result=json.loads((out/'result.json').read_text())
 if result['status']!='PASS_MEASURED_HOST_AB_COLLECTION' or result['GPU_requests']!=5 or result['cap_writes']!=0:errors.append(task+':invalid_result')
 records=[json.loads(x) for x in (out/'all_requests.jsonl').read_text().splitlines()]
 expected=[(0,'warmup')]+[(r['pair'],m) for r in protocol['sessions'][session] for m in r['order']]
 if [(r['pair'],r['mode']) for r in records]!=expected:errors.append(task+':frozen_order_not_followed')
 if any(r['terminal_stop_class']!='natural_eos_token_host_verified' or r['physical_admission']!='BLOCKED_DEVICE_BARRIER_UNQUALIFIED' for r in records):errors.append(task+':endpoint_or_claim_changed')
 events=[json.loads(x) for x in (out/'host_events.jsonl').read_text().splitlines()];power=[json.loads(x) for x in (out/'nvml.jsonl').read_text().splitlines()]
 if len({r['request_id'] for r in records})!=5:errors.append(task+':reused_request_identity')
 if any('text' in e or 'token_ids' in e for e in events):errors.append(task+':private_output_saved')
 if any(b['query_begin_ns']<=a['query_begin_ns'] for a,b in zip(power,power[1:])):errors.append(task+':clock_reorder')
 if len({e['acquisition_id'] for e in events+power})!=1:errors.append(task+':mixed_acquisition')
 for r in records:
  ev=[e for e in events if e['request_id']==r['request_id']]
  for kind in ['request_start','minimal_first_output','engine_terminal','host_drain_observed']:
   if sum(e['event']==kind for e in ev)!=1:errors.append(task+':event_count:'+kind)
  if r['mode']!='B' and any(e['event']=='host_progress' for e in ev):errors.append(task+':A_progress_log_enabled')
  if not power[0]['query_begin_ns']<r['request_start_ns']<r['request_end_ns']<power[-1]['arrival_ns']:errors.append(task+':NVML_does_not_bracket_request')
 before=json.loads((out/'gpu_before.json').read_text());after=json.loads((out/'gpu_after.json').read_text())
 if [(x['uuid_sha256'],x['power_limit_W']) for x in before]!=[(x['uuid_sha256'],x['power_limit_W']) for x in after]:errors.append(task+':device_cap_changed')
 for pair in [1,2]:
  rows={r['mode']:r for r in records if r['pair']==pair}
  if set(rows)!={'A','B'} or rows['A']['token_sequence_sha256']!=rows['B']['token_sequence_sha256']:errors.append(task+':output_mismatch');continue
  pairs.append({'session':session,'pair':pair,'frozen_order':'/'.join(next(r['order'] for r in protocol['sessions'][session] if r['pair']==pair)),'A_latency_ns':rows['A']['latency_ns_including_host_drain'],'B_latency_ns':rows['B']['latency_ns_including_host_drain'],'B_minus_A_latency_ns':rows['B']['latency_ns_including_host_drain']-rows['A']['latency_ns_including_host_drain'],'B_minus_A_TTFT_ns':rows['B']['TTFT_host_ns']-rows['A']['TTFT_host_ns'],'B_minus_A_controller_cpu_s':rows['B']['cpu_seconds']-rows['A']['cpu_seconds'],'A_log_bytes':rows['A']['host_log_bytes'],'B_log_bytes':rows['B']['host_log_bytes'],'terminal_outputs_equivalent':True})
 sessions.append({'session':session,'job_id':json.loads((receipt/'submit.stdout.json').read_text())['data']['job_id'],'UUID_hash':before[0]['uuid_sha256'],'requests':len(records),'NVML_rows':len(power)})
report={'status':'PASS_VERIFIED_DIAGNOSTIC_COLLECTION' if not errors else 'FAIL','errors':errors,'sessions':sessions,'pairs':len(pairs),'warmup_excluded':True,'median_B_minus_A_latency_ns':statistics.median(r['B_minus_A_latency_ns'] for r in pairs) if pairs else None,'median_B_minus_A_TTFT_ns':statistics.median(r['B_minus_A_TTFT_ns'] for r in pairs) if pairs else None,'decision':'INCONCLUSIVE_NO_PRESPECIFIED_ACCEPTABILITY_THRESHOLD','scope':protocol['claim_scope'],'I05_full_pass':False,'statistical_unit':'sessions, not tokens or callbacks; no iid population confidence interval from four pairs','total_cost_limit':'Controller-process CPU and host-log bytes only; engine workers, sampling overhead and calibrated energy excluded','device_time_instrumentation':'NOT_TESTED','all_small_projects_complete':False,'HTTP429_submission_failure_preserved':'submissions/ab_s2/attempt_001/failure.json'}
dest=ROOT/'03_calibration/pilot';dest.mkdir(parents=True,exist_ok=True)
if pairs:
 with (dest/'instrumentation_overhead.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
(dest/'instrumentation_decision.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(bool(errors))
