import unittest
from test_host_bridge import Fake,output,params,C
from adapters.vllm_host import HostEngineBridge,ContractError
class ABBridgeTests(unittest.IsolatedAsyncioTestCase):
 async def test_terminal_only_has_no_progress_log_and_matches_digest(self):
  digests=[]
  for enabled in [False,True]:
   events=[];bridge=HostEngineBridge(Fake([output([7]),output([7,2],'stop')]),events.append,observe_progress=enabled);result=await bridge.run('CPU_TEST',params(),C);digests.append(result['token_sequence_sha256'])
   self.assertEqual(sum(e['event']=='host_progress' for e in events),int(enabled));self.assertEqual(sum(e['event']=='minimal_first_output' for e in events),1)
  self.assertEqual(digests[0],digests[1])
 async def test_terminal_only_still_blocks_on_bad_terminal_identity(self):
  fake=Fake([output([7]),output([7,2],'stop',rid='wrong')]);bridge=HostEngineBridge(fake,lambda x:None,observe_progress=False)
  with self.assertRaises(ContractError):await bridge.run('CPU_TEST',params(),C)
  self.assertTrue(bridge.blocked);self.assertEqual(fake.aborts,1)
