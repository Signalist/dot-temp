from pathlib import Path
import os,sys,json,hashlib,time,asyncio,subprocess,resource
ROOT=Path(__file__).resolve().parents[1]
from source_guard import check
from real_smoke import gpu_inventory
async def run_ab(out,session):
 from verify_engine_abi import verify
 abi=verify();(out/'abi.json').write_text(json.dumps(abi,indent=2)+'\n')
 if abi['status']!='PASS_SOFTWARE_ABI':raise RuntimeError('pinned_engine_ABI_failed')
 inputs=json.loads((ROOT/'MODEL_INPUT.json').read_text());model=Path(inputs['local_model_root'])
 for row in inputs['files']:
  p=model/row['path'];h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
  if p.stat().st_size!=row['bytes'] or h.hexdigest()!=row['sha256']:raise RuntimeError('local_model_hash_drift')
 before=gpu_inventory();(out/'gpu_before.json').write_text(json.dumps(before,indent=2)+'\n')
 if len(before)!=1:raise RuntimeError('single_allocated_GPU_required')
 process=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True,timeout=10,check=True)
 if process.stdout.strip():raise RuntimeError('GPU_compute_process_present_before_session')
 from vllm.engine.arg_utils import AsyncEngineArgs
 from vllm.v1.engine.async_llm import AsyncLLM
 from vllm.sampling_params import SamplingParams,RequestOutputKind
 from adapters.vllm_host import RequestContract,HostEngineBridge
 args=AsyncEngineArgs(model=str(model),tokenizer=str(model),trust_remote_code=False,dtype='bfloat16',max_model_len=512,max_num_seqs=1,gpu_memory_utilization=0.15,enforce_eager=True,enable_log_requests=False,disable_log_stats=True,seed=17)
 import pynvml
 from adapters.nvml_sampler import NVMLSampler
 pynvml.nvmlInit();device=pynvml.nvmlDeviceGetHandleByIndex(0)
 uuid=pynvml.nvmlDeviceGetUUID(device);uuid=uuid.decode() if isinstance(uuid,bytes) else uuid
 if hashlib.sha256(uuid.encode()).hexdigest()!=before[0]['uuid_sha256']:raise RuntimeError('NVML_device_identity_mismatch')
 identity={'acquisition_id':'ab_'+session,'run_id':'run_ab_'+session,'session_id':session,'request_id':'session_scope','boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'clock_id':'host_monotonic_ns','evidence':'MEASURED_GPU_ONLY'}
 sampler=NVMLSampler(pynvml,device,out/'nvml.jsonl',identity)
 engine=None;current={};metrics=[]
 protocol=json.loads((ROOT/'AB_PROTOCOL.json').read_text())
 plan=[{'pair':0,'mode':'warmup'}]+[{'pair':p['pair'],'mode':mode} for p in protocol['sessions'][session] for mode in p['order']]
 with (out/'host_events.jsonl').open('x') as stream:
  def sink(event):
   sampler.check();event={**identity,**current,**event};stream.write(json.dumps(event,allow_nan=False)+'\n');stream.flush()
   if event['event']=='minimal_first_output':current['first_output_ns']=event['host_visible_ns']
   if event['event']=='engine_terminal':current['terminal_ns']=event['engine_visible_ns'];current['terminal_stop_class']=event['stop_class']
  try:
   engine=AsyncLLM.from_engine_args(args);sampler.start();await asyncio.sleep(.5);sampler.check()
   tokenizer=engine.get_tokenizer()
   from adapters.tokenizer_input import single_token_ids
   prompt=single_token_ids(tokenizer.apply_chat_template([{'role':'user','content':protocol['prompt']}],tokenize=True,add_generation_prompt=True),max_input_tokens=480)
   config=json.loads((model/'generation_config.json').read_text());eos=config['eos_token_id'];eos=tuple(eos if isinstance(eos,list) else [eos])
   for item in plan:
    current.clear();current.update(pair=item['pair'],mode=item['mode']);request_id=f"ab_{session}_p{item['pair']}_{item['mode']}"
    params=SamplingParams(n=1,max_tokens=32,temperature=0.,seed=17,ignore_eos=False,output_kind=RequestOutputKind.CUMULATIVE)
    contract=RequestContract(request_id,32,eos,17);bridge=HostEngineBridge(engine,sink,timeout_s=30,cleanup_timeout_s=10,observe_progress=item['mode']=='B')
    start=time.monotonic_ns();usage=resource.getrusage(resource.RUSAGE_SELF);position=stream.tell()
    result=await bridge.run({'prompt_token_ids':prompt},params,contract)
    end=time.monotonic_ns();after_usage=resource.getrusage(resource.RUSAGE_SELF)
    if current.get('terminal_stop_class')!='natural_eos_token_host_verified':raise RuntimeError('unexpected_censored_AB_request')
    row={**current,'session':session,'request_id':request_id,'request_start_ns':start,'request_end_ns':end,'latency_ns_including_host_drain':end-start,'TTFT_host_ns':current['first_output_ns']-start,'cpu_seconds':after_usage.ru_utime+after_usage.ru_stime-usage.ru_utime-usage.ru_stime,'host_log_bytes':stream.tell()-position,**result}
    metrics.append(row)
    with (out/'all_requests.jsonl').open('a') as m:m.write(json.dumps(row,allow_nan=False)+'\n')
    await asyncio.sleep(.2);sampler.check()
   await asyncio.sleep(.5)
  finally:
   try:sampler.close()
   finally:
    try:
     if engine is not None:engine.shutdown(timeout=10)
    finally:pynvml.nvmlShutdown()
 after=gpu_inventory();(out/'gpu_after.json').write_text(json.dumps(after,indent=2)+'\n')
 if [(r['uuid_sha256'],r['power_limit_W']) for r in before]!=[(r['uuid_sha256'],r['power_limit_W']) for r in after]:raise RuntimeError('device_or_cap_changed')
 for pair in [1,2]:
  pair_rows=[r for r in metrics if r['pair']==pair]
  if len(pair_rows)!=2 or len({r['token_sequence_sha256'] for r in pair_rows})!=1:raise RuntimeError('paired_output_mismatch')
 return {'status':'PASS_MEASURED_HOST_AB_COLLECTION','session':session,'GPU_requests':len(metrics),'warmup_requests':1,'paired_requests':4,'NVML_rows':sampler.rows,'cap_writes':0,'physical_admission':'NOT_QUALIFIED','full_goal_complete':False}

def main(session):
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 for key,folder in {'XDG_CACHE_HOME':'cache','HF_HOME':'hf','VLLM_CACHE_ROOT':'vllm','TORCHINDUCTOR_CACHE_DIR':'torch','TRITON_CACHE_DIR':'triton'}.items():
  p=out/folder;p.mkdir();os.environ[key]=str(p)
 parent=ROOT.parent/'t';parent.mkdir(exist_ok=True);short=parent/hashlib.sha256(str(out).encode()).hexdigest()[:4];short.mkdir(exist_ok=False)
 if len(str(short).encode())+37>107:raise RuntimeError('IPC_path_too_long')
 os.environ.update(TMPDIR=str(short),VLLM_RPC_BASE_PATH=str(short),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',VLLM_LOGGING_LEVEL='WARNING',TOKENIZERS_PARALLELISM='false')
 try:result=asyncio.run(run_ab(out,session))
 except BaseException as error:
  import traceback
  (out/'failure_traceback.txt').write_text(traceback.format_exc());result={'status':'FAIL_HOST_AB','error_type':type(error).__name__,'cap_writes':0,'full_goal_complete':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(not result['status'].startswith('PASS'))
