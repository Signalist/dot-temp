from pathlib import Path
import json,hashlib,argparse
ROOT=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);a=p.parse_args();receipt=ROOT/'submissions/real_smoke/attempt_001';out=ROOT/'artifacts/real_smoke/attempt_001';errors=[]
d=json.loads((receipt/f'detail_{a.snapshot}.json').read_text());status=d.get('data',{}).get('status')
if status not in ['job_succeeded','job_failed','job_stopped']:print(json.dumps({'status':'PENDING','platform_status':status,'restart':False}));raise SystemExit(2)
if status!='job_succeeded':errors.append('job_not_success')
instances=json.loads((receipt/f'instances_{a.snapshot}.json').read_text()).get('data',[])
if not any(r.get('instance_status')=='instance_success' for r in instances):errors.append('instance_not_success')
logs=json.loads((receipt/f'logs_{a.snapshot}.json').read_text()).get('data',{}) or {}
if not any('exit code 0' in r.get('message','') for r in logs.get('logs',[])):errors.append('exit_zero_missing')
for r in json.loads((receipt/'source_freeze.json').read_text())['files']:
 if hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()!=r['sha256']:errors.append('source_changed:'+r['path'])
if (out/'closure_ack.json').is_file():
 ack=json.loads((out/'closure_ack.json').read_text());scope=json.loads((out/'closure_scope.json').read_text());result=json.loads((out/'result.json').read_text());events=[json.loads(x) for x in (out/'host_events.jsonl').read_text().splitlines()]
 if scope['client_type']!='AsyncMPClient' or [scope[k] for k in ['TP','PP','DP']]!=[1,1,1]:errors.append('unsupported_scope')
 if scope['extension']!='adapters.worker_extension.DOTWorkerExtension':errors.append('extension_mismatch')
 w=ack['worker_ack']
 if not (ack['controller_issue_ns']<=w['worker_query_begin_ns']<=w['worker_return_ns']<=ack['controller_return_ns']):errors.append('clock_order')
 if w['cuda_all_stream_sync_ack'] is not True or w['boot_id']!=events[0]['boot_id']:errors.append('worker_ack_or_clock_domain')
 if ack['next_request_admitted'] is not False or ack['device_EOS_ns'] is not None or ack['physical_safety_certified'] is not False:errors.append('unsupported_claim_or_resume')
 if result['status']!='PASS_OBSERVED_BOUNDED_TIMEOUT_CLOSURE' or result['terminal_stop_class']!='TIMEOUT_EXCEPTION_NOT_ENGINE_REASON' or result['GPU_requests']!=1 or result['cap_writes']!=0:errors.append('invalid_result')
 before=json.loads((out/'gpu_before.json').read_text());after=json.loads((out/'gpu_after.json').read_text())
 if [(r['uuid_sha256'],r['power_limit_W']) for r in before]!=[(r['uuid_sha256'],r['power_limit_W']) for r in after]:errors.append('device_cap_changed')
 timeout=json.loads((out/'timeout_evidence.json').read_text())
 if timeout['exception']!='TimeoutError' or timeout['configured_request_timeout_ns']!=1000000 or timeout['host_bridge_blocked'] is not True or timeout['owner_final_state']!='CLOSED' or timeout['next_request_started'] is not False:errors.append('timeout_or_admission_not_verified')
 if not timeout['deadline_begin_ns']<timeout['exception_observed_after_cleanup_ns']<=ack['controller_issue_ns']:errors.append('timeout_closure_order_invalid')
 if sum(e['event']=='request_start' for e in events)!=1:errors.append('request_count_not_one')
else:errors.append('missing_closure_ack');ack=None
report={'status':'PASS_OBSERVED_SINGLE_WORKER_TIMEOUT_CLOSURE' if not errors else 'FAIL','errors':errors,'ack':ack,'insecure_serialization_enabled':False,'claim':'Observed one preset absolute request TimeoutError, latched admission and official abort-pause followed by worker CUDA synchronize, no resume','full_device_EOS_timing':'NOT_QUALIFIED','cancel_timeout_recovery':'ONE_TIMEOUT_CLOSURE_NO_RECOVERY_TRIAL','one_ms_physical_stop_guarantee':False,'device_exclusivity_and_external_clients':'NOT_CERTIFIED','physical_safety_or_DC_PCC':'NOT_CERTIFIED','full_goal_complete':False}
(ROOT/f'VERIFIED_TIMEOUT_{a.snapshot}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(bool(errors))
