"""Read installed source only: no imports of vLLM/torch, no model/GPU calls."""
from pathlib import Path
import sys,json,hashlib,importlib.metadata,ast
ROOT=Path(__file__).resolve().parents[1]
from source_guard import check
check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
dist=importlib.metadata.distribution('vllm')
if dist.version!='0.20.2':raise RuntimeError('version_drift')
targets=['vllm/v1/sample/sampler.py','vllm/v1/sample/metadata.py','vllm/v1/outputs.py','vllm/v1/worker/gpu_model_runner.py']
records=[];missing=[]
for name in targets:
 p=Path(dist.locate_file(name))
 if not p.is_file():missing.append(name);continue
 b=p.read_bytes();dest=out/'installed_source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 tree=ast.parse(b);methods=[]
 for cls in [n for n in ast.walk(tree) if isinstance(n,ast.ClassDef)]:
  for n in cls.body:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and any(x in n.name for x in ['update_from_output','schedule','request','scheduler','async']):methods.append({'class':cls.name,'method':n.name,'line':n.lineno,'async':isinstance(n,ast.AsyncFunctionDef)})
 records.append({'path':name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'methods':methods})
original=json.loads((ROOT.parent/'gpu_preflight/vllm/attempt_002/inventory.json').read_text())['engine_source'];errors=[]
for row in original:
 path=Path(dist.locate_file(row['relative_path']))
 if hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:errors.append('pinned_original_source_drift:'+row['relative_path'])
result={'status':'PASS_READONLY_SOURCE_CAPTURE' if not errors and not missing else 'FAIL_INCOMPLETE_SOURCE_CAPTURE','version':dist.version,'files':records,'missing':missing,'errors':errors,'GPU_requests':0,'model_loads':0,'cap_writes':0,'device_queue_barrier_validation':'NOT_RUN','full_goal_complete':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'files':len(records),'missing':missing,'errors':errors,'GPU_requests':0,'model_loads':0,'cap_writes':0}));raise SystemExit(result['status']!='PASS_READONLY_SOURCE_CAPTURE')
