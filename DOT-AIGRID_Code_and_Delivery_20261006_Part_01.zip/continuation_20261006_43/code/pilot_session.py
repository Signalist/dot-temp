from pathlib import Path
import json,sys,subprocess
from source_guard import check
ROOT=Path(__file__).resolve().parents[1]
def run(session):
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 protocol=json.loads((ROOT/'AB_DEVICE_PROTOCOL.json').read_text());order=protocol['sessions'][session];rows=[]
 for arm in order:
  p=subprocess.run([sys.executable,str(ROOT/'code'/('arm_'+arm.lower()+'.py')),str(out/arm),sys.argv[2]],capture_output=True,text=True,timeout=300)
  (out/(arm+'_stdout.txt')).write_text(p.stdout);(out/(arm+'_stderr.txt')).write_text(p.stderr)
  path=out/arm/'result.json';r=json.loads(path.read_text()) if path.exists() else {'status':'MISSING_RESULT'}
  rows.append({'arm':arm,'returncode':p.returncode,'status':r['status']})
  if p.returncode or not r['status'].startswith('PASS'):
   (out/'result.json').write_text(json.dumps({'status':'FAIL_NO_NEXT_ARM','arms':rows,'full_goal_complete':False},indent=2)+'\n');raise SystemExit(1)
 metrics={a:json.loads((out/a/'metrics.json').read_text()) for a in order}
 for k in ['generated_token_sha256','completed_tokens','stop_class']:
  if len({metrics[a][k] for a in order})!=1:raise RuntimeError('output_equivalence_failed:'+k)
 devices=[]
 for a in order:
  b=json.loads((out/a/'gpu_before.json').read_text())[0];e=json.loads((out/a/'gpu_after.json').read_text())[0]
  pair=(b['uuid_sha256'],b['power_limit_W'])
  if pair!=(e['uuid_sha256'],e['power_limit_W']):raise RuntimeError('device_or_cap_changed')
  devices.append(pair)
 if len(set(devices))!=1:raise RuntimeError('paired_device_mismatch')
 if any(metrics[a]['cycle_energy_J'] is None for a in order):raise RuntimeError('energy_counter_not_supported_no_expansion')
 result={'status':'PASS_THREE_ARM_DEVELOPMENT_OBSERVATION','session':session,'order':order,'arms':rows,'metrics':metrics,'output_hash_equal':True,'common_device_and_cap':True,'acceptability_decision':None,'J_W6':None,'full_goal_complete':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'session':session}))
