from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def audit():
 rows=[];attempts=[];bindings=[];counts={'planned_requests':18,'completed_requests':0,'failed_arm_processes':0,'observed_cancelled_requests':0,'observed_truncated_requests':0,'observed_timeout_requests':0}
 for s in range(1,7):
  session='pilot_s'+str(s);receipt=ROOT/'submissions'/session/'attempt_001';out=ROOT/'artifacts'/session/'attempt_001'
  instances=sorted(receipt.glob('instances_*.json'))
  if not instances:raise ValueError('platform_instances_missing:'+session)
  p=instances[-1];d=json.loads(p.read_text())
  if not d.get('ok') or len(d.get('data',[]))!=1:raise ValueError('unverified_single_instance')
  i=d['data'][0]
  if i['instance_status']!='instance_success':raise ValueError('instance_not_success')
  run_ns=(int(i['finished_at'])-int(i['started_at']))*1000000
  if run_ns!=int(i['running_time_ms'])*1000000:raise ValueError('platform_duration_inconsistent')
  bindings.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  arms=[]
  for arm in ['OFF','MIN','FULL']:
   a=out/arm;r=json.loads((a/'result.json').read_text());m=json.loads((a/'metrics.json').read_text());marks={x['label']:x for x in json.loads((a/'energy_counter.json').read_text())}
   init=(marks['engine_ready']['arrival_ns']-marks['cycle_start']['query_begin_ns'])/1e6
   req=(marks['request_recovery_end']['arrival_ns']-marks['request_recovery_start']['query_begin_ns'])/1e6
   arms.append({'arm':arm,'script_wall_ns':r['host_wall_duration_ns'],'reported_GPU_cycle_energy_J':m['cycle_energy_J'],'counter_engine_ready_interval_ms':init,'request_closure_extraction_interval_ms':req,'cycle_latency_ms':m['cycle_latency_ms'],'optimization_and_control':'No physical controller or optimizer executed; instrumentation installation/readout retained within measured scopes','excluded_from_cycle_energy':['Pre-counter Python/import/source/model integrity checks','Post-counter result writing and nvidia-smi inventory'],'excluded_costs_retained_in_platform_running_time':True})
  sum_ns=sum(x['script_wall_ns'] for x in arms)
  if sum_ns>run_ns:raise ValueError('script_scope_exceeds_platform')
  rows.append({'session':session,'platform_running_ns':run_ns,'sum_script_wall_ns':sum_ns,'unpartitioned_platform_minus_script_ns':run_ns-sum_ns,'unpartitioned_scope':'Includes process imports, pre-timer integrity checks, orchestration, residual output and platform accounting; not exclusively instrumentation cost','arms':arms,'platform_boundary':'Reported instance duration; not external energy or verified billing/allocation duration'})
  for attempt in sorted((ROOT/'artifacts'/session).glob('attempt_*')):
   for arm in ['OFF','MIN','FULL']:
    path=attempt/arm/'result.json'
    if not path.exists():continue
    r=json.loads(path.read_text());attempts.append({'session':session,'attempt':attempt.name,'arm':arm,'status':r['status']})
    if r['status'].startswith('PASS'):
     counts['completed_requests']+=1;reason=r.get('terminal_stop_class')
     if reason=='cancel':counts['observed_cancelled_requests']+=1
     if reason=='length':counts['observed_truncated_requests']+=1
     if reason=='timeout':counts['observed_timeout_requests']+=1
    else:counts['failed_arm_processes']+=1
 report={'status':'OBSERVED_EXECUTION_COST_AND_ATTEMPT_ACCOUNTING','sessions':rows,'attempts':attempts,'counts':counts,'source_bindings':bindings,'failure_rate_scope':'Arm process failure is not automatically an attempted model request; no reliability certification from 18 short pilot requests','NVML_total_energy_is_not_J_W6':True,'J_W6':None,'physical_state_recovery_qualified':False,'all_instrumentation_overhead_scope_qualified':False,'remaining_cost_limits':['No external CPU/whole-machine energy meter','Common endpoint observer cost not separately identifiable','Scheduler initialization included in cycle and platform costs, not excluded','No actual physical controller/optimizer deployed'],'full_goal_complete':False}
 p=ROOT/'COST_AND_ATTEMPT_AUDIT.json'
 if p.exists():raise FileExistsError(p)
 p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'sessions':len(rows),'counts':counts}))
if __name__=='__main__':audit()
