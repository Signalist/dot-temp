from pathlib import Path
import argparse,json,hashlib,sys,importlib.util,statistics
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from adapters.acquisition_identity import identity_for_output,verify_rows
from adapters.pilot_metrics import summarize
from source_guard import check
def verify(session,snapshot):
 receipt=ROOT/'submissions'/('pilot_'+session)/'attempt_001';a=ROOT/'artifacts'/('pilot_'+session)/'attempt_001'
 check(ROOT,receipt/'source_freeze.json')
 d=json.loads((receipt/f'detail_{snapshot}.json').read_text());i=json.loads((receipt/f'instances_{snapshot}.json').read_text());l=json.loads((receipt/f'logs_{snapshot}.json').read_text())
 if not d.get('ok') or d['data']['status']!='job_succeeded':raise ValueError('platform_not_terminal_success')
 if not i.get('ok') or not i['data'] or any(x['instance_status']!='instance_success' for x in i['data']):raise ValueError('instance_not_success')
 logs=[x.get('message','') for x in l.get('data',{}).get('logs',[])]
 if not l.get('ok') or not any('exit code 0' in x.lower() or 'exitcode: 0' in x.lower() or 'exitcode=0' in x.lower() for x in logs):raise ValueError('exit_zero_unproven')
 session_result=json.loads((a/'result.json').read_text())
 if session_result['status']!='PASS_THREE_ARM_DEVELOPMENT_OBSERVATION':raise ValueError('session_not_complete')
 results=[];allids=[];bindings=[]
 def bind(p):bindings.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 for arm in ['OFF','MIN','FULL']:
  out=a/arm;expected=identity_for_output(out,ROOT.parent);allids.append(expected['acquisition_id'])
  if json.loads((out/'acquisition_identity.json').read_text())!=expected:raise ValueError('acquisition_namespace_mismatch')
  events=json.loads((out/'observation_metadata.json').read_text())['events'];verify_rows(events,expected)
  marks=json.loads((out/'energy_counter.json').read_text());verify_rows(marks,expected)
  if [x['label'] for x in marks]!=['cycle_start','engine_ready','request_recovery_start','request_recovery_end','cycle_end']:raise ValueError('missing_cycle_boundaries')
  if any(x['energy_mJ'] is None or x['query_begin_ns']>x['arrival_ns'] for x in marks):raise ValueError('invalid_counter')
  if any(y['energy_mJ']<x['energy_mJ'] or y['query_begin_ns']<x['arrival_ns'] for x,y in zip(marks,marks[1:])):raise ValueError('counter_or_clock_order')
  metrics=json.loads((out/'metrics.json').read_text());derived=summarize(events,marks,0,0)
  for k in ['cycle_energy_J','request_recovery_energy_J','cycle_latency_ms','TTFT_ms','TPOT_ms','ITL_ms','request_e2e_ms','generated_token_sha256']:
   if metrics[k]!=derived[k]:raise ValueError('metrics_replay_mismatch:'+k)
  ack=json.loads((out/'closure_ack.json').read_text());w=ack['worker_ack']
  if not w['cuda_all_stream_sync_ack'] or ack['next_request_admitted'] or ack['frontend_request_states']!=0:raise ValueError('closure_failure')
  if not ack['controller_issue_ns']<=w['worker_query_begin_ns']<=w['worker_return_ns']<=ack['controller_return_ns']:raise ValueError('worker_clock_order')
  if any(x['boot_id']!=w['boot_id'] for x in marks+events):raise ValueError('host_clock_boot_mismatch')
  if json.loads((out/'shutdown_check.json').read_text())['remaining_compute_processes']!=0:raise ValueError('shutdown_failure')
  nvml=[] if arm=='OFF' else [json.loads(x) for x in (out/'nvml.jsonl').read_text().splitlines()]
  if arm=='OFF' and (out/'host_events.jsonl').stat().st_size:raise ValueError('OFF_has_persistent_events')
  telemetry={'periodic_rows':len(nvml),'native_bandwidth':'UNQUALIFIED','tracking_error':None,'physical_recovery_time':None}
  if nvml:
   verify_rows(nvml,expected)
   if any(x['boot_id']!=w['boot_id'] or x['query_begin_ns']>x['arrival_ns'] or x['raw_power_mW']<0 for x in nvml):raise ValueError('telemetry_invalid')
   intervals=[(y['query_begin_ns']-x['query_begin_ns'])/1e6 for x,y in zip(nvml,nvml[1:])]
   if any(x<=0 for x in intervals):raise ValueError('nonmonotonic_telemetry')
   power=[x['power_W'] for x in nvml]
   telemetry.update({'requested_period_ms':50,'observed_host_interval_min_median_max_ms':[min(intervals),statistics.median(intervals),max(intervals)],'queried_power_min_mean_max_W':[min(power),statistics.mean(power),max(power)],'scope':'Host query intervals and NVML-reported values; no native bandwidth, actual slew or commanded-power tracking guarantee'})
  device=None
  if arm=='FULL':
   spec=importlib.util.spec_from_file_location('join',ROOT.parent/'continuation_20261006_38/ops/join_scheduler.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
   worker=json.loads((out/'sample_events.json').read_text());binding=json.loads((out/'request_bindings.json').read_text())
   if len(worker)!=1 or len(binding)!=1 or binding[0]['external_request_id']!=expected['request_id']:raise ValueError('worker_binding_mismatch')
   device=m.join(worker[0],[json.loads(x) for x in (out/'scheduler_events.jsonl').read_text().splitlines()],binding[0])
   if worker[0]['boot_id']!=w['boot_id']:raise ValueError('worker_event_clock_mismatch')
   for x in worker[0]['rows']:
    if not x['host_record_begin_ns']<=x['host_record_return_ns']<=x['host_sync_begin_ns']<=x['host_completion_observed_ns']:raise ValueError('event_bound_order')
   device['host_event_observation_widths_ms']=[(x['host_completion_observed_ns']-x['host_record_begin_ns'])/1e6 for x in worker[0]['rows']]
  for p in sorted(out.rglob('*')):
   rel=p.relative_to(out)
   if p.is_file() and not {'cache','hf','torch','triton','vllm','__pycache__'}.intersection(rel.parts) and p.suffix in ['.json','.jsonl','.txt']:bind(p)
  terminal=next(x for x in events if x['event']=='engine_terminal')
  results.append({'arm':arm,'acquisition_id':expected['acquisition_id'],'telemetry':telemetry,'device_join':device,'host_terminal_to_closure_ack_ms':(ack['controller_return_ns']-terminal['engine_visible_ns'])/1e6,'energy_counter_query_durations_us':[(x['arrival_ns']-x['query_begin_ns'])/1000 for x in marks],'energy_counter_quantum_J':.001,'counter_accuracy_update_period_resolution':'NOT_CALIBRATED; API unit quantum is not measurement accuracy','physical_initial_final_state_equivalence':False})
 if len(set(allids))!=3:raise ValueError('duplicate_arm_identity')
 out=ROOT/f'VERIFIED_{session}_{snapshot}.json'
 if out.exists():raise FileExistsError(out)
 report={'status':'PASS_PLATFORM_RAW_METRIC_REPLAY_IDENTITIES_CLOSURE_AND_EOS_JOIN','session':session,'arms':results,'raw_bindings':bindings,'counter_boundary':'GPU_REPORTED_ONLY','J_W6':None,'acceptability_decision':None,'full_goal_complete':False}
 out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'session':session,'status':report['status'],'raw_files':len(bindings)}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--session',required=True);p.add_argument('--snapshot',required=True);a=p.parse_args();verify(a.session,a.snapshot)
