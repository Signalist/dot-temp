"""Fixed development cohort; planning sensitivity, never a success decision."""
from pathlib import Path
import json,statistics,math,random,hashlib
ROOT=Path(__file__).resolve().parents[1]
def quantile(values,p):
 v=sorted(values);x=(len(v)-1)*p;i=int(x);j=min(i+1,len(v)-1)
 return v[i]+(v[j]-v[i])*(x-i)
def analyze():
 protocol=json.loads((ROOT/'AB_DEVICE_PROTOCOL.json').read_text());sessions=[];sources=[]
 for session in protocol['sessions']:
  paths=list((ROOT/'artifacts'/('pilot_'+session)).glob('attempt_*/result.json'))
  good=[p for p in paths if json.loads(p.read_text()).get('status')=='PASS_THREE_ARM_DEVELOPMENT_OBSERVATION']
  if len(good)!=1:raise ValueError('six_complete_unique_sessions_required:'+session)
  p=good[0];d=json.loads(p.read_text());sessions.append(d)
  sources.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 base=statistics.mean(x['metrics']['OFF']['cycle_energy_J'] for x in sessions)
 if base<=0:raise ValueError('nonpositive_energy_scale')
 pairs=[];rng=random.Random(4317)
 for arm in ['MIN','FULL']:
  reports={}
  for field in ['cycle_energy_J','cycle_latency_ms','request_e2e_ms','TTFT_ms','TPOT_ms']:
   a=[x['metrics']['OFF'][field] for x in sessions];b=[x['metrics'][arm][field] for x in sessions]
   if any(v is None for v in a+b):reports[field]={'status':'UNAVAILABLE'};continue
   delta=[y-x for x,y in zip(a,b)];samples=[statistics.mean(rng.choices(delta,k=len(delta))) for _ in range(10000)]
   reports[field]={'OFF_mean':statistics.mean(a),'arm_mean':statistics.mean(b),'paired_mean_difference':statistics.mean(delta),'paired_SD':statistics.stdev(delta),'relative_difference_percent':100*statistics.mean(delta)/statistics.mean(a) if statistics.mean(a) else None,'bootstrap_percentile_95_diagnostic':[quantile(samples,.025),quantile(samples,.975)],'uncertainty_scope':'Six session paired resampling; fragile small-pilot diagnostic, not confirmation inference'}
  tails={}
  for field in ['request_e2e_ms','TTFT_ms','TPOT_ms']:
   a=[x['metrics']['OFF'][field] for x in sessions];b=[x['metrics'][arm][field] for x in sessions]
   if any(v is None for v in a+b):continue
   for q in [.95,.99]:
    draws=[]
    for _ in range(10000):
     indices=rng.choices(range(len(sessions)),k=len(sessions))
     draws.append(quantile([b[i] for i in indices],q)-quantile([a[i] for i in indices],q))
    x,y=quantile(a,q),quantile(b,q)
    tails[field+'_P'+str(round(100*q))]={'OFF_empirical_ms':x,'arm_empirical_ms':y,'difference_ms':y-x,'difference_percent':100*(y-x)/x if x else None,'bootstrap_percentile_95_diagnostic_ms':[quantile(draws,.025),quantile(draws,.975)],'qualification':'Small-pilot empirical tail; not production QoS or confirmation'}
  reports['empirical_tail_differences']=tails
  sd=reports['cycle_energy_J']['paired_SD'];sensitivity=[]
  z=statistics.NormalDist().inv_cdf(.975)+statistics.NormalDist().inv_cdf(.8)
  for relative in protocol['sensitivity_relative_energy']:
   delta=base*relative
   sensitivity.append({'relative_energy_difference_percent':relative*100,'difference_J':delta,'paired_sessions_normal_approximation':max(2,math.ceil((z*sd/delta)**2)),'pilot_pairs':len(sessions),'pilot_SD_J':sd,'variance_lower_upper_factor_scenario':[.5,2.0],'sessions_at_half_SD':max(2,math.ceil((z*.5*sd/delta)**2)),'sessions_at_double_SD':max(2,math.ceil((z*2*sd/delta)**2)),'assumptions':'Two-sided alpha .05, power .80; iid paired-session normal approximation. Factors are sensitivity scenarios, not confidence bounds. Need new frozen protocol; not an approved N or success threshold.'})
  pairs.append({'comparison':arm+' minus OFF','metrics':reports,'energy_sample_size_sensitivity':sensitivity})
 descriptive={}
 for arm in ['OFF','MIN','FULL']:
  descriptive[arm]={}
  for field in ['request_e2e_ms','TTFT_ms','TPOT_ms','cycle_latency_ms','cycle_energy_J']:
   v=[x['metrics'][arm][field] for x in sessions]
   descriptive[arm][field]={'n':len(v),'mean':statistics.mean(v),'SD_between_sessions':statistics.stdev(v),'empirical_P95':quantile(v,.95),'empirical_P99':quantile(v,.99),'tail_scope':'Empirical interpolation of six first requests; insufficient for stable production-tail estimation'} if all(x is not None for x in v) else {'status':'UNAVAILABLE'}
 report={'status':'DEVELOPMENT_DESCRIPTIVE_NO_ACCEPTABILITY_DECISION','independent_sessions':len(sessions),'paired_comparisons':pairs,'descriptive':descriptive,'source_bindings':sources,'J_W6':None,'acceptability_threshold':None,'confirmation_protocol_frozen':False,'physical_control_writes':0,'service_TPOT_excluding_EOS_ms':None,'useful_output_tokens_per_request':1,'energy_scope':protocol['energy_scope'],'limitations':['NVML accuracy, coverage and temporal update bandwidth unqualified','Independent engine cold-start and thermal/history variation retained','Common measurement overhead retained, not separately identifiable','All attempt failures require companion audit; successful cohort alone does not give failure rate','No physical tracking experiment or initial/final physical state equivalence','Six short tasks insufficient for production QoS tails','TPOT and ITL in raw metrics count EOS; here each task emits one useful token plus EOS, so service TPOT excluding EOS is undefined'],'full_goal_complete':False}
 out=ROOT/'PILOT_SENSITIVITY.json'
 if out.exists():raise FileExistsError(out)
 out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'sessions':len(sessions),'J_W6':None}))
if __name__=='__main__':analyze()
