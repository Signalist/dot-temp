from pathlib import Path
import sys,json,time,hashlib,subprocess,statistics
from source_guard import check
ROOT=Path(__file__).resolve().parents[1]
def run(out):
 import pynvml as nv
 nv.nvmlInit()
 try:
  if nv.nvmlDeviceGetCount()!=1:raise RuntimeError('single_allocated_GPU_required')
  proc=subprocess.run(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],capture_output=True,text=True,check=True,timeout=10)
  if proc.stdout.strip():raise RuntimeError('other_compute_process_present')
  device=nv.nvmlDeviceGetHandleByIndex(0);u=nv.nvmlDeviceGetUUID(device);u=u.decode() if isinstance(u,bytes) else u
  identity={'uuid_sha256':hashlib.sha256(u.encode()).hexdigest(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'driver':nv.nvmlSystemGetDriverVersion(),'device_name':nv.nvmlDeviceGetName(device)}
  for k,v in list(identity.items()):
   if isinstance(v,bytes):identity[k]=v.decode()
  cap=nv.nvmlDeviceGetPowerManagementLimit(device);rows=[];started=time.monotonic_ns()
  with (out/'counter_probe.jsonl').open('x') as stream:
   for i in range(500):
    begin=time.monotonic_ns();energy=nv.nvmlDeviceGetTotalEnergyConsumption(device);energy_end=time.monotonic_ns();power=nv.nvmlDeviceGetPowerUsage(device);arrival=time.monotonic_ns()
    if type(energy) is not int or energy<0 or type(power) is not int or power<0:raise RuntimeError('invalid_counter_or_power')
    row={'index':i,**identity,'query_begin_ns':begin,'energy_query_end_ns':energy_end,'arrival_ns':arrival,'energy_mJ':energy,'power_mW':power,'requested_period_ns':10000000,'native_timestamp':None,'boundary':'NVML_GPU_REPORTED_QUERY_DOMAIN'}
    stream.write(json.dumps(row)+'\n');rows.append(row)
    target=started+(i+1)*10000000;time.sleep(max(0,(target-time.monotonic_ns())/1e9))
  if nv.nvmlDeviceGetPowerManagementLimit(device)!=cap:raise RuntimeError('cap_changed')
  delta=[b['energy_mJ']-a['energy_mJ'] for a,b in zip(rows,rows[1:])]
  if any(x<0 for x in delta):raise RuntimeError('counter_reset_or_rollover')
  positive=[x for x in delta if x>0];host_gaps=[(b['query_begin_ns']-a['query_begin_ns'])/1e6 for a,b in zip(rows,rows[1:])]
  result={'status':'PASS_READ_ONLY_COUNTER_UPDATE_DIAGNOSTIC','identity':identity,'samples':len(rows),'energy_API_unit_quantum_J':.001,'observed_positive_energy_increment_min_median_max_J':[min(positive)/1000,statistics.median(positive)/1000,max(positive)/1000] if positive else None,'zero_increment_fraction':sum(x==0 for x in delta)/len(delta),'host_query_interval_min_median_max_ms':[min(host_gaps),statistics.median(host_gaps),max(host_gaps)],'energy_query_latency_median_us':statistics.median((x['energy_query_end_ns']-x['query_begin_ns'])/1000 for x in rows),'power_API_unit_quantum_W':.001,'power_repeated_adjacent_fraction':sum(a['power_mW']==b['power_mW'] for a,b in zip(rows,rows[1:]))/len(delta),'cap_writes':0,'GPU_model_requests':0,'J_W6':None,'limitation':'Observed query-domain increments in idle-only diagnostic; no calibrated accuracy, native sample bandwidth, under-load resolution, external DC or continuous slew guarantee','full_goal_complete':False}
  return result
 finally:nv.nvmlShutdown()
if __name__=='__main__':
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 try:result=run(out)
 except BaseException as e:
  import traceback
  (out/'failure_traceback.txt').write_text(traceback.format_exc());result={'status':'FAIL_COUNTER_PROBE','error_type':type(e).__name__,'full_goal_complete':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(not result['status'].startswith('PASS'))
