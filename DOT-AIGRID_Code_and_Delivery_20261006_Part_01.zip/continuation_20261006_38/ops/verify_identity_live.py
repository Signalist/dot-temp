from pathlib import Path
import sys,json,argparse,hashlib,importlib.util
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from adapters.acquisition_identity import identity_for_output,verify_rows

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);args=p.parse_args()
 receipt=ROOT/'submissions/pair_s1/attempt_001';a=ROOT/'artifacts/pair_s1/attempt_001'
 d=json.loads((receipt/f'detail_{args.snapshot}.json').read_text())
 if not d.get('ok') or d['data']['status']!='job_succeeded':raise ValueError('platform_not_succeeded')
 inst=json.loads((receipt/f'instances_{args.snapshot}.json').read_text())
 if not inst.get('ok') or not inst['data'] or any(x['instance_status']!='instance_success' for x in inst['data']):raise ValueError('instance_not_succeeded')
 for f in json.loads((receipt/'source_freeze.json').read_text())['files']:
  if hashlib.sha256((ROOT/f['path']).read_bytes()).hexdigest()!=f['sha256']:raise ValueError('source_drift')
 rows=[];hashes=[]
 for arm in ['A','B']:
  out=a/arm;expected=identity_for_output(out,ROOT.parent)
  if json.loads((out/'acquisition_identity.json').read_text())!=expected:raise ValueError('unexpected_saved_identity')
  host=[json.loads(x) for x in (out/'host_events.jsonl').read_text().splitlines()]
  nvml=[json.loads(x) for x in (out/'nvml.jsonl').read_text().splitlines()]
  verify_rows(host,expected);verify_rows(nvml,expected)
  terminal=[x for x in host if x['event']=='engine_terminal']
  if len(terminal)!=1 or terminal[0]['stop_class']!='natural_eos_token_host_verified':raise ValueError('natural_EOS_unproven')
  hashes.append(terminal[0]['generated_token_sha256'])
  ack=json.loads((out/'closure_ack.json').read_text());w=ack['worker_ack']
  if not w['cuda_all_stream_sync_ack'] or ack['next_request_admitted']:raise ValueError('closure_failed')
  if not ack['controller_issue_ns']<=w['worker_query_begin_ns']<=w['worker_return_ns']<=ack['controller_return_ns']:raise ValueError('worker_clock_order')
  if any(x['boot_id']!=w['boot_id'] for x in host+nvml):raise ValueError('clock_domain_changed')
  if arm=='B':
   binding=json.loads((out/'request_bindings.json').read_text())
   if len(binding)!=1 or binding[0]['external_request_id']!=expected['request_id']:raise ValueError('external_engine_binding_mismatch')
   spec=importlib.util.spec_from_file_location('join',ROOT/'ops/join_scheduler.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
   m.join(json.loads((out/'sample_events.json').read_text())[0],[json.loads(x) for x in (out/'scheduler_events.jsonl').read_text().splitlines()],binding[0])
  rows.append({'arm':arm,'acquisition_id':expected['acquisition_id'],'request_id':expected['request_id'],'host_rows':len(host),'NVML_rows':len(nvml)})
 if len({x['acquisition_id'] for x in rows})!=2 or len(set(hashes))!=1:raise ValueError('duplicate_identity_or_changed_output')
 report={'status':'PASS_LIVE_DISTINCT_ARM_IDENTITIES_AND_HOST_NVML_ENGINE_BINDINGS','arms':rows,
         'purpose':'TECHNICAL_REGRESSION_ONLY','pooled_with_prior_overhead_pilot':False,
         'overhead_qualification':'NOT_CLAIMED','full_goal_complete':False}
 target=ROOT/f'VERIFIED_IDENTITY_{args.snapshot}.json'
 if target.exists():raise FileExistsError(target)
 target.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
