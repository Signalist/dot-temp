from pathlib import Path
import json,os,subprocess,time,hashlib,collections
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent;jobs={};failed=[]
for root in [WS/'qz_submissions',*[WS/f'continuation_20261006_{n:02d}/submissions' for n in range(1,40)]]:
 for p in root.rglob('*.json'):
  if 'submit' not in p.name:continue
  try:d=json.loads(p.read_text());id=d.get('data',{}).get('job_id')
  except (ValueError,AttributeError):continue
  if id:jobs[id]=str(p.relative_to(WS))
  elif d.get('ok') is False:failed.append({'receipt':str(p.relative_to(WS)),'error':d.get('error',{}).get('http_status')})
 out=ROOT/'platform';out.mkdir(exist_ok=True)
env=dict(os.environ)
for k in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(k,None)
rows=[]
for id,receipt in jobs.items():
 r=subprocess.run(['qzcli','detail',id,'--brief'],env=env,capture_output=True,text=True,timeout=45);p=out/(id+'.json');p.write_text(r.stdout);d=json.loads(r.stdout)
 if not d.get('ok'):
  time.sleep(2);r=subprocess.run(['qzcli','detail',id,'--brief'],env=env,capture_output=True,text=True,timeout=45);p.write_text(r.stdout);d=json.loads(r.stdout)
 row={'job_id':id,'submit_receipt':receipt,'status':d.get('data',{}).get('status') if d.get('ok') else 'OBSERVATION_FAILED','detail_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};rows.append(row);time.sleep(.5)
report={'checked_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'schema_version':'w6-submission-review-3','jobs':rows,'status_counts':dict(collections.Counter(r['status'] for r in rows)),'submission_failures_without_job_id':failed,'live_jobs':[r['job_id'] for r in rows if r['status'] in ['job_creating','job_running','job_queuing','job_success_reserving']],'unknown_jobs':[r['job_id'] for r in rows if r['status']=='OBSERVATION_FAILED'],'all_small_projects_complete':False}
(ROOT/'CURRENT_JOB_RECONCILIATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'counts':report['status_counts'],'live_jobs':report['live_jobs'],'unknown_jobs':report['unknown_jobs'],'submission_failure_receipts':len(failed)},indent=2))
