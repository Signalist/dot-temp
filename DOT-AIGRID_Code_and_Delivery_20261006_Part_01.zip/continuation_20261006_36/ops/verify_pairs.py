from pathlib import Path
import json,argparse,hashlib,importlib.util
ROOT=Path(__file__).resolve().parents[1]

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);args=p.parse_args()
 spec=importlib.util.spec_from_file_location('join',ROOT/'ops/join_scheduler.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 protocol=json.loads((ROOT/'AB_DEVICE_PROTOCOL.json').read_text());reports=[]
 for session in ['s1','s2']:
  task='pair_'+session;receipt=ROOT/'submissions'/task/'attempt_001';a=ROOT/'artifacts'/task/'attempt_001'
  detail=json.loads((receipt/f'detail_{args.snapshot}.json').read_text())
  instances=json.loads((receipt/f'instances_{args.snapshot}.json').read_text())
  if not detail.get('ok') or detail['data']['status']!='job_succeeded':raise ValueError('platform_not_succeeded')
  if not instances.get('ok') or not instances['data'] or any(x['instance_status']!='instance_success' for x in instances['data']):raise ValueError('instance_not_succeeded')
  for row in json.loads((receipt/'source_freeze.json').read_text())['files']:
   if hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()!=row['sha256']:raise ValueError('frozen_source_changed')
  result=json.loads((a/'result.json').read_text())
  if result['status']!='PASS_MEASURED_DEVICE_INSTRUMENTATION_PAIR' or result['order']!=protocol['sessions'][session]:raise ValueError('pair_result_or_order_changed')
  terms={};devices=[];timing={}
  for arm in ['A','B']:
   out=a/arm;host=[json.loads(x) for x in (out/'host_events.jsonl').read_text().splitlines()];t=[x for x in host if x['event']=='engine_terminal']
   if len(t)!=1 or t[0]['stop_class']!='natural_eos_token_host_verified':raise ValueError('natural_EOS_not_proven')
   terms[arm]=t[0];ack=json.loads((out/'closure_ack.json').read_text());w=ack['worker_ack']
   if not w['cuda_all_stream_sync_ack'] or ack['next_request_admitted']:raise ValueError('closure_failed')
   if not ack['controller_issue_ns']<=w['worker_query_begin_ns']<=w['worker_return_ns']<=ack['controller_return_ns']:raise ValueError('closure_clock_order')
   if any(x['boot_id']!=w['boot_id'] for x in host):raise ValueError('host_worker_clock_mismatch')
   before=json.loads((out/'gpu_before.json').read_text());after=json.loads((out/'gpu_after.json').read_text())
   if len(before)!=1 or len(after)!=1:raise ValueError('single_GPU_required')
   identity=lambda x:(x[0]['uuid_sha256'],x[0]['power_limit_W'])
   if identity(before)!=identity(after):raise ValueError('cap_or_GPU_changed')
   devices.append(identity(before));timing[arm]=json.loads((out/'instrumentation_timing.json').read_text())['elapsed_ns']
  if devices[0]!=devices[1]:raise ValueError('different_AB_GPU')
  if any(terms['A'][k]!=terms['B'][k] for k in ['generated_token_sha256','completed_tokens','stop_class']):raise ValueError('output_mismatch')
  b=a/'B';joined=module.join(json.loads((b/'sample_events.json').read_text())[0],
      [json.loads(x) for x in (b/'scheduler_events.jsonl').read_text().splitlines()],json.loads((b/'request_bindings.json').read_text())[0])
  if result['end_to_end_B_minus_A_ns']!=timing['B']-timing['A']:raise ValueError('timing_summary_mismatch')
  reports.append({'session':session,'order':result['order'],'end_to_end_B_minus_A_ns':timing['B']-timing['A'],
                  'output_hash_equal':True,'accepted_EOS_step':joined['accepted_EOS_step']})
 report={'status':'PASS_TWO_MEASURED_DEVICE_HOOK_DEVELOPMENT_PAIRS','pairs':reports,
         'overhead_acceptable':'NOT_QUALIFIED_NO_PRESPECIFIED_THRESHOLD',
         'independent_engine_initialization_confound':'RETAINED','full_goal_complete':False}
 out=ROOT/f'VERIFIED_PAIRS_{args.snapshot}.json'
 if out.exists():raise FileExistsError(out)
 out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
