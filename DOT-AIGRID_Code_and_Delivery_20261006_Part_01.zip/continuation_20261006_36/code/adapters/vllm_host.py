"""vLLM 0.20.2 cumulative host-output bridge. No device timestamps or cap actuator.

Token IDs are retained in memory only to verify cumulative prefixes. Sink events
contain counts/reasons/identity, never text or token IDs. Passing CPU tests does
not qualify the engine/device/cancellation physical contract.
"""
import asyncio,time
from dataclasses import dataclass

class ContractError(RuntimeError):pass
class CleanupError(RuntimeError):pass

@dataclass(frozen=True)
class RequestContract:
 request_id:str
 max_tokens:int
 eos_token_ids:tuple[int,...]
 seed:int
 ignore_eos:bool=False
 stop_strings:tuple[str,...]=()
 stop_token_ids:tuple[int,...]=()
 def __post_init__(self):
  if not self.request_id or type(self.max_tokens) is not int or not 1<=self.max_tokens<=4096 or type(self.seed) is not int:raise ContractError("invalid_request_contract")
  if not self.eos_token_ids or not all(type(t) is int and t>=0 for t in self.eos_token_ids):raise ContractError("invalid_eos_token_contract")

class CumulativeObserver:
 def __init__(self,contract):
  self.contract=contract;self.tokens=();self.finished=False
 def observe(self,output):
  c=self.contract
  if self.finished:raise ContractError('output_after_terminal')
  if output.request_id!=c.request_id:raise ContractError('mixed_request_id')
  if len(output.outputs)!=1 or output.outputs[0].index!=0:raise ContractError('n_must_equal_1')
  item=output.outputs[0];ids=tuple(item.token_ids)
  if not all(type(x) is int and x>=0 for x in ids):raise ContractError('invalid_token_ids')
  if ids[:len(self.tokens)]!=self.tokens or len(ids)<len(self.tokens):raise ContractError('cumulative_prefix_changed_or_missing')
  if len(ids)>c.max_tokens:raise ContractError('max_tokens_exceeded')
  old=len(self.tokens);self.tokens=ids;finish=item.finish_reason
  if output.finished and finish is None:raise ContractError('terminal_without_reason')
  if finish is not None and not output.finished:raise ContractError('reason_before_terminal')
  classification=None
  if output.finished:
   if finish=='length':classification='length'
   elif finish in ('abort','cancelled','cancel'):classification='cancel'
   elif finish in ('error','timeout'):classification=finish
   elif finish=='stop':
    natural=(not c.ignore_eos and ids and ids[-1] in c.eos_token_ids and not c.stop_strings and not c.stop_token_ids and item.stop_reason in (None,ids[-1]))
    rule_verified=(isinstance(item.stop_reason,str) and item.stop_reason in c.stop_strings) or (type(item.stop_reason) is int and item.stop_reason in c.stop_token_ids)
    classification='natural_eos_token_host_verified' if natural else ('stop_rule' if rule_verified else 'unknown')
   else:classification='unknown'
  self.finished=bool(output.finished)
  reason=item.stop_reason
  allowlisted=(reason is None or isinstance(reason,str) and reason in c.stop_strings or type(reason) is int and reason in c.eos_token_ids+c.stop_token_ids)
  import hashlib,json
  metadata={'generated_token_sha256':hashlib.sha256(json.dumps(list(ids),separators=(',',':')).encode()).hexdigest(),'actual_stop_reason':reason if allowlisted else None,'stop_reason_redacted':not allowlisted,'stop_reason_type':type(reason).__name__,'declared_stop_strings':list(c.stop_strings),'declared_stop_token_ids':list(c.stop_token_ids),'declared_eos_token_ids':list(c.eos_token_ids),'ignore_eos':c.ignore_eos,'terminal_eos_token_id':ids[-1] if output.finished and ids and ids[-1] in c.eos_token_ids else None,'metadata_scope':'ALLOWLISTED_STOP_METADATA_NOT_GENERATED_TOKEN_SEQUENCE'}
  return {**metadata,'request_id':c.request_id,'event':'engine_terminal' if self.finished else 'host_progress','completed_tokens':len(ids),'new_tokens':len(ids)-old,'duplicate_cumulative':len(ids)==old,'finish_reason':finish,'stop_class':classification,'censored':classification!='natural_eos_token_host_verified' if self.finished else None,'engine_visible_ns':time.monotonic_ns(),'timestamp_source':'host_engine_output','true_eos_ns':None,'device_completion_ns':None,'max_tokens':c.max_tokens,'seed':c.seed}

class HostEngineBridge:
 def __init__(self,engine,sink,*,timeout_s=30,cleanup_timeout_s=10):
  if not 0<timeout_s<=600 or not 0<cleanup_timeout_s<=60:raise ContractError('invalid_time_budget')
  self.engine=engine;self.sink=sink;self.timeout_s=timeout_s;self.cleanup_timeout_s=cleanup_timeout_s;self.blocked=False;self.busy=False
 async def _cleanup(self,request_id,abort):
  if abort:await asyncio.wait_for(self.engine.abort(request_id),self.cleanup_timeout_s)
  await asyncio.wait_for(self.engine.wait_for_requests_to_drain(drain_timeout=max(1,int(self.cleanup_timeout_s))),self.cleanup_timeout_s)
  states=getattr(getattr(self.engine,'output_processor',None),'request_states',None)
  if not isinstance(states,dict) or states:raise CleanupError('host_request_states_not_empty')
  return {'event':'host_drain_observed','request_id':request_id,'host_visible_ns':time.monotonic_ns(),'host_request_states':0,'physical_queue_drained':None,'device_completion_verified':False,'evidence_scope':'HOST_ONLY_NOT_DEVICE_BARRIER'}
 async def run(self,prompt,sampling_params,contract):
  if self.blocked:raise CleanupError('previous_cleanup_failed_no_next_request')
  if self.busy:raise ContractError('concurrency_must_equal_1')
  if sampling_params.n!=1 or sampling_params.max_tokens!=contract.max_tokens or sampling_params.seed!=contract.seed:raise ContractError('sampling_contract_mismatch')
  kind=getattr(sampling_params.output_kind,'name',sampling_params.output_kind)
  if kind!='CUMULATIVE':raise ContractError('only_cumulative_output_supported_no_delta_guessing')
  if bool(sampling_params.ignore_eos)!=contract.ignore_eos or tuple(sampling_params.stop or ())!=contract.stop_strings or tuple(sampling_params.stop_token_ids or ())!=contract.stop_token_ids:raise ContractError('stop_contract_mismatch')
  self.busy=True;observer=CumulativeObserver(contract);original_error=None;stream=None
  try:
   self.sink({'event':'request_start','request_id':contract.request_id,'host_visible_ns':time.monotonic_ns(),'timestamp_source':'host_controller','max_tokens':contract.max_tokens,'seed':contract.seed})
   async with asyncio.timeout(self.timeout_s):
    stream=self.engine.generate(prompt,sampling_params,contract.request_id)
    async for output in stream:self.sink(observer.observe(output))
    if not observer.finished:raise ContractError('stream_closed_without_terminal')
  except BaseException as e:original_error=e
  finally:
   try:
    # Cancellation remains a hard stop if cleanup cannot be completed. No new
    # request may enter after a failed abort/drain, even when sink writes fail.
    drain=await self._cleanup(contract.request_id,abort=original_error is not None)
    if stream is not None:await asyncio.wait_for(stream.aclose(),self.cleanup_timeout_s)
    self.sink(drain)
   except BaseException as cleanup_error:
    self.blocked=True;self.busy=False
    raise CleanupError('abort_or_drain_or_sink_failed; hardware_state_unconfirmed') from cleanup_error
   self.busy=False
  if original_error is not None:
   # A host drain is insufficient to certify physical cancellation. Require a
   # new session/qualified recovery before another request after any failure.
   self.blocked=True
   raise original_error
  return {'status':'HOST_OUTPUT_COMPLETE','completed_tokens':len(observer.tokens),'physical_admission':'BLOCKED_DEVICE_BARRIER_UNQUALIFIED'}
