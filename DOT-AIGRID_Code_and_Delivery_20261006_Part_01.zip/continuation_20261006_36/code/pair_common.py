from pathlib import Path
import sys,json,subprocess,hashlib
from source_guard import check
ROOT=Path(__file__).resolve().parents[1]

def run(session):
 check(ROOT,sys.argv[2]);out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 protocol=json.loads((ROOT/'AB_DEVICE_PROTOCOL.json').read_text());order=protocol['sessions'][session]
 results=[]
 for arm in order:
  dest=out/arm
  p=subprocess.run([sys.executable,str(ROOT/'code'/('arm_'+arm.lower()+'.py')),str(dest),sys.argv[2]],capture_output=True,text=True,timeout=260)
  (out/(arm+'_stdout.txt')).write_text(p.stdout);(out/(arm+'_stderr.txt')).write_text(p.stderr)
  result=json.loads((dest/'result.json').read_text()) if (dest/'result.json').exists() else {'status':'MISSING_RESULT'}
  results.append({'arm':arm,'returncode':p.returncode,'status':result['status']})
  if p.returncode or not result['status'].startswith('PASS'):
   (out/'result.json').write_text(json.dumps({'status':'FAIL_PAIR_STOP_NO_NEXT_ARM','arms':results,'full_goal_complete':False},indent=2)+'\n')
   raise SystemExit(1)
 terminals={}
 for arm in order:
  events=[json.loads(x) for x in (out/arm/'host_events.jsonl').read_text().splitlines()]
  terminal=[x for x in events if x['event']=='engine_terminal']
  if len(terminal)!=1:raise RuntimeError('single_terminal_required')
  terminals[arm]=terminal[0]
 if any(terminals['A'][k]!=terminals['B'][k] for k in ['generated_token_sha256','completed_tokens','stop_class']):raise RuntimeError('AB_output_mismatch')
 devices=[]
 for arm in order:
  before=json.loads((out/arm/'gpu_before.json').read_text())[0]
  after=json.loads((out/arm/'gpu_after.json').read_text())[0]
  devices.append((before['uuid_sha256'],before['power_limit_W']))
  if devices[-1]!=(after['uuid_sha256'],after['power_limit_W']):raise RuntimeError('device_or_cap_changed')
 if len(set(devices))!=1:raise RuntimeError('AB_GPU_identity_changed')
 timing={arm:json.loads((out/arm/'instrumentation_timing.json').read_text()) for arm in order}
 result={'status':'PASS_MEASURED_DEVICE_INSTRUMENTATION_PAIR','session':session,'order':order,'arms':results,
         'output_token_hash_equal':True,'completed_tokens':terminals['A']['completed_tokens'],
         'end_to_end_B_minus_A_ns':timing['B']['elapsed_ns']-timing['A']['elapsed_ns'],
         'overhead_acceptable':'NOT_QUALIFIED_NO_PRESPECIFIED_THRESHOLD','profiler_enabled':False,
         'independent_engine_initialization_confound':'RETAINED','full_goal_complete':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
