from pathlib import Path
import json,hashlib,zipfile,datetime,collections
ROOT=Path(__file__).resolve().parent;WS=ROOT.parent
old=json.loads((WS/'continuation_20261006_01/COMPLETE_SCOPE_AUDIT.json').read_text());matrix=json.loads((WS/'source_plan/W6_Codex_Execution_Plan_20261005/experiment_design/EXPERIMENT_MATRIX.json').read_text())
progress={'I02':'Host bridge ABI and failure handling tested; device/controller/real model qualification absent.','I07':'Software EOS/censoring/failure tests; no acquired real model episodes.','F04':'Immutable parent/child registry and no-overwrite diagnostic model bindings tested; operator freeze and measured confirmation absent.','C05':'Complete five-attempt raw index retains original failure; diagnostic analysis gates tested; confirmatory statistics not established.','X01':'Workload axis registry extension tested; no measured workload-transfer experiment.','X04':'Phase/context axis and nested registry analysis tested; no measured queue/concurrency experiment.'}
byid={r['id']:r for r in matrix['experiments']}
for row in old['items']:
 row['new_software_progress']=progress.get(row['experiment_id'],row.get('new_software_progress'))
 row['dependency_contract']=byid[row['experiment_id']].get('depends_on_by_route',{})
 row['gate_zh']=byid[row['experiment_id']]['gate_zh']
 for evidence in row['required_outputs']:
  p=WS/evidence['path'];evidence['currently_exists']=p.is_file()
  if p.is_file():evidence['currently_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();evidence['unchanged_since_previous_audit']=evidence['currently_sha256']==evidence['sha256']
old['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();old['latest_software_report']='continuation_20261006_03/VERIFIED_RESUBMISSION_RESULTS.json';old['submission_reconciliation']='continuation_20261006_04/ALL_SUBMISSIONS_RECONCILED_FINAL.json';old['all_small_projects_complete']=False;old['status_counts']=dict(collections.Counter(x['prior_status'] for x in old['items']))
(ROOT/'FULL_SCOPE_CURRENT_AUDIT.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n')
report=json.loads((ROOT/'ALL_SUBMISSIONS_RECONCILED_FINAL.json').read_text())
(ROOT/'README_ZH.txt').write_text('W6 / DOT-AIGRID 补充软件交付。不是全部物理实验完成包。\n11次提交实时核验：9成功、1失败、1停止；无正在运行任务。初次HTTP429观测故障全部恢复，原失败回执保留；未因429重启作业。\n已修复python缺失入口为python3、目录迁移、正确quota/group/priority4、进程级代理移除、完整代码冻结和实际落盘核验。\n最新独立service_v2诊断分析入口支持嵌套采集路径，保留原有w6-dc验证，父子注册表冻结与SHA完整性检查；46项CPU_TEST/SIMULATED测试远端通过。不是确认性统计或MEASURED证据。\nFULL_SCOPE_CURRENT_AUDIT.json覆盖原计划38个ID；未提升任何硬件状态。缺模型/tokenizer或dataset ID；device timing、物理执行器/恢复/burn以及DC/PCC仪表和同步准入仍未建立。\n补充ZIP保留工作区相对路径，合并到现有DOT-AIGRID。运行 continuation_20261006_03/ops/verify_results.py 做只读验证。必须保有原source_package、原封存结果目录及原始交付；本包不重复打包这些输入。网络/权重/驱动不自动安装或下载。\n平台完整detail/instances/logs原件保留本地platform_snapshot和platform_retry_001，本ZIP只含摘要和SHA以避免公开无关账户信息。\n')
paths=[]
latest=WS/'continuation_20261006_03'
for folder in ['code','tests','ops','artifacts/integration/attempt_001','submissions/integration/attempt_001']:
 for p in sorted((latest/folder).rglob('*')):
  if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
  if folder.startswith('submissions') and (p.name.startswith(('detail_','instances_','logs_'))):continue
  paths.append(p)
for p in [latest/'README_ZH.txt',latest/'VERIFIED_RESUBMISSION_RESULTS.json',WS/'continuation_20261006_01/VERIFIED_RESUBMISSION_RESULTS.json',WS/'continuation_20261006_02/VERIFIED_RESUBMISSION_RESULTS.json',ROOT/'ALL_SUBMISSIONS_RECONCILED_FINAL.json',ROOT/'FULL_SCOPE_CURRENT_AUDIT.json',ROOT/'README_ZH.txt',ROOT/'reconcile.py',ROOT/'retry_observations.py',ROOT/'build_review.py']:paths.append(p)
# Latest verifier requires terminal sanitized platform receipts. They contain
# no commands, profiles, serial numbers or model outputs.
for name in ['detail','instances','logs']:
 p=latest/f'submissions/integration/attempt_001/{name}_004.json'
 data=json.loads(p.read_text());d=data['data']
 if name=='detail':d={'status':d['status']}
 elif name=='instances':d=[{'instance_status':x['instance_status']} for x in d]
 else:d={'logs':[{'message':x['message']} for x in d.get('logs',[]) if x.get('message')=='exit code 0']}
 safe=ROOT/'review_receipts'/f'{name}_004.json';safe.parent.mkdir(exist_ok=True);safe.write_text(json.dumps({'ok':True,'data':d},indent=2)+'\n')
 paths.append(safe)
manifest={'files':[{'path':str(p.relative_to(WS)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],'platform_receipt_replacement_map':{str((ROOT/'review_receipts'/f'{n}_004.json').relative_to(WS)):f'continuation_20261006_03/submissions/integration/attempt_001/{n}_004.json' for n in ['detail','instances','logs']},'physical_completion':False}
mp=ROOT/'PAYLOAD_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');paths.append(mp)
archive=ROOT/'W6_Software_Repair_Supplement_20261006.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in paths:
  name=str(p.relative_to(WS));name=manifest['platform_receipt_replacement_map'].get(name,name);z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest['files']:
  name=manifest['platform_receipt_replacement_map'].get(row['path'],row['path']);b=z.read(name);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
assert archive.stat().st_size<18_000_000
receipt={'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'CRC_and_all_payload_hashes':'PASS','files':len(paths),'all_small_projects_complete':False}
(ROOT/'DELIVERY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
